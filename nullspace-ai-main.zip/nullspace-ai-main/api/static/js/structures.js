/* Skeletal structures for the dashboard, drawn in the browser from the SMILES strings the model
   knows. The drawing is done by the vendored SmilesDrawer (static/vendor, MIT); this file is
   the small layer on top of it:
     - halogenOf / productSmiles: pure string logic, node-testable. The 15 aryl halides are one of
       Cl, Br or I as the FIRST atom of the SMILES, attached to one of five aryl groups, so the
       coupling product is drawn by swapping that leading atom for the amine. The amine is fixed:
       4-methylaniline, the amine of the dataset behind the model (Ahneman et al., Science 2018).
       The product is drawn from the reactants; it is not a computed prediction.
     - render(container, smiles, opts): draws into a container, caches the drawing, and falls back
       to the plain SMILES text if the library is missing or the string will not parse (it never
       throws and never logs).
   SmilesDrawer colours atoms by element; app.css forces every drawing to the site's monochrome. */
(function (root) {
  'use strict';

  var AMINE = 'CC1=CC=C(N)C=C1';           // 4-methylaniline
  var AMINE_FRAGMENT = 'CC1=CC=C(C=C1)N';  // the same, written to end on the nitrogen that bonds to the aryl carbon

  function halogenOf(smiles) {
    if (typeof smiles !== 'string') { return null; }
    var m = /^(Cl|Br|I)/.exec(smiles);
    return m ? m[1] : null;
  }

  function productSmiles(aryl) {
    var x = halogenOf(aryl);
    if (!x) { return null; }
    if ((aryl.match(/Cl|Br|I/g) || []).length !== 1) { return null; }   // more than one halogen: which one couples is unknown
    return AMINE_FRAGMENT + aryl.slice(x.length);
  }

  // SmilesDrawer gives every drawing a SQUARE viewBox, so a wide molecule in a wide box is limited
  // by the box's height and fills a fraction of it (an aryl halide, about a third). Cropping the
  // viewBox to the molecule's own bounding box, plus a small margin, lets it use the room. Pure
  // and node-tested; returns null for an empty or invalid box (the drawing then keeps its own).
  function viewBoxFor(box, pad) {
    if (!box || !(box.width > 0) || !(box.height > 0) || !isFinite(box.x) || !isFinite(box.y)) { return null; }
    var margin = Math.max(4, Math.max(box.width, box.height) * (pad === undefined ? 0.06 : pad));
    return [box.x - margin, box.y - margin, box.width + 2 * margin, box.height + 2 * margin]
      .map(function (n) { return Math.round(n * 100) / 100; }).join(' ');
  }

  /* ---- Drawing --------------------------------------------------------------- */
  var GROUND = '#0A0A0A';
  var THEME = { dark: {
    C: '#FFFFFF', O: '#FFFFFF', N: '#FFFFFF', F: '#FFFFFF', CL: '#FFFFFF', BR: '#FFFFFF', I: '#FFFFFF',
    P: '#FFFFFF', S: '#FFFFFF', B: '#FFFFFF', SI: '#FFFFFF', H: '#FFFFFF', BACKGROUND: GROUND
  } };
  var drawers = {};
  var cache = {};
  var counter = 0;

  function available() {
    var lib = root.SmilesDrawer;
    return !!(lib && lib.SvgDrawer && lib.parse);
  }

  function drawerFor(w, h) {
    var key = w + 'x' + h;
    if (!drawers[key]) {
      drawers[key] = new root.SmilesDrawer.SvgDrawer({
        width: w, height: h, padding: 8, bondThickness: 1.2, compactDrawing: false, themes: THEME
      });
    }
    return drawers[key];
  }

  function fallback(container, smiles) {
    container.textContent = smiles;
    container.classList.add('is-fallback');
    return false;
  }

  // Draws `smiles` into `container` (replacing what is there). Returns true if a structure was drawn.
  function render(container, smiles, opts) {
    opts = opts || {};
    var w = opts.width || 192, h = opts.height || 120;
    container.textContent = '';
    container.classList.remove('is-fallback');
    if (!smiles) { return false; }
    if (!available()) { return fallback(container, smiles); }

    var key = smiles + '|' + w + 'x' + h;
    if (cache[key]) {
      container.appendChild(cache[key].cloneNode(true));
      return true;
    }
    var svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    var id = 'f2f-structure-' + (++counter);
    svg.setAttribute('id', id);      // SmilesDrawer addresses its target by id
    container.appendChild(svg);
    var drawn = false;
    try {
      root.SmilesDrawer.parse(smiles, function (tree) {
        try { drawerFor(w, h).draw(tree, id, 'dark'); drawn = true; } catch (e) { drawn = false; }
      }, function () { drawn = false; });
    } catch (e) { drawn = false; }
    if (!drawn) { return fallback(container, smiles); }
    svg.removeAttribute('id');
    svg.removeAttribute('width');    // the stylesheet sizes it; the viewBox keeps the proportions
    svg.removeAttribute('height');
    try {                            // needs the container to be displayed; otherwise the drawing keeps its own viewBox
      var vb = viewBoxFor(svg.getBBox());
      if (vb) { svg.setAttribute('viewBox', vb); }
    } catch (e) { /* not rendered yet */ }
    svg.setAttribute('aria-hidden', 'true');
    svg.setAttribute('focusable', 'false');
    cache[key] = svg.cloneNode(true);
    return true;
  }

  var api = {
    AMINE: AMINE, AMINE_FRAGMENT: AMINE_FRAGMENT,
    halogenOf: halogenOf, productSmiles: productSmiles, viewBoxFor: viewBoxFor, render: render, available: available
  };
  if (typeof module === 'object' && module.exports) { module.exports = api; }
  else { (root.F2F = root.F2F || {}).Structures = api; }
})(typeof window !== 'undefined' ? window : globalThis);
