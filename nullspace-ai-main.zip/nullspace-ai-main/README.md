# nullspace AI — Failure Intelligence Engine

MLOps project (AD4V71) — predicts whether a proposed Buchwald–Hartwig
cross-coupling reaction is likely to fail (yield < 5%) before it is run,
using Logistic Regression, Decision Tree, Random Forest, and XGBoost,
tracked end-to-end with DVC + MLflow and served via a Flask API.

Madhumitha N (24AD0162) · Manga Haripriya (24AD0164) — AI & Data Science,
Chennai Institute of Technology

## Project structure

```
f2f-ai/
├── data/
│   ├── raw/                  # place Dreher_and_Doyle_input_data.xlsx here
│   └── processed/            # written by src/preprocess.py
├── src/
│   ├── config.py             # shared paths, schema, hyperparameters
│   ├── preprocess.py         # clean data, build failure label, encode features
│   ├── train.py              # train + evaluate 4 models, log to MLflow
│   └── predict.py            # single-reaction inference (CLI + shared logic)
├── models/                   # written by train.py: best_model.pkl, scaler.pkl, ...
├── api/
│   ├── app.py                # Flask REST API
│   ├── requirements.txt
│   └── Dockerfile
├── monitoring/
│   ├── logger.py             # SQLite logging of every prediction request
│   └── drift_detector.py     # chi-square drift check vs. training distribution
├── dvc.yaml                  # DVC pipeline: preprocess -> train
├── params.yaml                # DVC-tracked hyperparameters
└── requirements.txt           # top-level dev environment
```

## 1. Setup

```bash
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt
```

> **Serving the API?** Install from `api/requirements.txt` instead (Python
> 3.12+). The top-level file pins an older xgboost that loads the shipped
> `models/best_model.pkl` without error but reads it wrongly, shifting every
> failure probability upward. The API refuses to start in such an environment
> (see `src/load_check.py`).

Place your dataset at `data/raw/Dreher_and_Doyle_input_data.xlsx`.

## 2. Run the pipeline

Either run the two stages directly:

```bash
python src/preprocess.py
python src/train.py
```

Or, if you have DVC set up (`dvc init` once, then `dvc remote add ...`):

```bash
dvc repro
```

This writes `models/best_model.pkl`, `models/label_encoders.pkl`,
`models/scaler.pkl`, `models/model_config.json`, and a comparison table +
plots for all four models.

## 3. Inspect experiments in MLflow

```bash
mlflow ui
```

Open http://localhost:5000 (or the port MLflow prints) to see every run's
parameters, metrics, and logged model artifact side by side.

## 4. Serve predictions

Locally:

```bash
python api/app.py
```

Sign-in: the dashboard is open by default. Any non-empty username and password
gets in, and the login page says so. To require real credentials instead, set
`F2F_DEV_BYPASS_AUTH=0` together with `F2F_USERNAME`, `F2F_PASSWORD` and `SECRET_KEY`.
A value the app does not recognise also requires real credentials, and logs why.
The JSON endpoints (`/predict`, `/explain`, `/predict/batch`, `/stats`, `/recent-predictions`,
`/activity`, `/coverage`) are public either way.

The dashboard is a grid of widgets you can rearrange (drag the handle, or use each widget's
arrow buttons; the order is remembered per browser). Its "Why this?" and "Try this instead"
widgets call `POST /explain`, which takes the same four inputs as `/predict` and returns how far
each input moved the score (exact per-input contributions from the XGBoost model) and the
one-input swaps that lower the failure probability. It describes what the model learned, not a
chemical mechanism, and it does not write to the prediction log.

Choosing a value draws its skeletal structure under the dropdown, and "The reaction" widget shows
your picks as a scheme (aryl halide + 4-methylaniline, the amine in the source dataset, with your
ligand, base and additive) above an animated catalytic cycle. The product is drawn from your aryl
halide by swapping its halogen for the amine, and the cycle is the textbook Buchwald-Hartwig one;
both are illustrations, not predictions, and the model sees category IDs, not mechanism. The
structures are drawn in the browser by SmilesDrawer 2.1.7 (MIT), vendored in `api/static/vendor/`
with its licence, so nothing is loaded from a CDN.

Four more widgets read the prediction log and the model, and refresh after each prediction:
Activity (predictions per hour for five days), Trend (per day for fourteen, with the share flagged
as failures), Input coverage (how often each value the model knows has been asked about) and Batch.
All dates and hours are UTC. Batch takes a CSV (or pasted rows) with the columns Ligand, Additive,
Base and Aryl halide, where each cell is a dropdown name such as "Ligand 2" or the full SMILES, and
returns a prediction per row from `POST /predict/batch` (200 rows and 100 KB at most per request).
Batch runs are not written to the prediction log, so they do not change the stats or the charts.
"Copy link" on the Predict widget makes a URL that restores the four choices; a link made against a
different set of options is recognised (a short fingerprint of the lists) and is not applied.

`/login` and `/signup` are standalone pages that share one animated reaction-progress
component. Sign-up is UI only: it does not create an account, it runs the same check as
sign-in and signs you into the one shared session, so `F2F_DEV_BYPASS_AUTH=0` applies to it too.

Test it:

```bash
curl -X POST http://localhost:5000/predict \
  -H "Content-Type: application/json" \
  -d '{"ligand": "CC(C)C(C=C(C(C)C)C=C1C(C)C)=C1C2=C(P([C@@]3(C[C@@H]4C5)C[C@H](C4)C[C@H]5C3)[C@]6(C7)C[C@@H](C[C@@H]7C8)C[C@@H]8C6)C(OC)=CC=C2OC",
       "additive": "CC1=CC(C)=NO1",
       "base": "CN1CCCN2C1=NCCC2",
       "aryl_halide": "ClC1=CC=C(OC)C=C1"}'
```

The API takes the model's full chemical strings, exactly as the dashboard's lists
show them. Short labels such as `L1` or `AH5` are display names on the login page
only; sending them returns a prediction with "not seen during training" warnings.

Or with Docker, from the project root (so the build context includes `src/` and `models/`):

```bash
docker build -f api/Dockerfile -t nullspace-ai-api .
docker run -p 5000:5000 -v $(pwd)/monitoring:/app/monitoring nullspace-ai-api
```

## 5. Monitoring and drift

Every `/predict` call is logged to `monitoring/predictions.db`.
`GET /stats`, `GET /recent-predictions`, `GET /activity` (hourly and daily counts) and
`GET /coverage` (how often each value was asked) read from that log.

`/coverage` compares what was asked with the training mix in `models/training_distribution.json`
(row counts per value, recorded there because the dataset is not in the Docker image). The training
grid covers every value about equally, so an "uneven" verdict describes how people use the tool, not
a model that has gone stale; the real drift check is `monitoring/drift_detector.py`, below. The
verdict is a chi-square test per input (four tests sharing one 5% false-alarm budget) and is
withheld until every input has 30 logged asks with known values. After changing the processed data
or the option lists, regenerate the file:

```bash
python src/write_training_distribution.py
```

Run the drift check on a schedule (cron, GitHub Action, or a scheduled
Colab cell):

```bash
python monitoring/drift_detector.py
```

This compares the categories seen in live traffic against the training
distribution per feature (chi-square test) and writes
`monitoring/drift_report.json`.

## 6. Retraining

Once drift is flagged or enough new labeled reactions are collected:
append them to `data/raw/`, rerun `dvc repro` (or `preprocess.py` +
`train.py` directly), and compare the new `models/model_config.json`
metrics against the currently deployed model before promoting it.

After every retrain, regenerate the model's load-time check in the verified
environment (the one installed from `api/requirements.txt`):

```bash
python src/write_load_check.py
```

Until you do, `/health` reports `"load_check": "stale"` and the API logs a
warning that the new model's predictions are unverified.

## Notes

- The scaler is only actually used by Logistic Regression; tree models
  ignore it, but it's kept as a shared artifact so `predict.py` doesn't
  need per-model branching logic beyond the `use_scaled_input` flag in
  `model_config.json`.
- The best model is selected by **recall on the failure class**, not
  accuracy — see the accompanying paper's Evaluation Metrics section for
  why a missed failure is costlier than a false alarm for this system.
