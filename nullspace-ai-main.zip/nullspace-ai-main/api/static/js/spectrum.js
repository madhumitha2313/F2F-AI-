/* Spectrum field: pick an input to make its band the solid indigo run, and read
   one value at a time by pointing at a bar. State is class toggles and
   textContent only, so it behaves the same with or without motion. Without
   JavaScript the server has already rendered the default band and its readout. */
(function () {
  'use strict';

  var HOVER_HINT = 'Point at a bar to read one value.';

  function init(root) {
    var tabs = Array.prototype.slice.call(root.querySelectorAll('.spectrum-tab'));
    var groups = Array.prototype.slice.call(root.querySelectorAll('.spectrum-group'));
    var out = {};
    Array.prototype.forEach.call(root.querySelectorAll('[data-r]'), function (el) {
      out[el.getAttribute('data-r')] = el;
    });

    function select(key) {
      groups.forEach(function (g) {
        var on = g.getAttribute('data-group') === key;
        g.classList.toggle('is-selected', on);
        if (on) {
          out.label.textContent = g.getAttribute('data-label');
          out.n.textContent = g.getAttribute('data-n');
          out.share.textContent = g.getAttribute('data-share');
          out.range.textContent = g.getAttribute('data-range');
        }
      });
      tabs.forEach(function (t) {
        t.setAttribute('aria-pressed', t.getAttribute('data-group') === key ? 'true' : 'false');
      });
      out.hover.textContent = HOVER_HINT;
    }

    tabs.forEach(function (t) {
      t.addEventListener('click', function () { select(t.getAttribute('data-group')); });
    });

    function read(bar) {
      var group = bar.parentNode;
      out.hover.textContent = group.getAttribute('data-label') + ': ' +
        bar.getAttribute('data-value') + ' | average predicted failure probability ' +
        bar.getAttribute('data-p');
    }
    Array.prototype.forEach.call(root.querySelectorAll('.spectrum-bar'), function (bar) {
      bar.addEventListener('mouseenter', function () { read(bar); });
      bar.addEventListener('click', function () { read(bar); });
    });
    root.querySelector('.spectrum-field').addEventListener('mouseleave', function () {
      out.hover.textContent = HOVER_HINT;
    });
  }

  Array.prototype.forEach.call(document.querySelectorAll('[data-spectrum]'), init);
})();
