/* Dashboard widget effects.
     - the "Widgets" menu in the nav: every widget as a link (#w-<id>), listed in the order the grid
       is showing them right now. The browser's own anchor scroll does the moving (the sticky nav is
       cleared by html { scroll-padding-top }); this file then focuses the widget it landed on and
       outlines it for a moment, so the eye finds it.
     - F2F.WidgetFx.run(ids): marks widgets as working (a soft moving glow, see app.css). It gives
       back done(). The glow stays at least MIN_RUN_MS, because a local prediction answers in a few
       tens of milliseconds and a flash that short is not seen.
   The logic that can be tested without a browser (ordering, links, the run tracker) is pure and
   exported for node; everything that touches the page is below it. */
(function (root) {
  'use strict';

  var MIN_RUN_MS = 900;      // how long a working widget glows at the least
  var ARRIVED_MS = 1600;     // how long the arrival outline stays

  /* ---- Pure ---------------------------------------------------------------------- */

  // [{id, title, pos, index}] -> a new list in the order the user sees: by the position the grid
  // reports (aria-posinset), else by page order. Anything without an id or a title is dropped.
  function sortWidgets(list) {
    if (!Array.isArray(list)) { return []; }
    return list
      .filter(function (w) { return w && w.id && w.title; })
      .slice()
      .sort(function (a, b) {
        var pa = isFinite(a.pos) ? a.pos : Infinity, pb = isFinite(b.pos) ? b.pos : Infinity;
        if (pa !== pb) { return pa < pb ? -1 : 1; }
        return a.index - b.index;
      });
  }

  // '#w-predict' -> 'predict', but only for a widget that exists.
  function hashTarget(hash, ids) {
    if (typeof hash !== 'string') { return null; }
    var m = /^#w-(.+)$/.exec(hash);
    return m && ids.indexOf(m[1]) !== -1 ? m[1] : null;
  }

  // Counts overlapping runs per widget. end() says how many ms to wait before clearing the glow:
  // 0 = now, null = another run on the same widget is still going.
  function createRunTracker(minMs) {
    var state = {};
    return {
      start: function (id, now) {
        var s = state[id] || (state[id] = { count: 0, since: 0 });
        if (s.count === 0) { s.since = now; }
        s.count += 1;
      },
      end: function (id, now) {
        var s = state[id];
        if (!s || s.count === 0) { return 0; }
        s.count -= 1;
        if (s.count > 0) { return null; }
        return Math.max(0, s.since + minMs - now);
      },
      isRunning: function (id) { return !!(state[id] && state[id].count > 0); }
    };
  }

  var api = { MIN_RUN_MS: MIN_RUN_MS, sortWidgets: sortWidgets, hashTarget: hashTarget, createRunTracker: createRunTracker };
  if (typeof module === 'object' && module.exports) { module.exports = api; return; }

  /* ---- Page ------------------------------------------------------------------------ */
  var F2F = (root.F2F = root.F2F || {});
  var tracker = createRunTracker(MIN_RUN_MS);
  var timers = {};

  function widgetEl(id) { return document.getElementById('w-' + id); }

  function setRunning(id, on) {
    var el = widgetEl(id);
    if (!el) { return; }
    el.classList.toggle('is-running', on);
    if (on) { el.setAttribute('aria-busy', 'true'); } else { el.removeAttribute('aria-busy'); }
  }

  // Mark widgets as working; call the result when the work is over (safe to call twice).
  api.run = function (ids) {
    var now = Date.now();
    ids.forEach(function (id) {
      tracker.start(id, now);
      window.clearTimeout(timers[id]);
      setRunning(id, true);
    });
    var finished = false;
    return function done() {
      if (finished) { return; }
      finished = true;
      var t = Date.now();
      ids.forEach(function (id) {
        var wait = tracker.end(id, t);
        if (wait === null) { return; }
        if (wait <= 0) { setRunning(id, false); return; }
        window.clearTimeout(timers[id]);
        timers[id] = window.setTimeout(function () { if (!tracker.isRunning(id)) { setRunning(id, false); } }, wait);
      });
    };
  };
  F2F.WidgetFx = api;

  function widgets() {
    var els = document.querySelectorAll('[data-widget]');
    return sortWidgets(Array.prototype.map.call(els, function (el, i) {
      return { id: el.getAttribute('data-widget'), title: el.getAttribute('aria-label') || '', pos: parseInt(el.getAttribute('aria-posinset'), 10), index: i };
    }));
  }

  // Focus the widget the page just scrolled to and outline it for a moment.
  var arrivedTimer = 0;
  function arrive(id) {
    var el = widgetEl(id);
    if (!el) { return; }
    var prev = document.querySelector('.widget.is-arrived');
    if (prev) { prev.classList.remove('is-arrived'); }
    try { el.focus({ preventScroll: true }); } catch (e) { /* older browsers */ }
    el.classList.add('is-arrived');
    window.clearTimeout(arrivedTimer);
    arrivedTimer = window.setTimeout(function () { el.classList.remove('is-arrived'); }, ARRIVED_MS);
  }

  // The anchor scroll may be smooth: arrive once it stops (scrollend), or after a beat if it
  // never needed to scroll.
  function arriveWhenSettled(id) {
    var fired = false;
    function go() { if (!fired) { fired = true; arrive(id); } }
    if ('onscrollend' in window) { window.addEventListener('scrollend', go, { once: true }); }
    window.setTimeout(go, 1100);
  }

  function mountMenu(menu) {
    var button = menu.querySelector('[data-widget-menu-button]');
    var panel = menu.querySelector('.nav-menu-panel');
    var list = menu.querySelector('[data-widget-menu-list]');
    if (!button || !panel || !list) { return; }

    function fill() {
      list.textContent = '';
      widgets().forEach(function (w) {
        var li = document.createElement('li');
        var a = document.createElement('a');
        a.href = '#w-' + w.id;
        a.textContent = w.title;
        li.appendChild(a);
        list.appendChild(li);
      });
    }
    function isOpen() { return !panel.hidden; }
    function open() { fill(); panel.hidden = false; button.setAttribute('aria-expanded', 'true'); }
    function close(returnFocus) {
      panel.hidden = true;
      button.setAttribute('aria-expanded', 'false');
      if (returnFocus) { button.focus(); }
    }

    button.addEventListener('click', function () { if (isOpen()) { close(false); } else { open(); } });
    panel.addEventListener('click', function (ev) {
      var a = ev.target.closest ? ev.target.closest('a[href^="#w-"]') : null;
      if (!a) { return; }
      var id = hashTarget(a.getAttribute('href'), widgets().map(function (w) { return w.id; }));
      close(false);
      if (id) { arriveWhenSettled(id); }   // the browser follows the link itself
    });
    document.addEventListener('click', function (ev) { if (isOpen() && !menu.contains(ev.target)) { close(false); } });
    document.addEventListener('keydown', function (ev) { if (ev.key === 'Escape' && isOpen()) { close(true); } });
    menu.addEventListener('focusout', function (ev) {
      if (isOpen() && ev.relatedTarget && !menu.contains(ev.relatedTarget)) { close(false); }
    });
  }

  var menu = document.querySelector('[data-widget-menu]');
  if (menu) { mountMenu(menu); }

  // Arriving by a #w-... link from elsewhere, or the back button, gets the same outline.
  function fromHash() {
    var id = hashTarget(window.location.hash, widgets().map(function (w) { return w.id; }));
    if (id) { arriveWhenSettled(id); }
  }
  window.addEventListener('hashchange', fromHash);
  window.setTimeout(fromHash, 500);   // after the grid has laid itself out
})(typeof window !== 'undefined' ? window : globalThis);
