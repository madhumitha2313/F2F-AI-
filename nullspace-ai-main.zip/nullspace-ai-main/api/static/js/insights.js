/* Shapes for the Activity, Trend and Input coverage widgets: turns the /activity and /coverage
   payloads into the cells and bars the page draws. No DOM, no network; node-testable.
   Every date and hour here is UTC, read from the payload's own date strings and the ISO time given,
   never from the browser's clock or time zone, so the picture is the same for everyone. */
(function (root) {
  'use strict';

  var WEEKDAYS = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
  var MIN_DAY_BAR = 0.04;
  var MIN_VALUE_BAR = 0.06;
  var DEFAULT_MIN_SAMPLES = 30;

  function num(v) { return (typeof v === 'number' && isFinite(v)) ? v : 0; }

  function plural(n, word) {
    n = num(n);
    return n + ' ' + word + (n === 1 ? '' : 's');
  }

  function percent(x, digits) {
    if (typeof x !== 'number' || !isFinite(x)) { return 'n/a'; }
    return (x * 100).toFixed(digits || 0) + '%';
  }

  // 0 for nothing; otherwise 1 to 4 in quarters of the busiest cell (ceil, so anything at all shows).
  function heatLevel(count, max) {
    if (!(count > 0) || !(max > 0)) { return 0; }
    return Math.min(4, Math.ceil(count * 4 / max));
  }

  function evennessText(evenness, samples) {
    var status = evenness && evenness.status;
    if (status === 'insufficient_data') {
      var min = (typeof evenness.min_samples === 'number' && isFinite(evenness.min_samples)) ? evenness.min_samples : DEFAULT_MIN_SAMPLES;
      return 'Needs ' + min + ' predictions to say how evenly values have been asked about; ' + num(samples) + ' so far.';
    }
    if (status === 'even') { return 'Questions so far are spread about as evenly as the training data.'; }
    if (status === 'uneven') {
      return 'Questions so far favour some values over others. That is expected when people pick what interests them; it does not mean the model is out of date.';
    }
    if (status === 'unavailable') { return 'The training mix is not available, so evenness cannot be shown.'; }
    return '';
  }

  // 'YYYY-MM-DD' -> 'Fri'. The weekday comes from the calendar date itself (built in UTC), so it
  // cannot slip a day in a time zone west of Greenwich.
  function weekdayOf(dateText) {
    var m = /^(\d{4})-(\d{2})-(\d{2})/.exec(typeof dateText === 'string' ? dateText : '');
    if (!m) { return null; }
    var t = Date.UTC(+m[1], +m[2] - 1, +m[3]);
    return { name: WEEKDAYS[new Date(t).getUTCDay()], day: +m[3] };
  }

  function utcMs(iso) {
    if (typeof iso !== 'string') { return NaN; }
    return Date.parse(/T[^Z+\-]*$/.test(iso) ? iso + 'Z' : iso);   // a time with no zone is read as UTC
  }

  function pad2(n) { return (n < 10 ? '0' : '') + n; }

  function activityCells(hourly, nowIso) {
    if (!hourly || !Array.isArray(hourly.days)) { return []; }
    var ms = utcMs(nowIso), nowDay = null, nowHour = -1;
    if (isFinite(ms)) { nowDay = new Date(ms).toISOString().slice(0, 10); nowHour = new Date(ms).getUTCHours(); }
    var lastDay = hourly.days.length - 1, max = 0;
    var rows = hourly.days.map(function (date, di) {
      var wd = weekdayOf(date), prefix = wd ? wd.name + ' ' : '';
      var counts = (hourly.counts && hourly.counts[di]) || [], flagged = (hourly.flagged && hourly.flagged[di]) || [];
      var cells = [];
      for (var h = 0; h < 24; h++) {
        var future = di === lastDay && date === nowDay && h > nowHour;
        var when = prefix + pad2(h) + ':00 - ';
        if (future) { cells.push({ count: 0, flagged: 0, level: 0, future: true, label: when + 'not yet' }); continue; }
        var count = num(counts[h]), flag = num(flagged[h]);
        if (count > max) { max = count; }
        cells.push({
          count: count, flagged: flag, level: 0, future: false,
          label: when + plural(count, 'prediction') + (flag > 0 ? ' (' + flag + ' flagged)' : '')
        });
      }
      return cells;
    });
    rows.forEach(function (cells) { cells.forEach(function (c) { if (!c.future) { c.level = heatLevel(c.count, max); } }); });
    return rows;
  }

  function dailyBars(daily) {
    var days = Array.isArray(daily) ? daily : [];
    var max = 0;
    days.forEach(function (d) { if (num(d.total) > max) { max = num(d.total); } });
    return days.map(function (d) {
      var total = num(d.total), flagged = num(d.flagged), wd = weekdayOf(d.date);
      var h = total > 0 ? Math.max(total / max, MIN_DAY_BAR) : 0;
      return {
        date: d.date,
        label: wd ? wd.name + ' ' + wd.day : String(d.date),
        total: total,
        flagged: flagged,
        h: h,
        flaggedH: flagged > 0 ? Math.min(h, Math.max(flagged / max, MIN_DAY_BAR)) : 0,
        empty: total <= 0
      };
    });
  }

  function coverageBars(features) {
    var list = Array.isArray(features) ? features : [];
    var max = 0;
    list.forEach(function (f) {
      (Array.isArray(f.values) ? f.values : []).forEach(function (v) { if (num(v.count) > max) { max = num(v.count); } });
    });
    return list.map(function (f) {
      var values = Array.isArray(f.values) ? f.values : [];
      var bars = values.map(function (v) {
        var count = num(v.count), asked = count > 0;
        return {
          name: v.name, count: count, asked: asked,
          h: asked ? Math.max(count / max, MIN_VALUE_BAR) : 0,
          share: typeof v.training_share === 'number' ? v.training_share : null
        };
      });
      return {
        key: f.key, label: f.label,
        total: typeof f.total === 'number' ? f.total : values.length,
        asked: typeof f.asked === 'number' ? f.asked : bars.filter(function (b) { return b.asked; }).length,
        bars: bars
      };
    });
  }

  var api = {
    heatLevel: heatLevel, activityCells: activityCells, dailyBars: dailyBars, coverageBars: coverageBars,
    percent: percent, evennessText: evennessText, plural: plural
  };
  if (typeof module === 'object' && module.exports) { module.exports = api; }
  else { (root.F2F = root.F2F || {}).Insights = api; }
})(typeof window !== 'undefined' ? window : globalThis);
