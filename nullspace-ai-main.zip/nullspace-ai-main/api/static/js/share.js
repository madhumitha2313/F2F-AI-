/* Share links: the pure logic behind "Copy link" on the Predict widget. No DOM, no network;
   node-testable.
     ?l=2&a=7&b=1&h=8&k=ab12cd
   l, a, b and h are 1-based positions in the ligand, additive, base and aryl halide lists (the same
   numbers as "Ligand 2", "Additive 7", ...). k is a fingerprint of those four ordered lists: the
   numbers only mean the same reaction while the lists are unchanged, so a link made against an older
   model can be recognised (matches) and offered rather than silently restoring something else.
   The fingerprint is FNV-1a over the JSON of the ordered lists, cut to six hex digits. It is a
   change detector, not a security feature. */
(function (root) {
  'use strict';

  var KEYS = ['ligand', 'additive', 'base', 'aryl_halide'];
  var PARAM = { ligand: 'l', additive: 'a', base: 'b', aryl_halide: 'h' };
  var NAME = { l: 'ligand', a: 'additive', b: 'base', h: 'aryl_halide' };

  function fingerprint(lists) {
    var ordered = {};
    KEYS.forEach(function (key) { ordered[key] = (lists && Array.isArray(lists[key])) ? lists[key] : []; });
    var text = JSON.stringify(ordered);
    var h = 0x811c9dc5;
    for (var i = 0; i < text.length; i++) {
      h ^= text.charCodeAt(i);
      h = Math.imul(h, 16777619) >>> 0;
    }
    return ('000000' + (h >>> 0).toString(16)).slice(-6);
  }

  function isIndex(v) { return typeof v === 'number' && isFinite(v) && v >= 1 && Math.floor(v) === v; }

  function encode(picks, fp) {
    var parts = [];
    KEYS.forEach(function (key) {
      var v = picks ? picks[key] : null;
      if (isIndex(v)) { parts.push(PARAM[key] + '=' + v); }
    });
    if (fp) { parts.push('k=' + encodeURIComponent(fp)); }
    return parts.join('&');
  }

  function unescape(s) {
    try { return decodeURIComponent(s.replace(/\+/g, ' ')); } catch (e) { return null; }
  }

  function shown(s) { return s.length > 24 ? s.slice(0, 24) + '...' : s; }

  function decode(search, counts) {
    var out = { picks: { ligand: null, additive: null, base: null, aryl_halide: null }, key: null, problems: [] };
    var query = typeof search === 'string' ? search.replace(/^\?/, '') : '';
    var seen = {};
    query.split('&').forEach(function (part) {
      if (!part) { return; }
      var eq = part.indexOf('=');
      var name = unescape(eq === -1 ? part : part.slice(0, eq));
      if (name === null || (!NAME[name] && name !== 'k') || seen[name]) { return; }
      seen[name] = true;                                   // the first of a repeated parameter wins
      var raw = eq === -1 ? '' : unescape(part.slice(eq + 1));
      if (name === 'k') {
        if (raw !== null && /^[0-9a-fA-F]{6}$/.test(raw)) { out.key = raw.toLowerCase(); }
        else { out.problems.push('k=' + shown(raw === null ? '?' : raw) + ' is not a valid model key; ignored'); }
        return;
      }
      var key = NAME[name];
      var max = (counts && isIndex(counts[key])) ? counts[key] : Infinity;
      var n = (raw !== null && /^[0-9]+$/.test(raw)) ? parseInt(raw, 10) : NaN;
      if (isIndex(n) && n <= max && n <= 9007199254740991) { out.picks[key] = n; }
      else {
        out.problems.push(name + '=' + shown(raw === null ? '?' : raw) + ' is not a valid ' + key.replace('_', ' ') +
          (max === Infinity ? '' : ' (1 to ' + max + ')') + '; ignored');
      }
    });
    return out;
  }

  function matches(key, fp) {
    return typeof key === 'string' && typeof fp === 'string' && key !== '' && key === fp;
  }

  function buildUrl(base, picks, fp) {
    base = typeof base === 'string' ? base : '';
    if (encode(picks, null) === '') { return base; }
    var hash = '', at = base.indexOf('#');
    if (at !== -1) { hash = base.slice(at); base = base.slice(0, at); }
    var joiner = base.indexOf('?') === -1 ? '?' : (/[?&]$/.test(base) ? '' : '&');
    return base + joiner + encode(picks, fp) + hash;
  }

  var api = { fingerprint: fingerprint, encode: encode, decode: decode, matches: matches, buildUrl: buildUrl };
  if (typeof module === 'object' && module.exports) { module.exports = api; }
  else { (root.F2F = root.F2F || {}).Share = api; }
})(typeof window !== 'undefined' ? window : globalThis);
