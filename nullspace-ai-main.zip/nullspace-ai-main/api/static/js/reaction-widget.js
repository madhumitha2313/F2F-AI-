/* "The reaction" widget: the reaction drawn as real structures, and the animated catalytic cycle
   beneath it (reaction-cycle.js).
     - the scheme: your aryl halide + 4-methylaniline -> product. The product is drawn from the
       aryl halide by swapping its halogen for the amine (structures.js); it is an illustration,
       not a prediction. Your ligand, base and additive are drawn under their dropdowns instead.
     - the cycle: the picks are named on it, and after a run the model's per-input pushes appear on
       it as badges. The mapping of an input onto a step is illustrative: the model sees category
       IDs, not mechanism.
   It only listens: dashboard.js announces 'f2f:inputs' (what is selected) and 'f2f:explained'
   (the contributions from POST /explain, or null). Without the drawing library the labels still
   update; without the cycle engine the scheme still works. */
(function () {
  'use strict';

  var host = document.querySelector('[data-reaction-widget]');
  if (!host) { return; }

  var F2F = window.F2F || {};
  var S = F2F.Structures && F2F.Structures.available() ? F2F.Structures : null;
  var cycleRoot = document.getElementById('rx-cycle');
  var cycle = F2F.ReactionCycle && cycleRoot ? F2F.ReactionCycle.mount(cycleRoot) : null;

  function byId(id) { return document.getElementById(id); }

  // Draw a structure into a slot (an empty slot shows as a dashed outline, see app.css).
  function draw(id, smiles, width, height) {
    var box = byId(id);
    if (!box) { return; }
    if (S && smiles) { S.render(box, smiles, { width: width, height: height }); }
    else { box.textContent = ''; box.classList.remove('is-fallback'); }
  }

  function caption(id, name, generic) {
    var el = byId(id);
    if (el) { el.textContent = name || generic; }
  }

  function update(detail) {
    var v = detail.values || {}, n = detail.names || {};

    // Only the reaction itself is drawn here. The ligand, base and additive are drawn under
    // their dropdowns (dashboard.js) and named on the cycle, so they are not repeated.
    draw('rx-aryl', v.aryl_halide, 240, 120);
    draw('rx-product', S ? S.productSmiles(v.aryl_halide) : null, 240, 120);
    caption('rx-aryl-name', n.aryl_halide, 'Aryl halide');

    if (cycle) {
      cycle.setPicks({
        aryl: v.aryl_halide ? { name: n.aryl_halide, halogen: S ? S.halogenOf(v.aryl_halide) : null } : null,
        ligand: v.ligand ? { name: n.ligand } : null,
        base: v.base ? { name: n.base } : null,
        additive: v.additive ? { name: n.additive } : null
      });
      cycle.setInfluence(null);   // the choice changed, so the last explanation no longer applies
    }
  }

  document.addEventListener('f2f:inputs', function (ev) { update(ev.detail || {}); });

  document.addEventListener('f2f:explained', function (ev) {
    if (!cycle) { return; }
    var list = ev.detail && ev.detail.contributions;
    if (!Array.isArray(list)) { cycle.setInfluence(null); return; }
    var influence = {};
    list.forEach(function (c) { influence[c.key] = { push: c.push, direction: c.direction }; });
    cycle.setInfluence(influence);
  });

  draw('rx-amine', S ? S.AMINE : null, 240, 120);
})();
