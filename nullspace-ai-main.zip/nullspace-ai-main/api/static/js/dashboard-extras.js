/* Dashboard extras: the four extra widgets and the share link.
     - Activity, Trend and Input coverage read GET /activity and GET /coverage (the prediction log
       and the model) on load and again whenever dashboard.js says a prediction was logged.
     - Batch turns a CSV (or pasted rows) into POST /predict/batch and shows the answers in a table
       that can be downloaded. Batch runs are not logged, so they never change the widgets above.
     - "Copy link" makes a URL that restores the four choices; opening one applies them, but only
       if it was made for this version of the model (a short fingerprint of the option lists).
   The logic worth testing lives in batch.js, share.js and insights.js (pure, node-tested); this
   file is the DOM around it. All text from the network is written with textContent. */
(function () {
  'use strict';

  var F2F = window.F2F || {};
  var grid = document.querySelector('[data-widget-grid]');
  var I = F2F.Insights;
  if (!grid || !I) { return; }

  var KEYS = ['ligand', 'additive', 'base', 'aryl_halide'];

  function byId(id) { return document.getElementById(id); }
  function el(tag, className, text) {
    var node = document.createElement(tag);
    if (className) { node.className = className; }
    if (text !== undefined) { node.textContent = text; }
    return node;
  }
  function getJson(url) {
    return fetch(url, { headers: { 'Accept': 'application/json' }, credentials: 'same-origin' })
      .then(function (res) {
        if (!res.ok) { throw new Error('HTTP ' + res.status); }
        return res.json();
      });
  }
  function shortDay(dateStr) {   // '2026-09-25' -> 'Fri 25', in UTC whatever the visitor's time zone
    var d = new Date(dateStr + 'T00:00:00Z');
    if (isNaN(d.getTime())) { return dateStr; }
    return d.toLocaleDateString('en-US', { weekday: 'short', timeZone: 'UTC' }) + ' ' + d.getUTCDate();
  }
  function showEmpty(prefix, message) {
    var empty = byId(prefix + '-empty'), body = byId(prefix + '-body');
    if (empty) { empty.textContent = message; empty.hidden = false; }
    if (body) { body.hidden = true; }
  }
  function showBody(prefix) {
    var empty = byId(prefix + '-empty'), body = byId(prefix + '-body');
    if (empty) { empty.hidden = true; }
    if (body) { body.hidden = false; }
  }

  /* ---- Activity: predictions per hour, five days ----------------------------------- */
  function renderActivity(d) {
    if (!d.total_all) { showEmpty('activity', 'No predictions logged yet.'); return; }
    showBody('activity');
    F2F.setLead(byId('activity-total'), String(d.hourly.total_today));
    var cells = I.activityCells(d.hourly, d.generated_at);
    var host = byId('activity-grid');
    host.textContent = '';
    cells.forEach(function (row, r) {
      var day = el('span', 'heat-day' + (r === cells.length - 1 ? ' is-today' : ''), r === cells.length - 1 ? 'Today' : shortDay(d.hourly.days[r]));
      host.appendChild(day);
      var line = el('span', 'heat-row');
      row.forEach(function (c) {
        var cell = el('span', 'heat-cell' + (c.future ? ' is-future' : ''));
        cell.setAttribute('data-level', String(c.level));
        if (c.label) { cell.title = c.label; }
        line.appendChild(cell);
      });
      host.appendChild(line);
    });
    host.appendChild(el('span'));
    var ticks = el('span', 'heat-ticks');
    ['00', '06', '12', '18'].forEach(function (h) { ticks.appendChild(el('span', '', h)); });
    host.appendChild(ticks);
    host.setAttribute('aria-label', 'Predictions per hour over the last five days, UTC. ' + I.plural(d.hourly.total_today, 'prediction') + ' today.');
  }

  /* ---- Trend: predictions per day, two weeks --------------------------------------- */
  function renderTrend(d) {
    var bars = I.dailyBars(d.daily);
    var any = bars.some(function (b) { return !b.empty; });
    if (!any) { showEmpty('trend', 'No predictions in the last 14 days.'); return; }
    showBody('trend');
    var w = d.week || {};
    F2F.setLead(byId('trend-rate'), I.percent(w.failure_rate, 1));
    byId('trend-note').textContent = w.total
      ? 'Failure rate over 7 days: ' + w.flagged + ' flagged of ' + I.plural(w.total, 'prediction') + '.'
      : 'Nothing logged in the last 7 days.';
    var host = byId('trend-bars');
    host.textContent = '';
    bars.forEach(function (b) {
      var col = el('span', 'trend-col' + (b.empty ? ' is-empty' : ''));
      col.title = b.label + ': ' + I.plural(b.total, 'prediction') + (b.total ? ' (' + b.flagged + ' flagged)' : '');
      var total = el('span', 'trend-total');
      total.style.setProperty('--h', String(b.h));
      col.appendChild(total);
      if (b.flagged) {
        var flag = el('span', 'trend-flag');
        flag.style.setProperty('--fh', String(b.flaggedH));
        col.appendChild(flag);
      }
      host.appendChild(col);
    });
    byId('trend-from').textContent = bars[0].label;
    host.setAttribute('aria-label', 'Predictions per day, UTC: ' + bars.map(function (b) { return b.label + ' ' + b.total + (b.flagged ? ' (' + b.flagged + ' flagged)' : ''); }).join(', ') + '.');
  }

  /* ---- Input coverage: how often each value has been asked about ------------------- */
  function renderCoverage(d) {
    var summary = byId('coverage-summary');
    if (!summary) { return; }
    F2F.setLead(summary, d.asked_values + ' of ' + d.total_values);
    var host = byId('coverage-groups');
    var hover = byId('coverage-hover');
    var idle = 'Point at a bar to read one value.';
    host.textContent = '';
    I.coverageBars(d.features).forEach(function (g) {
      var group = el('div', 'cov-group');
      group.style.setProperty('--n', String(g.bars.length));
      var bars = el('div', 'cov-bars');
      g.bars.forEach(function (b) {
        var text = b.name + ': ' + (b.count === 0 ? 'never asked' : b.count === 1 ? 'asked once' : 'asked ' + b.count + ' times');
        var bar = el('span', 'cov-bar' + (b.asked ? '' : ' is-unasked'));
        bar.style.setProperty('--h', String(b.h));
        bar.title = text;
        bar.setAttribute('role', 'img');
        bar.setAttribute('aria-label', text);
        bar.addEventListener('mouseenter', function () { bar.classList.add('is-hover'); hover.textContent = text; });
        bar.addEventListener('mouseleave', function () { bar.classList.remove('is-hover'); hover.textContent = idle; });
        bars.appendChild(bar);
      });
      group.appendChild(bars);
      var name = el('span', 'label cov-label');
      name.appendChild(el('span', 'cov-name', g.label));
      name.appendChild(el('span', 'cov-count', g.asked + '/' + g.total));
      group.appendChild(name);
      host.appendChild(group);
    });
    byId('coverage-note').textContent = I.evennessText(d.evenness, d.samples);
    byId('coverage-unseen').textContent = d.unseen_requests > 0
      ? I.plural(d.unseen_requests, 'request') + ' sent a value the model had not seen; the API swapped it for a known one and warned.'
      : 'No request has sent a value the model had not seen.';
  }

  function loadActivity() {
    var url = grid.getAttribute('data-activity-url');
    if (!url) { return; }
    getJson(url).then(function (d) { renderActivity(d); renderTrend(d); })
      .catch(function () {
        showEmpty('activity', 'The prediction log could not be read. Check the server log.');
        showEmpty('trend', 'The prediction log could not be read. Check the server log.');
      });
  }
  function loadCoverage() {
    var url = grid.getAttribute('data-coverage-url');
    if (!url || !byId('coverage-groups')) { return; }
    getJson(url).then(renderCoverage).catch(function () {
      byId('coverage-note').textContent = 'Coverage could not be read. Check the server log.';
    });
  }
  function refresh() { loadActivity(); loadCoverage(); }
  document.addEventListener('f2f:logged', refresh);
  refresh();

  /* ---- Batch ----------------------------------------------------------------------- */
  var B = F2F.Batch;
  var runBtn = byId('batch-run');
  if (B && runBtn) {
    var fileInput = byId('batch-file'), textEl = byId('batch-text'), statusEl = byId('batch-status');
    var errorEl = byId('batch-error'), resultsEl = byId('batch-results'), bodyEl = byId('batch-body');
    var downloadBtn = byId('batch-download'), templateBtn = byId('batch-template');
    var batchUrl = grid.getAttribute('data-batch-url');
    var lastResults = null;

    var setStatus = function (msg) { statusEl.textContent = msg || ''; };
    var showError = function (msg) { errorEl.textContent = msg || ''; errorEl.hidden = !msg; };

    var saveText = function (name, text) {
      var url = URL.createObjectURL(new Blob([text], { type: 'text/csv;charset=utf-8' }));
      var a = document.createElement('a');
      a.href = url; a.download = name;
      document.body.appendChild(a); a.click(); document.body.removeChild(a);
      window.setTimeout(function () { URL.revokeObjectURL(url); }, 1000);
    };

    var readFile = function (file) {
      if (!file) { return; }
      if (file.size > B.MAX_CHARS * 4) { showError('That file is too large. The limit is about 100 KB of text.'); return; }
      var reader = new FileReader();
      reader.onload = function () { textEl.value = String(reader.result || ''); showError(''); setStatus(file.name + ' loaded. Press Run batch.'); };
      reader.onerror = function () { showError('That file could not be read.'); };
      reader.readAsText(file);
    };
    fileInput.addEventListener('change', function () { readFile(fileInput.files && fileInput.files[0]); });
    // a CSV dropped anywhere on the widget is read the same way
    var host = runBtn.closest('.batch') || runBtn.parentNode;
    host.addEventListener('dragover', function (ev) { ev.preventDefault(); });
    host.addEventListener('drop', function (ev) {
      ev.preventDefault();
      if (ev.dataTransfer && ev.dataTransfer.files && ev.dataTransfer.files[0]) { readFile(ev.dataTransfer.files[0]); }
    });
    templateBtn.addEventListener('click', function () { saveText('f2f-batch-template.csv', B.template()); });
    downloadBtn.addEventListener('click', function () { if (lastResults) { saveText('f2f-batch-results.csv', B.resultsToCsv(lastResults)); } });

    var clip = function (v) { v = String(v || ''); return v.length > 16 ? v.slice(0, 15) + '…' : v; };
    var renderResults = function (results, sent) {
      bodyEl.textContent = '';
      results.forEach(function (r, i) {
        var tr = document.createElement('tr');
        tr.appendChild(el('td', '', String(r.row)));
        if (r.ok) {
          KEYS.forEach(function (k) { tr.appendChild(el('td', '', r.inputs[k])); });
          var out = el('td');
          var tag = el('span', 'batch-out', r.prediction);
          tag.setAttribute('data-result', r.prediction);
          out.appendChild(tag);
          tr.appendChild(out);
          tr.appendChild(el('td', 'num', F2F.pct(r.failure_probability)));
        } else {
          tr.className = 'is-error';
          var raw = sent[i] || {};
          KEYS.forEach(function (k) { tr.appendChild(el('td', '', clip(raw[k]))); });
          var msg = el('td', '', r.error);
          msg.colSpan = 2;
          tr.appendChild(msg);
        }
        bodyEl.appendChild(tr);
      });
      resultsEl.hidden = false;
      downloadBtn.hidden = false;
    };

    runBtn.addEventListener('click', function () {
      showError('');
      var parsed = B.parseCsv(textEl.value);
      if (!parsed.ok) { showError(parsed.error || 'That text could not be read as a table.'); return; }
      var req = B.toRequestRows(parsed);
      if (req.missing.length) {
        showError('Missing column' + (req.missing.length > 1 ? 's' : '') + ': ' + req.missing.join(', ') + '. Start with a header line: Ligand, Additive, Base, Aryl halide.');
        return;
      }
      if (!req.rows.length) { showError('No rows found. Add at least one line under the header.'); return; }
      var note = req.tooMany ? ' Only the first ' + B.LIMIT + ' of ' + req.count + ' rows were run.' : '';
      runBtn.disabled = true;
      setStatus('Running ' + I.plural(req.rows.length, 'row') + '.');
      var stop = F2F.WidgetFx && F2F.WidgetFx.run ? F2F.WidgetFx.run(['batch']) : function () {};
      fetch(batchUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
        credentials: 'same-origin',
        body: JSON.stringify({ rows: req.rows })
      })
        .then(function (res) {
          return res.json().catch(function () { return null; }).then(function (data) { return { ok: res.ok, status: res.status, data: data }; });
        })
        .then(function (r) {
          if (!r.ok || !r.data || !Array.isArray(r.data.results)) {
            var why = r.data && r.data.error ? r.data.error : 'The server returned an unexpected response';
            if (r.data && r.data.limit) { why += ' (limit ' + r.data.limit + ')'; }
            showError(why + ' (HTTP ' + r.status + ').');
            setStatus('');
            return;
          }
          lastResults = r.data.results;
          renderResults(lastResults, req.rows);
          var s = B.summarize(lastResults);
          setStatus(s.ok + ' predicted' + (s.failed ? ', ' + s.failed + ' with problems' : '') + '; ' + s.predictedFailure + ' flagged as failure.' + note);
        })
        .catch(function () { showError('Could not reach the server. Check your connection and run the batch again.'); setStatus(''); })
        .then(function () { runBtn.disabled = false; stop(); });
    });
  }

  /* ---- Share link ------------------------------------------------------------------ */
  var S = F2F.Share;
  var shareBtn = byId('share-btn');
  if (S && shareBtn && byId('f-ligand')) {
    var optionValues = function () {
      var lists = {};
      KEYS.forEach(function (k) {
        lists[k] = Array.prototype.filter.call(byId('f-' + k).options, function (o) { return o.value; })
          .map(function (o) { return o.value; });
      });
      return lists;
    };
    var lists = optionValues();
    var counts = {};
    KEYS.forEach(function (k) { counts[k] = lists[k].length; });
    var fp = S.fingerprint(lists);
    var shareStatus = byId('share-status'), notice = byId('share-notice');

    var currentPicks = function () {
      var picks = {};
      KEYS.forEach(function (k) {
        var i = lists[k].indexOf(byId('f-' + k).value);
        picks[k] = i >= 0 ? i + 1 : null;
      });
      return picks;
    };
    var say = function (msg) {
      shareStatus.textContent = msg;
      window.setTimeout(function () { if (shareStatus.textContent === msg) { shareStatus.textContent = ''; } }, 3500);
    };
    var copy = function (text) {
      if (navigator.clipboard && navigator.clipboard.writeText) { return navigator.clipboard.writeText(text); }
      return new Promise(function (resolve, reject) {
        var ta = document.createElement('textarea');
        ta.value = text; ta.setAttribute('readonly', ''); ta.style.position = 'fixed'; ta.style.opacity = '0';
        document.body.appendChild(ta); ta.select();
        var ok = false;
        try { ok = document.execCommand('copy'); } catch (e) { ok = false; }
        document.body.removeChild(ta);
        if (ok) { resolve(); } else { reject(new Error('copy failed')); }
      });
    };

    shareBtn.addEventListener('click', function () {
      var picks = currentPicks();
      if (!KEYS.some(function (k) { return picks[k]; })) { say('Choose a value first.'); return; }
      var url = S.buildUrl(window.location.origin + window.location.pathname, picks, fp);
      copy(url).then(function () { say('Link copied.'); }, function () {
        // no clipboard access: put the link in the address bar so it can be copied from there
        try { window.history.replaceState(null, '', url.slice(window.location.origin.length)); } catch (e) { /* ignore */ }
        say('Copy the address bar.');
      });
    });

    // Opening a shared link: apply its choices, but only if it was made for this model.
    var d = S.decode(window.location.search, counts);
    var any = KEYS.some(function (k) { return d.picks[k]; });
    if (any && S.matches(d.key, fp)) {
      KEYS.forEach(function (k) {
        if (!d.picks[k]) { return; }
        var select = byId('f-' + k);
        select.value = lists[k][d.picks[k] - 1];
        select.dispatchEvent(new Event('change', { bubbles: true }));
      });
      notice.textContent = 'Loaded the choices from a shared link.' + (d.problems.length ? ' Some parts of it were not valid and were ignored.' : '');
      notice.hidden = false;
    } else if (any) {
      // The numbers are positions in the option lists, so without a matching key they could mean
      // a different reaction. Say so rather than guess.
      notice.textContent = d.key
        ? 'This link was made for a different version of the model, so its choices may mean something else. Nothing was loaded.'
        : 'This link does not say which version of the model it was made for, so its choices may mean something else. Nothing was loaded.';
      notice.hidden = false;
    } else if (d.problems.length) {
      notice.textContent = 'The choices in this link were not valid, so nothing was loaded.';
      notice.hidden = false;
    }
  }
})();
