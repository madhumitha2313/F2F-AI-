/* Catalytic-cycle diagram for the dashboard's "The reaction" widget.

   A hairline ring of four numbered stages (the Buchwald-Hartwig cycle) with a palladium
   token that travels stage to stage. Around the ring: the aryl halide enters at stage 1,
   the amine (fixed) at stage 2, the base at stage 3 and the product leaves at stage 4.
   The ligand rides with the palladium, and the additive hangs off the cycle on a dashed
   branch labelled "may interfere". After a prediction, small badges show how far the
   model's score moved for each input. The mapping of inputs onto steps is illustrative:
   the model sees category IDs, not mechanism.

   Three layers, so the logic can be tested without a browser:
     - pure helpers: STAGES, captions, influence formatting, the token's path;
     - createPlayer(opts): the autoplay / step state machine. No DOM and no clock: advance
       it with tick(ms). Hand-rolled: one eased glide, and a wait between glides;
     - mount(root, opts): the SVG renderer and its single requestAnimationFrame loop. It
       pauses when the tab is hidden or the widget is off screen.

   Autoplay runs only when motion is allowed (base.html adds the "motion" class only when
   the visitor has NOT asked for reduced motion). Under reduced motion nothing animates:
   the token jumps, the Autoplay button is hidden, and the stages are still clickable.
   No colours, fonts or shadows here: only class names and currentColor (see the .cycle-*
   rules in app.css). */
(function (root) {
  'use strict';

  var SVG_NS = 'http://www.w3.org/2000/svg';
  var DEG = Math.PI / 180;
  var MINUS = '\u2212';
  var DASH = '\u2013';

  /* ---- The four stages: the verified wording, and what acts at each ----------- */
  var STAGES = [
    { key: 'oxidative-addition',    title: 'Oxidative addition',    inputs: ['aryl_halide'],
      text: 'Pd(0) inserts into the aryl-halide bond.' },
    { key: 'amine-coordination',    title: 'Amine coordination',    inputs: [],
      text: 'The amine binds to the Pd(II) complex.' },
    { key: 'deprotonation',         title: 'Deprotonation',         inputs: ['base'],
      text: 'The base removes an N-H proton, giving a palladium amide.' },
    { key: 'reductive-elimination', title: 'Reductive elimination', inputs: [],
      text: 'The C-N bond forms, the product leaves and Pd(0) is regenerated.' }
  ];
  var N = STAGES.length;

  // The model's four inputs, in the order ties are broken.
  var INPUT_ORDER = ['aryl_halide', 'ligand', 'base', 'additive'];
  var INPUT_NAMES = { aryl_halide: 'Aryl halide', ligand: 'Ligand', base: 'Base', additive: 'Additive' };

  // Where an input is drawn: a stage index, on the travelling token, or on the side branch.
  function stageForInput(key) {
    if (key === 'aryl_halide') { return 0; }
    if (key === 'base') { return 2; }
    if (key === 'ligand') { return 'token'; }
    if (key === 'additive') { return 'side'; }
    return null;   // the amine is fixed; anything else is not an input
  }

  function wrapStage(i) {
    var n = Number(i);
    if (!isFinite(n)) { n = 0; }
    return ((Math.floor(n) % N) + N) % N;
  }
  function nextStage(i) { return wrapStage(wrapStage(i) + 1); }
  function prevStage(i) { return wrapStage(wrapStage(i) - 1); }

  // Signed distance (in stages) from `from` to `to` the short way round; forward on a tie.
  function shortestDelta(from, to) {
    var d = (((to - from) % N) + N) % N;
    return d > N / 2 ? d - N : d;
  }

  function easeInOut(x) { return 0.5 * (1 - Math.cos(Math.PI * x)); }
  function wrap01(x) { return ((x % 1) + 1) % 1; }

  /* ---- Influence: how far each input moved the model's score ------------------ */
  function formatPush(x) {
    if (typeof x !== 'number' || !isFinite(x)) { return ''; }
    var r = Math.round(Math.abs(x) * 100) / 100;
    if (r === 0) { return '0.00'; }
    return (x > 0 ? '+' : MINUS) + r.toFixed(2);
  }

  function pushOf(entry) {
    return entry && typeof entry.push === 'number' && isFinite(entry.push) ? entry.push : null;
  }

  // The input with the largest absolute push; ties go to the earlier input.
  function topInfluence(influence) {
    if (!influence || typeof influence !== 'object') { return null; }
    var best = null, bestAbs = -1;
    INPUT_ORDER.forEach(function (key) {
      var p = pushOf(influence[key]);
      if (p !== null && Math.abs(p) > bestAbs) { best = key; bestAbs = Math.abs(p); }
    });
    return best;
  }

  function directionOf(entry) {
    if (entry && (entry.direction === 'failure' || entry.direction === 'success')) { return entry.direction; }
    var p = pushOf(entry);
    return p !== null && p > 0 ? 'failure' : 'success';
  }

  /* ---- Captions ---------------------------------------------------------------- */
  function cleanStr(s) { return typeof s === 'string' && s.trim() ? s.trim() : ''; }
  function pickOf(x) {
    var o = x && typeof x === 'object' ? x : {};
    return { name: cleanStr(o.name), halogen: cleanStr(o.halogen) };
  }
  function normPicks(p) {
    p = p && typeof p === 'object' ? p : {};
    return { aryl: pickOf(p.aryl), ligand: pickOf(p.ligand), base: pickOf(p.base), additive: pickOf(p.additive) };
  }

  function detailFor(index, picks) {
    if (index === 0) {
      var a = picks.aryl;
      var bond = a.halogen ? 'Ar' + DASH + a.halogen : '';
      if (a.name && bond) { return 'Shown here: your aryl halide, ' + a.name + ' (' + bond + ').'; }
      if (a.name) { return 'Shown here: your aryl halide, ' + a.name + '.'; }
      if (bond) { return 'Shown here: your aryl halide (' + bond + ').'; }
      return 'Shown here: your aryl halide.';
    }
    if (index === 1) { return 'Shown here: the amine, fixed as 4-methylaniline.'; }
    if (index === 2) {
      return picks.base.name ? 'Shown here: your base, ' + picks.base.name + '.' : 'Shown here: your base.';
    }
    return 'Shown here: the product leaving.';
  }

  // "Largest push" is said at the stage it belongs to; the ligand and additive belong to
  // no single stage, so it is said at every stage.
  function largestLine(index, influence) {
    var top = topInfluence(influence);
    if (!top) { return ''; }
    var where = stageForInput(top);
    if (where === null || (typeof where === 'number' && where !== index)) { return ''; }
    var entry = influence[top];
    return 'Largest push: ' + INPUT_NAMES[top] + ', ' + formatPush(pushOf(entry)) + ' toward ' + directionOf(entry) + '.';
  }

  function describeStage(index, picks, influence) {
    if (typeof index !== 'number' || index !== Math.floor(index) || index < 0 || index >= N) {
      throw new RangeError('no stage ' + index + ' (0 to ' + (N - 1) + ')');
    }
    var s = STAGES[index];
    var detail = detailFor(index, normPicks(picks));
    var largest = largestLine(index, influence);
    return {
      index: index, number: index + 1, title: s.title, text: s.text, detail: detail, largest: largest,
      caption: (index + 1) + '. ' + s.title + '. ' + s.text + ' ' + detail + (largest ? ' ' + largest : '')
    };
  }

  /* ---- Geometry: two fixed scenes, scaled to the widget ------------------------
     "wide" is a landscape ring with the stage names inside it; "narrow" is a compact
     portrait ring (stage numbers only) for a phone-width widget. Every coordinate is in
     viewBox units, so text stays about 10px at the widget's natural width. */
  function tokenPoint(progress, g) {
    var a = (-90 + 360 * wrap01(progress)) * DEG;   // stage 1 at the top, clockwise
    return { x: g.ring.cx + g.ring.rx * Math.cos(a), y: g.ring.cy + g.ring.ry * Math.sin(a) };
  }

  var GEOMETRY = {
    wide: {
      w: 560, h: 310, nodeR: 14, tokenR: 12,
      ring: { cx: 280, cy: 155, rx: 130, ry: 80 },
      titles: [
        { x: 280, y: 101, anchor: 'middle', lines: ['Oxidative', 'addition'] },
        { x: 390, y: 150, anchor: 'end',    lines: ['Amine', 'coordination'] },
        { x: 280, y: 211, anchor: 'middle', lines: ['Deprotonation'] },
        { x: 170, y: 150, anchor: 'start',  lines: ['Reductive', 'elimination'] }
      ],
      hub: { x: 280, y: 148 },
      aryl: { from: { x: 104, y: 48 }, label: { x: 14, y: 28, anchor: 'start' }, badge: { x: 196, y: 34 } },
      amine: { from: { x: 546, y: 155 }, label: { x: 492, y: 143, anchor: 'middle' } },
      base: { from: { x: 280, y: 298 }, label: { x: 294, y: 294, anchor: 'start' }, badge: { x: 362, y: 283 } },
      product: { to: { x: 22, y: 155 }, label: { x: 76, y: 143, anchor: 'middle' } },
      side: { label: { x: 480, y: 26, anchor: 'middle' }, from: { x: 452, y: 50 }, badge: { x: 436, y: 84 } }
    },
    narrow: {
      w: 330, h: 380, nodeR: 14, tokenR: 12,
      ring: { cx: 134, cy: 206, rx: 76, ry: 76 },
      titles: null,
      hub: { x: 134, y: 200 },
      aryl: { from: { x: 34, y: 78 }, label: { x: 8, y: 24, anchor: 'start' }, badge: { x: 112, y: 70 } },
      amine: { from: { x: 324, y: 206 }, label: { x: 282, y: 194, anchor: 'middle' } },
      base: { from: { x: 134, y: 362 }, label: { x: 146, y: 358, anchor: 'start' }, badge: { x: 212, y: 347 } },
      product: { to: { x: 16, y: 262 }, label: { x: 8, y: 278, anchor: 'start' } },
      side: { label: { x: 322, y: 24, anchor: 'end' }, from: { x: 290, y: 48 }, badge: { x: 290, y: 100 } }
    }
  };
  ['wide', 'narrow'].forEach(function (mode) {
    var g = GEOMETRY[mode];
    g.nodes = [0, 1, 2, 3].map(function (i) { return tokenPoint(i / N, g); });
    g.side.to = tokenPoint(0.125, g);   // where the side branch meets the ring
  });

  function modeFor(width) {
    return typeof width === 'number' && width > 0 && width < 460 ? 'narrow' : 'wide';
  }

  /* ---- Player: autoplay and step state machine ---------------------------------
     `want` is what the person asked for (autoplay on or off); whether it actually runs
     also depends on motion being allowed and the widget and tab being visible. Hiding
     the tab pauses without losing the wait it had left. A glide that has started always
     finishes. Choosing a stage mid-glide starts from where the token is, so it never
     jumps. */
  function createPlayer(opts) {
    opts = opts || {};
    var interval = opts.interval > 0 ? opts.interval : 2400;    // start of one glide to the next
    var tween = opts.tween > 0 ? Math.min(opts.tween, interval) : 700;
    var env = { motion: !!opts.motion, visible: opts.visible !== false, tabVisible: opts.tabVisible !== false };
    var want = opts.autoplay !== false;
    var stage = 0, pos = 0, from = 0, delta = 0, t = 0, moving = false, idle = 0, byUser = false;

    function running() { return want && env.motion && env.visible && env.tabVisible; }

    function begin(target, user) {
      target = wrapStage(target);
      var d = shortestDelta(pos, target);
      stage = target;
      byUser = user;
      idle = 0;
      if (!env.motion || Math.abs(d) < 1e-9) { pos = target; moving = false; t = 0; return; }
      from = pos; delta = d; t = 0; moving = true;
    }

    return {
      tick: function (dt) {
        if (!(dt > 0)) { return; }
        if (moving) {
          t += dt;
          if (t >= tween) { idle = t - tween; moving = false; t = 0; pos = stage; }
          else { pos = from + delta * easeInOut(t / tween); }
          return;
        }
        if (running()) {
          idle += dt;
          if (idle >= interval - tween) { begin(nextStage(stage), false); }
        }
      },
      play: function () { if (!want) { idle = 0; } want = true; },
      pause: function () { want = false; },
      step: function () { want = false; begin(nextStage(stage), true); },
      select: function (i) { want = false; begin(i, true); },
      setEnv: function (e) {
        if (e && 'motion' in e) { env.motion = !!e.motion; }
        if (e && 'visible' in e) { env.visible = !!e.visible; }
        if (e && 'tabVisible' in e) { env.tabVisible = !!e.tabVisible; }
        if (!env.motion) { moving = false; t = 0; pos = stage; }
      },
      state: function () {
        return {
          stage: stage, pos: pos, moving: moving, playing: want && env.motion, running: running(),
          progress: wrap01(pos / N), live: byUser ? 'polite' : 'off'
        };
      }
    };
  }

  /* ---- Renderer ----------------------------------------------------------------- */
  function svgEl(doc, tag, attrs) {
    var node = doc.createElementNS(SVG_NS, tag);
    if (attrs) { Object.keys(attrs).forEach(function (k) { node.setAttribute(k, String(attrs[k])); }); }
    return node;
  }

  function textEl(doc, parent, cls, x, y, str, anchor) {
    var node = svgEl(doc, 'text', { 'class': cls, x: x, y: y });
    if (anchor) { node.setAttribute('text-anchor', anchor); }
    node.textContent = str || '';
    parent.appendChild(node);
    return node;
  }

  // The point `gap` short of `node`, on the line towards `from`.
  function toward(node, from, gap) {
    var dx = from.x - node.x, dy = from.y - node.y, d = Math.sqrt(dx * dx + dy * dy) || 1;
    return { x: node.x + dx / d * gap, y: node.y + dy / d * gap };
  }

  // A line with an arrowhead at its end.
  function arrow(doc, parent, a, b) {
    parent.appendChild(svgEl(doc, 'line', { 'class': 'cycle-line', x1: a.x, y1: a.y, x2: b.x, y2: b.y }));
    var dx = b.x - a.x, dy = b.y - a.y, d = Math.sqrt(dx * dx + dy * dy) || 1, ux = dx / d, uy = dy / d;
    var bx = b.x - ux * 8, by = b.y - uy * 8;
    parent.appendChild(svgEl(doc, 'polygon', {
      'class': 'cycle-head',
      points: b.x + ',' + b.y + ' ' + (bx - uy * 3.5) + ',' + (by + ux * 3.5) + ' ' + (bx + uy * 3.5) + ',' + (by - ux * 3.5)
    }));
  }

  function build(doc, g) {
    var refs = { nodes: [], titles: [], badges: {} };
    var svg = svgEl(doc, 'svg', {
      'class': 'cycle-svg', viewBox: '0 0 ' + g.w + ' ' + g.h, role: 'group', focusable: 'false',
      'aria-label': 'Catalytic cycle in four steps: oxidative addition, amine coordination, deprotonation, reductive elimination'
    });
    refs.svg = svg;
    var r = g.ring;

    svg.appendChild(svgEl(doc, 'ellipse', { 'class': 'cycle-ring-path', cx: r.cx, cy: r.cy, rx: r.rx, ry: r.ry }));
    // Small chevrons between the stages show the way round (clockwise).
    [0.125, 0.375, 0.625, 0.875].forEach(function (p) {
      var a = (-90 + 360 * p) * DEG, pt = tokenPoint(p, g);
      var tx = -r.rx * Math.sin(a), ty = r.ry * Math.cos(a), d = Math.sqrt(tx * tx + ty * ty), ux = tx / d, uy = ty / d;
      svg.appendChild(svgEl(doc, 'polygon', {
        'class': 'cycle-chevron',
        points: (pt.x + ux * 5) + ',' + (pt.y + uy * 5) + ' ' + (pt.x - ux * 4 - uy * 4) + ',' + (pt.y - uy * 4 + ux * 4) + ' ' + (pt.x - ux * 4 + uy * 4) + ',' + (pt.y - uy * 4 - ux * 4)
      }));
    });

    // The additive: off the cycle, on a dashed branch that meets the ring.
    var side = g.side;
    svg.appendChild(svgEl(doc, 'line', { 'class': 'cycle-side-line', x1: side.from.x, y1: side.from.y, x2: side.to.x, y2: side.to.y }));
    svg.appendChild(svgEl(doc, 'circle', { 'class': 'cycle-side-dot', cx: side.to.x, cy: side.to.y, r: 3 }));
    refs.sideName = textEl(doc, svg, 'cycle-label', side.label.x, side.label.y, '', side.label.anchor);
    textEl(doc, svg, 'cycle-sub', side.label.x, side.label.y + 13, 'may interfere', side.label.anchor);

    // Reagents in, product out.
    var nodes = g.nodes, gap = g.nodeR + 3;
    arrow(doc, svg, g.aryl.from, toward(nodes[0], g.aryl.from, gap));
    refs.arylBond = textEl(doc, svg, 'cycle-label', g.aryl.label.x, g.aryl.label.y, '', g.aryl.label.anchor);
    refs.arylName = textEl(doc, svg, 'cycle-sub', g.aryl.label.x, g.aryl.label.y + 13, '', g.aryl.label.anchor);
    arrow(doc, svg, g.amine.from, toward(nodes[1], g.amine.from, gap));
    textEl(doc, svg, 'cycle-label', g.amine.label.x, g.amine.label.y, '4-methylaniline', g.amine.label.anchor);
    arrow(doc, svg, g.base.from, toward(nodes[2], g.base.from, gap));
    refs.baseName = textEl(doc, svg, 'cycle-label', g.base.label.x, g.base.label.y, '', g.base.label.anchor);
    arrow(doc, svg, toward(nodes[3], g.product.to, gap), g.product.to);
    textEl(doc, svg, 'cycle-label', g.product.label.x, g.product.label.y, 'Product', g.product.label.anchor);

    // Stage names inside the ring (wide layout only).
    if (g.titles) {
      g.titles.forEach(function (tt, i) {
        var node = svgEl(doc, 'text', { 'class': 'cycle-node-title', x: tt.x, y: tt.y, 'text-anchor': tt.anchor });
        tt.lines.forEach(function (line, k) {
          var span = svgEl(doc, 'tspan', { x: tt.x, dy: k ? 12 : 0 });
          span.textContent = line;
          node.appendChild(span);
        });
        svg.appendChild(node);
        refs.titles.push(node);
      });
    }

    // The catalyst hub: Pd and the ligand's name, in the middle of the ring.
    var hub = svgEl(doc, 'g', { 'class': 'cycle-hub' });
    refs.hubTitle = svgEl(doc, 'title');
    hub.appendChild(refs.hubTitle);
    textEl(doc, hub, 'cycle-hub-pd', g.hub.x, g.hub.y, 'Pd', 'middle');
    refs.hubName = textEl(doc, hub, 'cycle-hub-name', g.hub.x, g.hub.y + 14, '', 'middle');
    svg.appendChild(hub);

    // Stage nodes: keyboard-operable buttons.
    for (var i = 0; i < N; i++) {
      var n = svgEl(doc, 'g', {
        'class': 'cycle-node', role: 'button', tabindex: 0, 'data-stage': i,
        'aria-label': 'Step ' + (i + 1) + ': ' + STAGES[i].title, 'aria-pressed': 'false'
      });
      var tip = svgEl(doc, 'title');
      tip.textContent = 'Step ' + (i + 1) + ': ' + STAGES[i].title;
      n.appendChild(tip);
      n.appendChild(svgEl(doc, 'circle', { 'class': 'cycle-node-focus', cx: nodes[i].x, cy: nodes[i].y, r: g.nodeR + 5 }));
      n.appendChild(svgEl(doc, 'circle', { 'class': 'cycle-node-dot', cx: nodes[i].x, cy: nodes[i].y, r: g.nodeR }));
      textEl(doc, n, 'cycle-node-num', nodes[i].x, nodes[i].y, String(i + 1), 'middle');
      svg.appendChild(n);
      refs.nodes.push(n);
    }

    // The travelling token.
    var token = svgEl(doc, 'g', { 'class': 'cycle-token', 'aria-hidden': 'true' });
    token.appendChild(svgEl(doc, 'circle', { 'class': 'cycle-token-dot', r: g.tokenR }));
    textEl(doc, token, 'cycle-token-text', 0, 0, 'Pd', 'middle');
    svg.appendChild(token);
    refs.token = token;

    // Influence badges, drawn last so nothing covers them. Hidden until there is a push.
    var spots = { aryl_halide: g.aryl.badge, ligand: { x: g.hub.x, y: g.hub.y + 32 }, base: g.base.badge, additive: g.side.badge };
    INPUT_ORDER.forEach(function (key) {
      var b = svgEl(doc, 'g', { 'class': 'cycle-badge', 'data-input': key, 'aria-hidden': 'true',
        transform: 'translate(' + spots[key].x + ' ' + spots[key].y + ')' });
      b.appendChild(svgEl(doc, 'rect', { 'class': 'cycle-badge-top', x: -26, y: -11, width: 52, height: 22 }));
      b.appendChild(svgEl(doc, 'rect', { 'class': 'cycle-badge-box', x: -23, y: -8, width: 46, height: 16 }));
      refs.badges[key] = { g: b, text: textEl(doc, b, 'cycle-badge-text', 0, 0, '', 'middle') };
      svg.appendChild(b);
    });
    return refs;
  }

  function mount(rootEl, opts) {
    opts = opts || {};
    var doc = rootEl && rootEl.ownerDocument;
    if (!doc || !doc.createElementNS) { return null; }
    var probe = doc.createElementNS(SVG_NS, 'svg');
    if (!probe || typeof probe.createSVGRect !== 'function') { return null; }
    var win = doc.defaultView || root;

    var motion = doc.documentElement.classList.contains('motion');
    var player = createPlayer({ motion: motion, autoplay: opts.autoplay !== false, interval: opts.interval, tween: opts.tween, tabVisible: !doc.hidden });
    var picks = normPicks(null), influence = null;
    var mode = modeFor(rootEl.getBoundingClientRect().width);
    var refs = null, raf = 0, last = 0, destroyed = false, shownStage = -1;
    var io = null, ro = null;

    rootEl.classList.add('cycle');
    var figure = doc.createElement('div');
    figure.className = 'cycle-figure';
    var controls = doc.createElement('div');
    controls.className = 'cycle-controls';
    var auto = doc.createElement('button');
    auto.type = 'button'; auto.className = 'btn btn-ghost'; auto.textContent = 'Autoplay';
    auto.hidden = !motion;
    var next = doc.createElement('button');
    next.type = 'button'; next.className = 'btn btn-ghost'; next.textContent = 'Next step';
    controls.appendChild(auto); controls.appendChild(next);
    var note = doc.createElement('p');
    note.className = 'cycle-note';
    note.textContent = 'Badges show how far the model\u2019s score moved. The mapping onto steps is illustrative: the model sees category IDs, not mechanism.';
    var caption = doc.createElement('p');
    caption.className = 'cycle-caption';
    caption.setAttribute('data-cycle-caption', '');
    caption.setAttribute('aria-live', 'off');
    var sr = doc.createElement('ul');
    sr.className = 'cycle-sr sr-only';
    sr.setAttribute('data-cycle-influence', '');
    [figure, controls, caption, note, sr].forEach(function (n) { rootEl.appendChild(n); });

    function geometry() { return GEOMETRY[mode]; }

    function paintToken(s) {
      var p = tokenPoint(s.progress, geometry());
      refs.token.setAttribute('transform', 'translate(' + p.x.toFixed(2) + ' ' + p.y.toFixed(2) + ')');
    }

    function paintCaption(s) {
      var d = describeStage(s.stage, picks, influence);
      caption.setAttribute('aria-live', s.live);
      caption.textContent = '';
      var title = doc.createElement('span');
      title.className = 'cycle-caption-title';
      title.textContent = d.number + '. ' + d.title;
      caption.appendChild(title);
      // Plain spaces between the parts, so a screen reader does not run the title into the text.
      caption.appendChild(doc.createTextNode(' ' + d.text + ' ' + d.detail));
      if (d.largest) {
        var push = doc.createElement('span');
        push.className = 'cycle-caption-push';
        push.textContent = d.largest;
        caption.appendChild(doc.createTextNode(' '));
        caption.appendChild(push);
      }
    }

    function paint() {
      if (!refs) { return; }
      var s = player.state();
      var halogen = picks.aryl.halogen;
      refs.arylBond.textContent = 'Ar' + DASH + (halogen || 'X');
      refs.arylName.textContent = picks.aryl.name || 'Aryl halide';
      refs.baseName.textContent = picks.base.name || 'Base';
      refs.sideName.textContent = picks.additive.name || 'Additive';
      refs.hubName.textContent = picks.ligand.name || 'Ligand';
      refs.hubTitle.textContent = 'Pd \u00b7 ' + (picks.ligand.name || 'Ligand');

      var top = topInfluence(influence);
      sr.textContent = '';
      INPUT_ORDER.forEach(function (key) {
        var b = refs.badges[key], p = influence ? pushOf(influence[key]) : null;
        var on = p !== null;
        b.g.setAttribute('class', 'cycle-badge' + (on ? ' is-on' : '') + (on && key === top ? ' is-top' : ''));
        if (on) {
          b.g.setAttribute('data-dir', directionOf(influence[key]));
          b.text.textContent = formatPush(p);
          var li = doc.createElement('li');
          li.textContent = INPUT_NAMES[key] + ': ' + formatPush(p) + ', toward ' + directionOf(influence[key]) + '.' + (key === top ? ' Largest push.' : '');
          sr.appendChild(li);
        } else { b.g.removeAttribute('data-dir'); b.text.textContent = ''; }
      });

      for (var i = 0; i < N; i++) {
        var active = i === s.stage;
        refs.nodes[i].setAttribute('class', 'cycle-node' + (active ? ' is-active' : ''));
        refs.nodes[i].setAttribute('aria-pressed', active ? 'true' : 'false');
        if (active) { refs.nodes[i].setAttribute('aria-current', 'step'); } else { refs.nodes[i].removeAttribute('aria-current'); }
        if (refs.titles[i]) { refs.titles[i].setAttribute('class', 'cycle-node-title' + (active ? ' is-active' : '')); }
      }
      auto.setAttribute('aria-pressed', s.playing ? 'true' : 'false');
      auto.hidden = !motion;
      paintCaption(s);
      paintToken(s);
      shownStage = s.stage;
    }

    function rebuild() {
      // The stylesheet follows the engine's own layout choice (the caption needs more room
      // when the compact layout narrows it).
      rootEl.classList.toggle('is-narrow', mode === 'narrow');
      var focused = -1;
      if (refs) {
        focused = refs.nodes.indexOf(doc.activeElement);
        figure.textContent = '';
      }
      refs = build(doc, geometry());
      figure.appendChild(refs.svg);
      paint();
      if (focused >= 0) { refs.nodes[focused].focus(); }
    }

    function announce(user) {
      try {
        rootEl.dispatchEvent(new win.CustomEvent('f2f:cycle-stage', { bubbles: true, detail: { stage: player.state().stage, user: !!user } }));
      } catch (e) { /* CustomEvent is optional */ }
    }

    function frame(now) {
      raf = 0;
      var dt = last ? Math.min(now - last, 100) : 0;
      last = now;
      player.tick(dt);
      var s = player.state();
      if (s.stage !== shownStage) { paint(); announce(false); } else { paintToken(s); }
      if (s.running || s.moving) { raf = win.requestAnimationFrame(frame); } else { last = 0; }
    }
    function kick() {
      if (!raf && !destroyed) { last = 0; raf = win.requestAnimationFrame(frame); }
    }
    // A person did something: apply it, redraw at once, and keep the loop going if needed.
    function act(fn) { fn(); paint(); announce(true); kick(); }

    function onNode(ev) {
      var n = ev.target.closest ? ev.target.closest('.cycle-node') : null;
      if (n) { act(function () { player.select(Number(n.getAttribute('data-stage'))); }); }
    }
    function onKey(ev) {
      if (ev.key !== 'Enter' && ev.key !== ' ' && ev.key !== 'Spacebar') { return; }
      var n = ev.target.closest ? ev.target.closest('.cycle-node') : null;
      if (!n) { return; }
      ev.preventDefault();
      act(function () { player.select(Number(n.getAttribute('data-stage'))); });
    }
    function onAuto() {
      var s = player.state();
      // Autoplay is a switch, not a step: it does not change the stage or say anything aloud.
      if (s.playing) { player.pause(); } else { player.play(); }
      paint(); kick();
    }
    function onNext() { act(function () { player.step(); }); }
    function onVis() { player.setEnv({ tabVisible: !doc.hidden }); kick(); }

    figure.addEventListener('click', onNode);
    figure.addEventListener('keydown', onKey);
    auto.addEventListener('click', onAuto);
    next.addEventListener('click', onNext);
    doc.addEventListener('visibilitychange', onVis);
    if ('IntersectionObserver' in win) {
      io = new win.IntersectionObserver(function (entries) {
        player.setEnv({ visible: entries[0].isIntersecting });
        kick();
      });
      io.observe(rootEl);
    }
    if ('ResizeObserver' in win) {
      ro = new win.ResizeObserver(function () {
        var w = rootEl.getBoundingClientRect().width;
        if (!w) { return; }
        var m = modeFor(w);
        if (m !== mode) { mode = m; rebuild(); }
      });
      ro.observe(rootEl);
    }

    rebuild();
    kick();

    return {
      setPicks: function (p) { picks = normPicks(p); paint(); },
      setInfluence: function (x) { influence = x && typeof x === 'object' ? x : null; paint(); },
      play: function () { player.play(); paint(); kick(); },
      pause: function () { player.pause(); paint(); },
      step: onNext,
      select: function (i) { act(function () { player.select(i); }); },
      state: function () { var s = player.state(); s.mode = mode; return s; },
      destroy: function () {
        destroyed = true;
        if (raf) { win.cancelAnimationFrame(raf); raf = 0; }
        if (io) { io.disconnect(); }
        if (ro) { ro.disconnect(); }
        doc.removeEventListener('visibilitychange', onVis);
        figure.removeEventListener('click', onNode);
        figure.removeEventListener('keydown', onKey);
        auto.removeEventListener('click', onAuto);
        next.removeEventListener('click', onNext);
        [figure, controls, caption, note, sr].forEach(function (n) { if (n.parentNode) { n.parentNode.removeChild(n); } });
        rootEl.classList.remove('cycle', 'is-narrow');
      }
    };
  }

  var api = {
    STAGES: STAGES, INPUT_ORDER: INPUT_ORDER, INPUT_NAMES: INPUT_NAMES, GEOMETRY: GEOMETRY,
    stageForInput: stageForInput, nextStage: nextStage, prevStage: prevStage, shortestDelta: shortestDelta,
    easeInOut: easeInOut, formatPush: formatPush, topInfluence: topInfluence, describeStage: describeStage,
    tokenPoint: tokenPoint, modeFor: modeFor, createPlayer: createPlayer, mount: mount
  };
  if (typeof module === 'object' && module.exports) { module.exports = api; }
  else { (root.F2F = root.F2F || {}).ReactionCycle = api; }
})(typeof window !== 'undefined' ? window : globalThis);
