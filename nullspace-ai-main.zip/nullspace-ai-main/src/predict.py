# -*- coding: utf-8 -*-
"""
Stage: Live Predictions (architecture slide stage 9)

Loads the trained best model + encoders + scaler once, and exposes a
single `predict_failure()` function that both the CLI below and the
Flask API (api/app.py) call. Keeping this logic in one place means the
API can never drift from what was actually trained and evaluated.

At load time the model is re-scored against a stored known-answer check
(models/load_check.json, see load_check.py) so an environment that reads
the model wrongly is refused instead of quietly serving wrong numbers.

CLI usage:
    python src/predict.py --ligand L1 --additive A3 --base B2 --aryl_halide AH5
"""

import argparse
import json
import logging
import math
import os
import sys

import joblib

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import config as cfg
import load_check
from load_check import ModelLoadError

log = logging.getLogger("f2f.predict")


def _shorten(value: str, limit: int = 40) -> str:
    return value if len(value) <= limit else value[: limit - 3] + "..."


class UnknownValueError(ValueError):
    """A value the model never saw in training. explain() refuses it (predict() would
    swap in the first known value and warn), because an explanation of a different
    reaction than the one asked about is worse than none."""

    def __init__(self, key: str, value: str):
        self.key = key.lower()
        self.value = value
        super().__init__(
            f"'{self.key}': '{_shorten(value)}' was not seen during training, so the "
            f"model has no information about it."
        )


def _load_artifact(path: str, label: str):
    try:
        return joblib.load(path)
    except Exception as e:  # noqa: BLE001 - unpickling can raise almost anything
        raise ModelLoadError(
            f"Could not load the {label} at {path} ({type(e).__name__}: {e}). "
            f"This environment: {load_check.environment_summary()}. The artifacts were "
            f"written by the versions pinned in api/requirements.txt."
        ) from e


class FailurePredictor:
    """Loads model artifacts once; call .predict(...) many times."""

    def __init__(self, verify: bool = True):
        for path, label in [
            (cfg.BEST_MODEL_PATH, "best model"),
            (cfg.ENCODERS_PATH, "label encoders"),
            (cfg.SCALER_PATH, "scaler"),
            (cfg.MODEL_CONFIG_PATH, "model config"),
        ]:
            if not os.path.exists(path):
                raise FileNotFoundError(
                    f"Missing {label} at {path}. Run src/preprocess.py then "
                    f"src/train.py before serving predictions."
                )

        self.model = _load_artifact(cfg.BEST_MODEL_PATH, "best model")
        self.encoders = _load_artifact(cfg.ENCODERS_PATH, "label encoders")
        self.scaler = _load_artifact(cfg.SCALER_PATH, "scaler")
        with open(cfg.MODEL_CONFIG_PATH) as f:
            self.model_config = json.load(f)

        # Refuse to serve a model this environment reads wrongly (raises
        # ModelLoadError); missing/stale checks only warn.
        if verify:
            self.load_check = load_check.verify(
                self._score, cfg.BEST_MODEL_PATH, cfg.LOAD_CHECK_PATH
            )
            if self.load_check["status"] != "passed":
                log.warning("Model load check %s: %s",
                            self.load_check["status"], self.load_check["detail"])
        else:
            self.load_check = {"status": "skipped", "detail": "verification disabled"}

    def _score(self, encoded_rows) -> list:
        """Failure probability for each row of label-encoded features."""
        import pandas as pd
        X = pd.DataFrame(encoded_rows, columns=cfg.FEATURE_COLS)
        if self.model_config.get("use_scaled_input"):
            X = self.scaler.transform(X)
        return [float(p) for p in self.model.predict_proba(X)[:, 1]]

    def predict(self, ligand: str, additive: str, base: str, aryl_halide: str) -> dict:
        """
        Returns:
            {
              "prediction": "Failure" | "Success",
              "failure_probability": float,   # 0-1
              "confidence": float,             # 0-1, probability of the predicted class
              "model_used": str,
              "warnings": [str, ...]           # e.g. unseen category
            }
        """
        raw_values = {
            "Ligand": ligand, "Additive": additive,
            "Base": base, "Aryl_halide": aryl_halide,
        }

        warnings = []
        encoded = {}
        for col in cfg.FEATURE_COLS:
            le = self.encoders[col]
            val = str(raw_values[col])
            if val not in le.classes_:
                fallback = str(le.classes_[0])
                warnings.append(
                    f"'{_shorten(val)}' was not seen during training for '{col}', so the "
                    f"model has no information about it. This prediction was made with the "
                    f"first known value instead ('{_shorten(fallback)}', first in alphabetical "
                    f"order) and does not reflect your input. Do not rely on it."
                )
                val = fallback
            encoded[col] = le.transform([val])[0]

        prob_failure = self._score([[encoded[c] for c in cfg.FEATURE_COLS]])[0]
        prediction = "Failure" if prob_failure >= 0.5 else "Success"
        confidence = prob_failure if prediction == "Failure" else 1 - prob_failure

        return {
            "prediction": prediction,
            "failure_probability": round(prob_failure, 4),
            "confidence": round(confidence, 4),
            "model_used": self.model_config.get("best_model", "unknown"),
            "warnings": warnings,
        }

    # How much lower a swapped combination's failure probability must be to be worth
    # suggesting, and how many suggestions to return.
    MIN_IMPROVEMENT = 0.05
    MAX_ALTERNATIVES = 5

    def explain(self, ligand: str, additive: str, base: str, aryl_halide: str) -> dict:
        """
        Why the model scored one reaction the way it did, and what to change.

        Works in raw SMILES only; the API adds the friendly "Ligand 2" names.
        Raises UnknownValueError for a value the model never saw (unlike predict(),
        it never substitutes another value).

        Returns, for an XGBoost model:
            {
              "supported": True,
              "model_used": str,
              "prediction": "Failure" | "Success",
              "failure_probability": float,    # 4 dp
              "baseline_probability": float,   # 4 dp: the model's score before any input is known
              "contributions": [               # 4 items, largest push first
                {"key", "input", "value", "push" (log-odds, 4 dp), "direction": "failure"|"success"}
              ],
              "alternatives": [                # 0..5 one-input swaps, lowest failure probability first
                {"key", "input", "to_value", "failure_probability", "change", "flips"}
              ]
            }
        The four pushes plus the baseline (in log-odds) add up to the model's own raw
        score: they are exact tree-SHAP contributions, not an approximation. They say how
        the model weighed each choice, not why the chemistry behaves that way.

        Any other model gets {"supported": False, "reason", "model_used", "prediction",
        "failure_probability"}.
        """
        raw_values = {
            "Ligand": ligand, "Additive": additive,
            "Base": base, "Aryl_halide": aryl_halide,
        }
        values, encoded = [], []
        for col in cfg.FEATURE_COLS:
            le = self.encoders[col]
            val = str(raw_values[col])
            if val not in le.classes_:
                raise UnknownValueError(col, val)
            values.append(val)
            encoded.append(int(le.transform([val])[0]))

        prob = self._score([encoded])[0]
        prediction = "Failure" if prob >= 0.5 else "Success"
        model_used = self.model_config.get("best_model", "unknown")
        result = {
            "model_used": model_used,
            "prediction": prediction,
            "failure_probability": round(prob, 4),
        }

        # Contributions come from the trained booster; only XGBoost has one, and only on
        # unscaled input (the booster then sees exactly the columns it was trained on).
        if getattr(self.model, "get_booster", None) is None or self.model_config.get("use_scaled_input"):
            result["supported"] = False
            result["reason"] = (
                f"Per-input contributions are only available for XGBoost models; "
                f"this deployment serves {model_used}."
            )
            return result

        import pandas as pd
        import xgboost as xgb

        X = pd.DataFrame([encoded], columns=cfg.FEATURE_COLS)
        contribs = self.model.get_booster().predict(xgb.DMatrix(X), pred_contribs=True)[0]
        bias = float(contribs[len(cfg.FEATURE_COLS)])   # the last column is the bias term

        contributions = []
        for col, val, c in zip(cfg.FEATURE_COLS, values, contribs):
            push = round(float(c), 4)
            contributions.append({
                "key": col.lower(), "input": col.replace("_", " "), "value": val,
                "push": push, "direction": "failure" if push > 0 else "success",
            })
        contributions.sort(key=lambda c: -abs(c["push"]))   # stable: ties keep feature order

        # Every one-input swap (4 + 22 + 3 + 15 minus the four current values), scored in one batch.
        rows, swaps = [], []
        for j, col in enumerate(cfg.FEATURE_COLS):
            classes = [str(c) for c in self.encoders[col].classes_]
            for v, name in enumerate(classes):
                if v == encoded[j]:
                    continue
                row = list(encoded)
                row[j] = v
                rows.append(row)
                swaps.append((col, name))
        scores = self._score(rows) if rows else []

        alternatives = [
            {
                "key": col.lower(), "input": col.replace("_", " "), "to_value": name,
                "failure_probability": round(p, 4), "change": round(p - prob, 4),
                "flips": bool(p < 0.5 <= prob),
            }
            for (col, name), p in sorted(zip(swaps, scores), key=lambda t: t[1])
            if p <= prob - self.MIN_IMPROVEMENT
        ][: self.MAX_ALTERNATIVES]

        result.update({
            "supported": True,
            "baseline_probability": round(1 / (1 + math.exp(-bias)), 4),
            "contributions": contributions,
            "alternatives": alternatives,
        })
        return result


def main():
    parser = argparse.ArgumentParser(description="Predict failure risk for a single reaction.")
    parser.add_argument("--ligand", required=True)
    parser.add_argument("--additive", required=True)
    parser.add_argument("--base", required=True)
    parser.add_argument("--aryl_halide", required=True)
    args = parser.parse_args()

    try:
        predictor = FailurePredictor()
    except ModelLoadError as e:
        print(f"ERROR: {e}", file=sys.stderr)
        sys.exit(2)
    result = predictor.predict(args.ligand, args.additive, args.base, args.aryl_halide)
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
