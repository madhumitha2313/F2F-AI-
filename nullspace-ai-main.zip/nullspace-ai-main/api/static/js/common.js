/* Shared helpers for every page: the accented leading digits of a figure, and the
   refresh of the four live-stat tiles from GET /stats. Anything that came from the
   network is written with textContent; nothing is parsed as HTML. */
(function () {
  'use strict';

  var F2F = (window.F2F = window.F2F || {});

  F2F.pct = function (x) {
    return (x === null || x === undefined) ? 'n/a' : (x * 100).toFixed(1) + '%';
  };

  // Mirrors the server-side "lead" filter: the first one or two digits get .lead.
  F2F.setLead = function (el, text) {
    if (!el) { return; }
    text = String(text);
    el.textContent = '';
    var m = /^(\d{1,2})([\s\S]*)$/.exec(text);
    if (!m) { el.textContent = text; return; }
    var lead = document.createElement('span');
    lead.className = 'lead';
    lead.textContent = m[1];
    el.appendChild(lead);
    el.appendChild(document.createTextNode(m[2]));
  };

  // The nav sticks to the top on every page and turns translucent once the page has scrolled,
  // so content shows through it (app.css styles .is-scrolled). One passive listener, one
  // class toggle per frame at most.
  (function () {
    var nav = document.querySelector('[data-nav]');
    if (!nav) { return; }
    var queued = false;
    function sync() {
      queued = false;
      var y = window.pageYOffset || document.documentElement.scrollTop || 0;
      nav.classList.toggle('is-scrolled', y > 8);
    }
    window.addEventListener('scroll', function () {
      if (!queued) { queued = true; window.requestAnimationFrame(sync); }
    }, { passive: true });
    sync();   // a reload part-way down the page starts translucent
  })();

  F2F.refreshStats = function () {
    var host = document.getElementById('stats-panel');
    var url = host && host.getAttribute('data-stats-url');
    if (!url) { return Promise.resolve(); }
    var updated = document.getElementById('stats-updated');
    return fetch(url, { headers: { 'Accept': 'application/json' }, credentials: 'same-origin' })
      .then(function (res) {
        if (!res.ok) { throw new Error('HTTP ' + res.status); }
        return res.json();
      })
      .then(function (s) {
        F2F.setLead(document.getElementById('stat-total'), String(s.total_predictions));
        F2F.setLead(document.getElementById('stat-flagged'), String(s.flagged_failures));
        F2F.setLead(document.getElementById('stat-rate'), F2F.pct(s.failure_rate));
        F2F.setLead(document.getElementById('stat-conf'), F2F.pct(s.average_confidence));
        if (updated) {
          var now = new Date();
          updated.setAttribute('datetime', now.toISOString());
          updated.textContent = now.toISOString().slice(11, 19) + ' UTC';
        }
      })
      .catch(function () {
        if (updated) { updated.textContent = 'refresh failed'; }
      });
  };
})();
