# -*- coding: utf-8 -*-
"""
Load-time known-answer check for the trained model.

Why this exists: XGBoost will happily *load* a model written by a newer
version and then read part of it wrongly, with no error. This project hit
exactly that. The model stores base_score as "[2.0701644E-1]" (xgboost 3.x);
xgboost 2.1.0 reads it as 0.5, and every probability is shifted upward
(held-out precision 0.885 -> 0.726, recall 0.799 -> 0.890). ROC-AUC does not
move, so nothing looks wrong.

How the check works: models/load_check.json holds a handful of encoded probe
inputs spread across the model's probability range, plus the failure
probability the model gave for each when the file was generated in a verified
environment. At startup the probes are scored again and compared in logit
space. A misread intercept or tree changes the logits immediately; ordinary
floating-point noise does not.

Outcomes (see verify()):
  passed   probes match                          -> serve
  mismatch probes differ beyond the tolerance    -> ModelLoadError (do not serve)
  stale    the model file changed since the check was written (e.g. after a
           retrain)                              -> serve, but warn loudly
  missing  no load_check.json                    -> serve, but warn loudly

After every retrain, regenerate the reference in the verified environment
(the one installed from api/requirements.txt):
    python src/write_load_check.py
Do NOT regenerate it from an environment you have not verified: it would bake
that environment's misreading into the reference.
"""

import hashlib
import itertools
import math
import os
import sys
from importlib import metadata

FORMAT_VERSION = 1
LOGIT_TOLERANCE = 0.02   # ~0.5% relative change in odds; float noise is ~1e-6
N_PROBES = 16
_EPS = 1e-6              # clip so probabilities near 0/1 stay finite in logit space


class ModelLoadError(RuntimeError):
    """Model artifacts could not be loaded, or loaded but do not behave as verified."""


def environment_dict() -> dict:
    env = {"python": sys.version.split()[0]}
    for pkg in ("xgboost", "scikit-learn", "numpy"):
        try:
            env[pkg] = metadata.version(pkg)
        except metadata.PackageNotFoundError:
            env[pkg] = "not installed"
    return env


def environment_summary(env: dict = None) -> str:
    env = env or environment_dict()
    return ", ".join(f"{k} {v}" for k, v in env.items())


def file_sha256(path: str) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def _logit(p: float) -> float:
    p = min(max(p, _EPS), 1.0 - _EPS)
    return math.log(p / (1.0 - p))


def build(score, class_counts, model_path: str) -> dict:
    """Score every category combination, keep N_PROBES spread from the lowest to
    the highest predicted probability, and return the reference document.

    score:        callable(list[list[int]]) -> list[float] (failure probabilities)
    class_counts: number of known categories per feature, in FEATURE_COLS order
    """
    grid = [list(t) for t in itertools.product(*[range(n) for n in class_counts])]
    probs = score(grid)
    if not all(math.isfinite(p) for p in probs):
        raise ModelLoadError("Model produced non-finite probabilities; refusing to write a load check.")
    order = sorted(range(len(grid)), key=lambda i: probs[i])
    n = min(N_PROBES, len(order))
    picks = sorted({order[round(k * (len(order) - 1) / (n - 1))] for k in range(n)}) if n > 1 else order
    return {
        "format": FORMAT_VERSION,
        "model_sha256": file_sha256(model_path),
        "generated_with": environment_dict(),
        "logit_tolerance": LOGIT_TOLERANCE,
        "probes": [
            {"encoded": grid[i], "failure_probability": float(f"{probs[i]:.9g}")}
            for i in picks
        ],
    }


def verify(score, model_path: str, check_path: str) -> dict:
    """Re-score the stored probes. Returns {"status", "detail", ...} or raises ModelLoadError."""
    import json
    regenerate = "Regenerate it in the verified environment with: python src/write_load_check.py"

    if not os.path.exists(check_path):
        return {"status": "missing",
                "detail": f"No load check at {check_path}, so this model's predictions are "
                          f"UNVERIFIED in this environment. {regenerate}"}
    try:
        with open(check_path, encoding="utf-8") as f:
            ref = json.load(f)
        recorded_hash = ref["model_sha256"]
        tol = float(ref.get("logit_tolerance", LOGIT_TOLERANCE))
        rows = [[int(v) for v in p["encoded"]] for p in ref["probes"]]
        expected = [float(p["failure_probability"]) for p in ref["probes"]]
        reference_env = ref.get("generated_with") or {}
        if not rows:
            raise ValueError("no probes")
    except (OSError, ValueError, KeyError, TypeError) as e:
        raise ModelLoadError(f"Load check file {check_path} is unreadable ({type(e).__name__}: {e}). {regenerate}") from e

    if recorded_hash != file_sha256(model_path):
        return {"status": "stale",
                "detail": f"{os.path.basename(check_path)} was written for a different model file, so "
                          f"this model's predictions are UNVERIFIED. {regenerate}"}

    try:
        got = score(rows)
    except Exception as e:  # noqa: BLE001 - any scoring failure means the model is unusable here
        raise ModelLoadError(
            f"The model loaded but could not score the load-check probes ({type(e).__name__}: {e}). "
            f"This environment: {environment_summary()}."
        ) from e

    diffs = [abs(_logit(g) - _logit(e)) if math.isfinite(g) else float("inf") for g, e in zip(got, expected)]
    worst = max(range(len(diffs)), key=lambda i: diffs[i])
    if diffs[worst] > tol:
        raise ModelLoadError(
            "The model loaded but does NOT give the predictions it was verified to give, so it is not "
            f"being read correctly by this environment (largest logit difference {diffs[worst]:.3f}, "
            f"allowed {tol}; probe {worst}: expected failure probability {expected[worst]:.4f}, got "
            f"{got[worst]:.4f}). This usually means the installed xgboost / scikit-learn / numpy differ "
            f"from the versions the model was written and verified with.\n"
            f"  verified with: {environment_summary(reference_env) if reference_env else 'unknown'}\n"
            f"  this environment: {environment_summary()}\n"
            f"Install the versions pinned in api/requirements.txt."
        )
    return {"status": "passed", "probes": len(rows), "max_logit_diff": round(max(diffs), 6),
            "detail": f"{len(rows)} probes matched (largest logit difference {max(diffs):.2e})."}
