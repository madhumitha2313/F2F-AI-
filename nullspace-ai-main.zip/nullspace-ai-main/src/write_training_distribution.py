# -*- coding: utf-8 -*-
"""
Write models/training_distribution.json: how many training rows carry each value of each
input. The dashboard's Input coverage widget compares what people ask about with this mix.

The dataset itself is not in the Docker image, so the counts are recorded here, next to the
model, and committed. Run this after any change to the processed data:

    python src/write_training_distribution.py
"""

import json
import os
import sys

import pandas as pd

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import config as cfg


def build(csv_path=None):
    """{"rows": n, "features": {"Ligand": {smiles: rows}, ...}} from the processed dataset."""
    df = pd.read_csv(csv_path or cfg.PROCESSED_DATA_PATH)
    return {
        "rows": int(len(df)),
        "features": {
            col: {str(value): int(n) for value, n in df[col].astype(str).value_counts().items()}
            for col in cfg.FEATURE_COLS
        },
    }


def write(path=None, csv_path=None):
    """Write the file (sorted keys, LF line ends, so re-running gives the same bytes)."""
    doc = build(csv_path)
    with open(path or cfg.TRAINING_DISTRIBUTION_PATH, "w", encoding="utf-8", newline="\n") as f:
        json.dump(doc, f, indent=2, sort_keys=True)
        f.write("\n")
    return doc


def main():
    doc = write()
    print(f"Wrote {cfg.TRAINING_DISTRIBUTION_PATH}")
    print(f"  rows : {doc['rows']}")
    for col, counts in doc["features"].items():
        print(f"  {col:<12}: {len(counts)} values, {min(counts.values())}..{max(counts.values())} rows each")


if __name__ == "__main__":
    main()
