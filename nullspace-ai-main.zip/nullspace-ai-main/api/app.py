# -*- coding: utf-8 -*-
"""
Stage: Deployment + Live Predictions (architecture slide stages 8-9)

Flask REST API serving the trained Failure Intelligence Engine.

Endpoints:
  GET  /health                    -> liveness check
  POST /predict                   -> single-reaction failure prediction
  GET  /stats                     -> summary of logged predictions
  GET  /recent-predictions        -> last N logged predictions
  GET  /                          -> landing page
  GET  /login, /signup            -> standalone sign-in and sign-up pages
  POST /login, /signup            -> sign in (session cookie); sign-up is the same
                                     check, not a real account (see _AUTH_PAGES)
  POST /logout                    -> sign out
  GET  /dashboard                 -> signed-in dashboard (compare, stats, predict)

Sign-in is OPEN by default: /login and /signup accept any non-empty username and
password, so anyone can get in. Set F2F_DEV_BYPASS_AUTH=0 to require the real
credentials on both (F2F_USERNAME / F2F_PASSWORD, with SECRET_KEY for the session
cookie). The JSON endpoints above are public either way.

Run locally:
    python api/app.py
Run with gunicorn (production, see Dockerfile):
    gunicorn --bind 0.0.0.0:5000 app:app
"""

import csv
import hmac
import itertools
import mimetypes
import os
import re
import secrets
import sys
from datetime import datetime, timezone
from functools import wraps

from flask import (
    Flask, jsonify, make_response, redirect, render_template, request,
    session, url_for,
)
from markupsafe import Markup, escape

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "src"))
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "monitoring"))

from predict import FailurePredictor  # noqa: E402
from load_check import ModelLoadError  # noqa: E402
import config as cfg  # noqa: E402
import logger  # noqa: E402

mimetypes.add_type("font/woff2", ".woff2")   # Windows' registry often lacks it

app = Flask(__name__)

# Loaded once at startup, not per-request — avoids reloading the model on
# every call. Any failure (missing file, deserialisation error, or a model
# this environment reads wrongly) leaves the app running in an explicit
# "model not loaded" state that /health, /predict and the dashboard report,
# rather than crashing at import or serving wrong numbers.
try:
    predictor = FailurePredictor()
    MODEL_LOAD_ERROR = None
except Exception as e:  # noqa: BLE001
    predictor = None
    MODEL_LOAD_ERROR = str(e) if isinstance(e, (FileNotFoundError, ModelLoadError)) \
        else f"{type(e).__name__}: {e}"
    app.logger.error("Model not loaded: %s", MODEL_LOAD_ERROR)


# ---- Sign-in (demo gate) ---------------------------------------------------
_secret_key = os.environ.get("SECRET_KEY")
if not _secret_key:
    _secret_key = secrets.token_hex(32)
    app.logger.warning(
        "SECRET_KEY is not set: using a random key. Sessions will not survive "
        "a restart or work across multiple gunicorn workers."
    )
app.secret_key = _secret_key
app.config.update(SESSION_COOKIE_HTTPONLY=True, SESSION_COOKIE_SAMESITE="Lax")

USERNAME = os.environ.get("F2F_USERNAME", "demo")
PASSWORD = os.environ.get("F2F_PASSWORD")
_dev_credentials = not PASSWORD
if _dev_credentials:   # always a string, so the real check can never crash
    USERNAME, PASSWORD = "demo", "f2f-demo"

# Open sign-in is the default: /login accepts ANY non-empty username and password.
# F2F_DEV_BYPASS_AUTH=0 (or false/no/off) turns it off and the real check above
# applies. A value we do not recognise fails CLOSED (real check), and says so.
_bypass_raw = os.environ.get("F2F_DEV_BYPASS_AUTH", "")
_bypass_flag = _bypass_raw.strip().lower()
if _bypass_flag in ("", "1", "true", "yes", "on"):
    DEV_BYPASS_AUTH = True
else:
    DEV_BYPASS_AUTH = False
    if _bypass_flag not in ("0", "false", "no", "off"):
        app.logger.warning(
            "F2F_DEV_BYPASS_AUTH is set to %r, which is not 1/true/yes/on or "
            "0/false/no/off, so sign-in is CLOSED and the real credentials are "
            "required.", _bypass_raw
        )

if DEV_BYPASS_AUTH:
    app.logger.warning(
        "Sign-in is OPEN: any non-empty username and password is accepted. Set "
        "F2F_DEV_BYPASS_AUTH=0 (with F2F_USERNAME and F2F_PASSWORD) to require real credentials."
    )
elif _dev_credentials:
    app.logger.warning(
        "F2F_PASSWORD is not set: signing in with the DEV credentials "
        "demo / f2f-demo. Set F2F_USERNAME and F2F_PASSWORD before sharing "
        "this app with anyone."
    )


@app.route("/health", methods=["GET"])
def health():
    if predictor is None:
        return jsonify({"status": "unhealthy", "reason": MODEL_LOAD_ERROR}), 503
    return jsonify({
        "status": "healthy",
        "model": predictor.model_config.get("best_model"),
        "load_check": predictor.load_check["status"],   # passed | stale | missing
    })


@app.route("/predict", methods=["POST"])
def predict():
    if predictor is None:
        return jsonify({"error": "Model not loaded", "detail": MODEL_LOAD_ERROR}), 503

    body = request.get_json(silent=True)
    if not body:
        return jsonify({"error": "Request body must be JSON"}), 400

    required = ["ligand", "additive", "base", "aryl_halide"]
    missing = [f for f in required if f not in body]
    if missing:
        return jsonify({"error": f"Missing required fields: {missing}"}), 400

    try:
        result = predictor.predict(
            ligand=body["ligand"], additive=body["additive"],
            base=body["base"], aryl_halide=body["aryl_halide"],
        )
    except Exception as e:
        return jsonify({"error": "Prediction failed", "detail": str(e)}), 500

    try:
        logger.log_prediction(body, result)
    except Exception as e:
        # Logging failure should never break the API response itself.
        result.setdefault("warnings", []).append(f"Logging failed: {e}")

    return jsonify(result)


# ---- /explain: why the model said what it said, and what to change ----------
# Public like /predict. It never writes the prediction log (the dashboard calls
# /predict first, which does). The maths lives in FailurePredictor.explain(); this
# route only adds the friendly names, taken from _friendly_options() so they are the
# dropdowns' own labels and the two can never drift.
from predict import UnknownValueError  # noqa: E402


def _friendly_names():
    """{key: {smiles: "Ligand 2"}} using the same numbering as the predict form."""
    names = {}
    for col in cfg.FEATURE_COLS:
        options = _friendly_options(
            col.replace("_", " "), (str(c) for c in predictor.encoders[col].classes_))
        names[col.lower()] = {o["value"]: o["name"] for o in options}
    return names


@app.route("/explain", methods=["POST"])
def explain():
    if predictor is None:
        return jsonify({"error": "Model not loaded", "detail": MODEL_LOAD_ERROR}), 503

    body = request.get_json(silent=True)
    if not isinstance(body, dict) or not body:
        return jsonify({"error": "Request body must be JSON"}), 400

    required = ["ligand", "additive", "base", "aryl_halide"]
    missing = [f for f in required if f not in body]
    if missing:
        return jsonify({"error": f"Missing required fields: {missing}"}), 400

    try:
        result = predictor.explain(
            ligand=body["ligand"], additive=body["additive"],
            base=body["base"], aryl_halide=body["aryl_halide"],
        )
    except UnknownValueError as e:
        return jsonify({"error": "Unknown value", "detail": str(e)}), 400
    except Exception as e:
        return jsonify({"error": "Explanation failed", "detail": str(e)}), 500

    if result.get("supported"):
        names = _friendly_names()
        current = {c["key"]: c["value"] for c in result["contributions"]}
        for c in result["contributions"]:
            c["choice"] = names[c["key"]][c["value"]]
        for a in result["alternatives"]:
            a["from"] = names[a["key"]][current[a["key"]]]
            a["to"] = names[a["key"]][a["to_value"]]
    return jsonify(result)


# ---- /activity, /coverage, /predict/batch: the extra dashboard widgets ------
# All three are public like /predict, and none of them writes the prediction log.
import json  # noqa: E402
import sqlite3  # noqa: E402

from predict import _shorten  # noqa: E402

_TRAINING_CACHE = {}
EVENNESS_MIN_SAMPLES = 30      # below this a chi-square test says nothing worth showing
EVENNESS_ALPHA = 0.05
BATCH_MAX_ROWS = 200
BATCH_MAX_BYTES = 100000


@app.route("/activity", methods=["GET"])
def activity():
    try:
        return jsonify(logger.get_activity())
    except (sqlite3.Error, OSError) as e:
        return jsonify({"error": "Activity could not be read", "detail": str(e)}), 500


def _load_training_distribution():
    """models/training_distribution.json as a dict, or None if it is missing or unreadable."""
    try:
        with open(cfg.TRAINING_DISTRIBUTION_PATH, encoding="utf-8") as f:
            doc = json.load(f)
    except (OSError, ValueError):
        return None
    if not isinstance(doc, dict) or not isinstance(doc.get("rows"), int) \
            or not isinstance(doc.get("features"), dict):
        return None
    return doc


def _training_distribution():
    """The training mix, read once. A missing file is looked for again on the next call."""
    if "value" not in _TRAINING_CACHE:
        doc = _load_training_distribution()
        if doc is None:
            return None
        _TRAINING_CACHE["value"] = doc
    return _TRAINING_CACHE["value"]


def _training_counts(classes):
    """({column: {smiles: training rows}}, total rows) for the model's own values, or None when
    the file is missing or does not describe this model (a value with no training count)."""
    doc = _training_distribution()
    if doc is None:
        return None
    counts = {}
    for col in cfg.FEATURE_COLS:
        have = doc["features"].get(col)
        if not isinstance(have, dict):
            return None
        for smiles in classes[col]:
            n = have.get(smiles)
            if not isinstance(n, int) or isinstance(n, bool) or n <= 0:
                return None
        counts[col] = {smiles: have[smiles] for smiles in classes[col]}
    return counts, doc["rows"]


def _evenness(asked, training):
    """Chi-square goodness of fit of what was asked (per input, known values only) against the
    training mix. `asked` is {column: {smiles: n}}, `training` the counts from _training_counts()
    or None. One test per input; the verdict is 'uneven' if any input's p is under its cutoff.
    The four tests share one EVENNESS_ALPHA budget (Bonferroni), so a perfectly even log is
    called uneven about 5% of the time rather than about 1 time in 5."""
    from scipy.stats import chisquare

    result = {"status": None, "min_samples": EVENNESS_MIN_SAMPLES, "p_values": None, "note": ""}
    if training is None:
        result["status"] = "unavailable"
        result["note"] = ("The training mix (models/training_distribution.json) is missing or does "
                          "not match this model, so your asks cannot be compared with it.")
        return result
    enough = min(sum(asked[col].values()) for col in cfg.FEATURE_COLS)
    if enough < EVENNESS_MIN_SAMPLES:
        result["status"] = "insufficient_data"
        result["note"] = (f"Needs at least {EVENNESS_MIN_SAMPLES} logged asks with known values for "
                          f"every input before a comparison means anything; the smallest input has {enough}.")
        return result

    p_values, small = {}, False
    for col in cfg.FEATURE_COLS:
        values = list(training[col])
        observed = [asked[col].get(v, 0) for v in values]
        n = sum(observed)
        total = sum(training[col].values())
        expected = [training[col][v] / total * n for v in values]
        small = small or min(expected) < 5
        p_values[col.lower()] = float(chisquare(observed, expected).pvalue)
    cutoff = EVENNESS_ALPHA / len(cfg.FEATURE_COLS)
    basis = (f"chi-square, p < {cutoff:.4g} for an input, so four tests share a "
             f"{EVENNESS_ALPHA:.0%} false-alarm budget")
    differing = [col.replace("_", " ") for col in cfg.FEATURE_COLS if p_values[col.lower()] < cutoff]
    result["p_values"] = p_values
    result["status"] = "uneven" if differing else "even"
    if differing:
        result["note"] = (f"What was asked differs from the training mix for: {', '.join(differing)} "
                          f"({basis}). That describes how the tool is used, not that the model is "
                          f"stale: the training data covers every value about equally.")
    else:
        result["note"] = f"No input shows a clear difference from the training mix ({basis})."
    if small:
        result["note"] += " Counts are still small, so treat this as a rough guide."
    return result


@app.route("/coverage", methods=["GET"])
def coverage():
    if predictor is None:
        return jsonify({"error": "Model not loaded", "detail": MODEL_LOAD_ERROR}), 503
    try:
        counts = logger.get_value_counts()
        unseen = logger.count_unseen_requests()
    except (sqlite3.Error, OSError) as e:
        return jsonify({"error": "Coverage could not be read", "detail": str(e)}), 500

    names = _friendly_names()      # the dropdowns' own labels, in the dropdowns' own order
    classes = {col: list(names[col.lower()]) for col in cfg.FEATURE_COLS}
    loaded = _training_counts(classes)
    training, training_rows = loaded if loaded else (None, None)

    features, asked_by_col = [], {}
    for col in cfg.FEATURE_COLS:
        key = col.lower()
        # Only values the model knows get a bar; a request with an unknown one is
        # counted in `unseen_requests` instead.
        asked_by_col[col] = {s: counts[key].get(s, 0) for s in classes[col]}
        total = sum(training[col].values()) if training else None
        values = [{
            "name": names[key][s],
            "count": asked_by_col[col][s],
            "training_share": round(training[col][s] / total, 6) if training else None,
        } for s in classes[col]]
        features.append({
            "key": key, "label": col.replace("_", " "), "total": len(values),
            "asked": sum(1 for v in values if v["count"]), "values": values,
        })

    return jsonify({
        "samples": counts["samples"],
        "features": features,
        "asked_values": sum(f["asked"] for f in features),
        "total_values": sum(f["total"] for f in features),
        "unseen_requests": unseen,
        "evenness": _evenness(asked_by_col, training),
        "training": {"rows": training_rows} if training else None,
    })


def _batch_row(row, lookup):
    """Resolve one batch row to ({column: smiles}, None), or (None, why not). Each value may be
    a SMILES string or the friendly name the dropdowns show ('Ligand 2'), in any case or spacing."""
    if not isinstance(row, dict):
        return None, "Row must be an object with ligand, additive, base and aryl_halide"
    smiles = []
    for col in cfg.FEATURE_COLS:
        key = col.lower()
        value = row.get(key)
        if value is None or (isinstance(value, str) and not value.strip()):
            return None, f"Missing {key}"
        if not isinstance(value, str):
            return None, f"{key} must be text"
        text = value.strip()
        found = lookup[key]["exact"].get(text) or lookup[key]["friendly"].get(
            re.sub(r"[\s_]+", " ", text).lower())
        if found is None:
            return None, f"Unknown {key}: '{_shorten(text)}'"
        smiles.append(found)
    return smiles, None


@app.route("/predict/batch", methods=["POST"])
def predict_batch():
    if predictor is None:
        return jsonify({"error": "Model not loaded", "detail": MODEL_LOAD_ERROR}), 503

    # Read at most one byte past the limit ourselves: that covers a declared Content-Length and a
    # chunked body alike (Werkzeug's own cap would silently truncate the latter).
    raw = request.stream.read(BATCH_MAX_BYTES + 1) if request.is_json else b""
    if len(raw) > BATCH_MAX_BYTES:
        return jsonify({"error": f"Request body is too large (over {BATCH_MAX_BYTES} bytes)",
                        "limit_bytes": BATCH_MAX_BYTES}), 413
    try:
        body = json.loads(raw)
    except ValueError:
        body = None
    if not isinstance(body, dict) or not isinstance(body.get("rows"), list) or not body["rows"]:
        return jsonify({"error": 'Request body must be JSON like {"rows": [{...}, ...]} with at least one row'}), 400
    rows = body["rows"]
    if len(rows) > BATCH_MAX_ROWS:
        return jsonify({"error": f"At most {BATCH_MAX_ROWS} rows per request", "limit": BATCH_MAX_ROWS}), 413

    names = _friendly_names()
    lookup = {key: {"exact": {s: s for s in by_smiles},
                    "friendly": {re.sub(r"[\s_]+", " ", n).lower(): s for s, n in by_smiles.items()}}
              for key, by_smiles in names.items()}
    classes = {col: {s: i for i, s in enumerate(str(c) for c in predictor.encoders[col].classes_)}
               for col in cfg.FEATURE_COLS}

    results, scorable = [], []          # scorable: (index into results, encoded row)
    for number, row in enumerate(rows, start=1):
        smiles, why = _batch_row(row, lookup)
        if why:
            results.append({"row": number, "ok": False, "error": why})
            continue
        results.append({"row": number, "ok": True,
                        "inputs": {c.lower(): names[c.lower()][s] for c, s in zip(cfg.FEATURE_COLS, smiles)}})
        scorable.append((len(results) - 1, [classes[c][s] for c, s in zip(cfg.FEATURE_COLS, smiles)]))

    try:
        probabilities = predictor._score([encoded for _, encoded in scorable]) if scorable else []
    except Exception as e:  # noqa: BLE001
        return jsonify({"error": "Batch prediction failed", "detail": str(e)}), 500
    for (at, _), p in zip(scorable, probabilities):
        prediction = "Failure" if p >= 0.5 else "Success"       # the same rules as predict()
        results[at].update({
            "prediction": prediction,
            "failure_probability": round(p, 4),
            "confidence": round(p if prediction == "Failure" else 1 - p, 4),
        })

    return jsonify({
        "count": len(results), "ok": len(scorable), "failed": len(results) - len(scorable),
        "model_used": predictor.model_config.get("best_model", "unknown"),
        "results": results,
    })


@app.route("/stats", methods=["GET"])
def stats():
    return jsonify(logger.get_summary_stats())


@app.route("/recent-predictions", methods=["GET"])
def recent_predictions():
    limit = request.args.get("limit", default=50, type=int)
    return jsonify(logger.get_recent_predictions(limit=limit))


# ---- Pages: landing, sign-in, dashboard ------------------------------------
METRIC_COLUMNS = [
    ("accuracy", "Accuracy"), ("precision", "Precision"), ("recall", "Recall"),
    ("f1", "F1"), ("roc_auc", "ROC-AUC"),
]


def login_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if not session.get("user"):
            return redirect(url_for("landing"))
        return view(*args, **kwargs)
    return wrapped


def _credentials_ok(username: str, password: str) -> bool:
    # Evaluate both comparisons so a wrong username and a wrong password
    # take the same time.
    user_ok = hmac.compare_digest(username.encode("utf-8"), USERNAME.encode("utf-8"))
    pass_ok = hmac.compare_digest(password.encode("utf-8"), PASSWORD.encode("utf-8"))
    return user_ok and pass_ok


@app.template_filter("lead")
def _lead_filter(value):
    """Wrap the first one or two digits in .lead so the stylesheet can accent
    them: '93.7%' -> <span class="lead">93</span>.7%. Text with no leading
    digit ('n/a') is returned escaped and unchanged."""
    text = str(value)
    m = re.match(r"^(\d{1,2})(.*)$", text, re.S)
    if not m:
        return escape(text)
    return Markup('<span class="lead">%s</span>%s') % (m.group(1), m.group(2))


def _pct(x):
    return "n/a" if x is None else f"{x * 100:.1f}%"


def _stats_view(stats):
    """Display strings for the four live-stat tiles (same rules as the JS refresh)."""
    if not stats:
        return None
    return {
        "total": str(stats.get("total_predictions", 0)),
        "flagged": str(stats.get("flagged_failures", 0)),
        "rate": _pct(stats.get("failure_rate")),
        "conf": _pct(stats.get("average_confidence")),
    }


_GRID_CACHE = {}


def _grid_scores():
    """(classes, grid, probs): the model's failure probability for EVERY combination
    of the values it knows (4 x 22 x 3 x 15 = 3960), scored once and cached. `grid`
    rows are indices into `classes` in cfg.FEATURE_COLS order (itertools.product
    order), so the score for (l, a, b, h) sits at ((l*nA + a)*nB + b)*nH + h."""
    if "value" not in _GRID_CACHE:
        classes = [[str(c) for c in predictor.encoders[col].classes_] for col in cfg.FEATURE_COLS]
        grid = [list(g) for g in itertools.product(*[range(len(c)) for c in classes])]
        _GRID_CACHE["value"] = (classes, grid, predictor._score(grid))
    return _GRID_CACHE["value"]


_SPECTRUM_CACHE = {}


def _spectrum():
    """Data for the spectrum field: one bar per category value the model knows
    (4 ligands + 22 additives + 3 bases + 15 aryl halides = 44), grouped by
    feature. A bar's height is the model's average predicted failure probability
    over every combination that contains that value. It comes from the model
    alone, so it needs no dataset at serve time, and it is a model estimate,
    not an observed failure rate."""
    if predictor is None:
        return None
    if "value" in _SPECTRUM_CACHE:
        return _SPECTRUM_CACHE["value"]
    try:
        classes, grid, probs = _grid_scores()
        shares = {r["label"]: r["share"] for r in (_feature_importance() or [])}
        groups = []
        for j, col in enumerate(cfg.FEATURE_COLS):
            sums, counts = [0.0] * len(classes[j]), [0] * len(classes[j])
            for g, p in zip(grid, probs):
                sums[g[j]] += p
                counts[g[j]] += 1
            values = sorted(
                ({"label": classes[j][k], "p": sums[k] / counts[k]} for k in range(len(classes[j]))),
                key=lambda v: v["p"],
            )
            for v in values:
                v["short"] = v["label"] if len(v["label"]) <= 32 else v["label"][:31] + "…"
                v["h"] = max(2.0, v["p"] * 100)
            label = col.replace("_", " ")
            groups.append({
                "key": col.lower(), "label": label, "n": len(values),
                "share": shares.get(label), "lo": values[0]["p"], "hi": values[-1]["p"],
                "bars": values,
            })
        ranked = [g for g in groups if g["share"] is not None]
        default = max(ranked, key=lambda g: g["share"])["key"] if ranked else groups[0]["key"]
        result = {"groups": groups, "total": sum(g["n"] for g in groups), "default": default}
    except Exception as e:  # noqa: BLE001 - the visual is optional; never break the page
        app.logger.warning("Could not build the spectrum data: %s", e)
        result = None
    _SPECTRUM_CACHE["value"] = result
    return result


_PLATE_CACHE = {}
_HALOGENS = ("Cl", "Br", "I")


def _plate():
    """Data for the login page's lab elements. One well per reaction the model can
    score: rows are the 15 aryl halides, columns are ligand x base (4 x 3 = 12), and
    there is one plate per additive (22). A well holds the model's predicted failure
    probability (0-1000). Values are model estimates, not measurements. Halogen
    tiles filter the rows; `halides` gives each halogen's row count and mean
    predicted failure probability. Codes (L1, A3, B2, AH5) are display labels in
    the order of the model's known values; the API itself takes the full strings."""
    if predictor is None:
        return None
    if "value" in _PLATE_CACHE:
        return _PLATE_CACHE["value"]
    try:
        classes, grid, probs = _grid_scores()
        ligands, additives, bases, aryls = classes          # cfg.FEATURE_COLS order
        nL, nA, nB, nH = (len(c) for c in classes)
        assert len(grid) == len(probs) == nL * nA * nB * nH

        def at(l, a, b, h):
            return probs[((l * nA + a) * nB + b) * nH + h]

        rows = [{"code": f"AH{h + 1}", "label": s,
                 "halide": next((x for x in _HALOGENS if x in s), None)}
                for h, s in enumerate(aryls)]
        halides = {}
        for x in _HALOGENS:
            idx = [h for h, r in enumerate(rows) if r["halide"] == x]
            if idx:
                vals = [at(l, a, b, h) for h in idx for l in range(nL) for a in range(nA) for b in range(nB)]
                halides[x] = {"n": len(idx), "mean": sum(vals) / len(vals)}
        result = {
            "ligands": [{"code": f"L{i + 1}", "label": s} for i, s in enumerate(ligands)],
            "additives": [{"code": f"A{i + 1}", "label": s} for i, s in enumerate(additives)],
            "bases": [{"code": f"B{i + 1}", "label": s} for i, s in enumerate(bases)],
            "rows": rows,
            # p[additive][row][col], col = ligand * nB + base
            "p": [[[int(round(at(l, a, b, h) * 1000)) for l in range(nL) for b in range(nB)]
                   for h in range(nH)] for a in range(nA)],
            "halides": halides,
            "counts": {"ligand": nL, "additive": nA, "base": nB, "aryl_halide": nH},
            "threshold": predictor.model_config.get("failure_threshold"),
        }
    except Exception as e:  # noqa: BLE001 - decorative and optional; never break the page
        app.logger.warning("Could not build the reaction plate data: %s", e)
        result = None
    _PLATE_CACHE["value"] = result
    return result


def _landing_context():
    """Everything the landing page shows that comes from the model or the log."""
    ctx = {"metrics": None, "model_name": None, "threshold": None, "meta": None,
           "stats": _stats_view(_initial_stats()), "spectrum": None, "plate": None}
    if predictor is None:
        return ctx
    config = predictor.model_config
    m = config.get("metrics") or {}
    try:
        ctx["metrics"] = [
            {"label": "Accuracy", "value": f"{m['accuracy'] * 100:.1f}%"},
            {"label": "Precision on failures", "value": f"{m['precision'] * 100:.1f}%"},
            {"label": "Recall on failures", "value": f"{m['recall'] * 100:.1f}%"},
            {"label": "ROC-AUC", "value": f"{m['roc_auc']:.3f}"},
        ]
        ctx["meta"] = [
            {"label": "Model", "value": str(config.get("best_model", "unknown"))},
            {"label": "Held-out recall", "value": f"{m['recall'] * 100:.1f}%"},
            {"label": "ROC-AUC", "value": f"{m['roc_auc']:.3f}"},
            {"label": "Failure threshold", "value": str(config.get("failure_threshold"))},
        ]
    except (KeyError, TypeError):
        pass
    ctx["model_name"] = config.get("best_model")
    ctx["threshold"] = config.get("failure_threshold")
    ctx["spectrum"] = _spectrum()
    ctx["plate"] = _plate()
    return ctx


def _model_comparison(best_name):
    try:
        with open(cfg.COMPARISON_CSV_PATH, newline="", encoding="utf-8") as f:
            raw_rows = list(csv.DictReader(f))
    except OSError:
        return None
    rows = []
    for r in raw_rows:
        try:
            metrics = {key: float(r[key]) for key, _ in METRIC_COLUMNS}
        except (KeyError, ValueError, TypeError):
            continue
        rows.append({"name": r.get("Model", ""), "metrics": metrics,
                     "best": r.get("Model") == best_name})
    return rows or None


def _feature_importance():
    if predictor is None:
        return None
    try:
        raw = predictor.model.feature_importances_
        values = [float(v) for v in raw]
    except Exception:
        return None
    if len(values) != len(cfg.FEATURE_COLS) or sum(values) <= 0:
        return None
    total = sum(values)
    rows = [{"label": col.replace("_", " "), "share": v / total}
            for col, v in zip(cfg.FEATURE_COLS, values)]
    return sorted(rows, key=lambda r: r["share"], reverse=True)


def _friendly_options(label, values):
    """Dropdown options as {"value": SMILES, "name": "<Label> <n>"}. `value` is
    exactly what /predict receives; `name` is only what the person reads. Sorted by
    the SMILES string so the numbering is the same on every page load (it shifts only
    if a retrained model knows a different set of categories)."""
    return [{"value": v, "name": f"{label} {n}"} for n, v in enumerate(sorted(values), 1)]


def _form_fields():
    """The four inputs, with the categories the model saw in training."""
    if predictor is None:
        return None
    fields = []
    for col in cfg.FEATURE_COLS:
        label = col.replace("_", " ")
        fields.append({
            "key": col.lower(), "label": label,
            "options": _friendly_options(label, (str(c) for c in predictor.encoders[col].classes_)),
        })
    return fields


def _initial_stats():
    try:
        return logger.get_summary_stats()
    except Exception as e:
        app.logger.warning("Could not read prediction stats: %s", e)
        return None


@app.route("/", methods=["GET"])
def landing():
    # Also for someone who is signed in: the wordmark in the nav is the way home, so it has to
    # reach the homepage and not bounce to the dashboard. The hero offers "Open dashboard"
    # instead of "Sign in" (see landing.html). /login and /signup still send them on.
    return render_template("landing.html", **_landing_context())


# ---- Sign-in and sign-up: two standalone pages, one shared component ---------
# Both pages render templates/auth.html and both draw the same reaction-progress
# canvas (static/js/reaction.js). Only the copy, the fields and the atoms differ.
#
# SIGN-UP IS NOT REAL MULTI-USER AUTH. It never creates, stores or looks up an
# account. POST /signup runs the exact same check as POST /login and, if that
# passes, signs the visitor into the ONE existing single-account session. In the
# default (open) build that means any non-empty username and password works; with
# F2F_DEV_BYPASS_AUTH=0 it needs the real F2F_USERNAME / F2F_PASSWORD, so /signup
# is never a way around the real login. If real accounts are wanted later, this
# is the place to add them (and the confirm field, which is checked in the browser
# only and is deliberately unnamed so it is never submitted).
_AUTH_PAGES = {
    "signin": {
        "endpoint": "login", "title": "Sign in", "eyebrow": "Sign in",
        "heading": "Sign in to run a prediction",
        "lede": "Two reagents, one coupling. Each field you fill adds an atom to the molecule.",
        "button": "Sign in", "busy": "Signing in",
        "atoms": ["N", "Pd"],
        "fields": [
            {"id": "username", "name": "username", "label": "Username", "type": "text",
             "autocomplete": "username"},
            {"id": "password", "name": "password", "label": "Password", "type": "password",
             "autocomplete": "current-password"},
        ],
        "final_step": "Ready",
        "alt_endpoint": "signup", "alt_text": "New here?", "alt_link": "Sign up",
    },
    "signup": {
        "endpoint": "signup", "title": "Sign up", "eyebrow": "Sign up",
        "heading": "Sign up to run a prediction",
        "lede": "Three reagents, one coupling. Each field you fill adds an atom to the molecule.",
        "button": "Sign up", "busy": "Signing up",
        "atoms": ["N", "Pd", "Br"],
        "fields": [
            {"id": "username", "name": "username", "label": "Username", "type": "text",
             "autocomplete": "username"},
            {"id": "password", "name": "password", "label": "Password", "type": "password",
             "autocomplete": "new-password"},
            # No name: the browser never submits it. It only has to match the password.
            {"id": "confirm", "name": None, "label": "Confirm password", "type": "password",
             "autocomplete": "new-password"},
        ],
        "final_step": "Ready",
        "alt_endpoint": "login", "alt_text": "Already here?", "alt_link": "Sign in",
    },
}
_AUTH_FAILED = "Username or password is incorrect. Check both and try again."


def _wants_json() -> bool:
    """True for the page's own fetch() (it asks for JSON); a normal navigation or a
    no-JS form post asks for HTML and gets the redirect / re-rendered page instead."""
    accept = request.accept_mimetypes
    return accept["application/json"] > accept["text/html"]


def _auth_page(mode, error=None, status=200):
    return render_template(
        "auth.html", mode=mode, page=_AUTH_PAGES[mode], error=error,
        open_login=DEV_BYPASS_AUTH,
    ), status


def _auth_view(mode):
    if request.method == "GET":
        if session.get("user"):
            return redirect(url_for("dashboard"))
        return _auth_page(mode)
    username = request.form.get("username", "")
    password = request.form.get("password", "")
    bypass = DEV_BYPASS_AUTH and bool(username.strip()) and bool(password.strip())
    if bypass:
        # %r keeps a hostile username from injecting newlines into the log
        app.logger.info("open %s: %r signed in without a credential check", mode, username[:40])
    if bypass or _credentials_ok(username, password):
        session.clear()  # fresh session on sign-in
        session["user"] = USERNAME
        if _wants_json():
            return jsonify({"ok": True, "next": url_for("dashboard")})
        return redirect(url_for("dashboard"))
    if _wants_json():
        return jsonify({"ok": False, "error": _AUTH_FAILED}), 401
    return _auth_page(mode, error=_AUTH_FAILED, status=401)


@app.route("/login", methods=["GET", "POST"])
def login():
    return _auth_view("signin")


@app.route("/signup", methods=["GET", "POST"])
def signup():
    return _auth_view("signup")


@app.route("/logout", methods=["POST"])
def logout():
    session.clear()
    return redirect(url_for("landing"))


@app.route("/dashboard", methods=["GET"])
@login_required
def dashboard():
    now = datetime.now(timezone.utc)
    best_name = predictor.model_config.get("best_model") if predictor else None
    html = render_template(
        "dashboard.html",
        model_loaded=predictor is not None,
        load_error=MODEL_LOAD_ERROR,
        best_model=best_name,
        fields=_form_fields(),
        importance=_feature_importance(),
        spectrum=_spectrum(),
        comparison=_model_comparison(best_name),
        metric_columns=METRIC_COLUMNS,
        stats=_stats_view(_initial_stats()),
        now_iso=now.isoformat(timespec="seconds"),
        now_hms=now.strftime("%H:%M:%S"),
    )
    resp = make_response(html)
    resp.headers["Cache-Control"] = "no-store"  # signed-out users must not see it via Back
    return resp


if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5000))
    app.run(host="0.0.0.0", port=port, debug=False)
