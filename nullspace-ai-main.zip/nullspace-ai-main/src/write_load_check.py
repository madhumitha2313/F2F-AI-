# -*- coding: utf-8 -*-
"""
Write models/load_check.json: the known-answer reference the API re-checks at
startup (see load_check.py for why).

Run this after every retrain, in the VERIFIED environment (the one installed
from api/requirements.txt). Running it in an environment that misreads the
model would record the misreading as the reference.

    python src/write_load_check.py
"""

import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import config as cfg
import load_check
from predict import FailurePredictor


def main():
    predictor = FailurePredictor(verify=False)   # the reference cannot check itself
    counts = [len(predictor.encoders[c].classes_) for c in cfg.FEATURE_COLS]
    doc = load_check.build(predictor._score, counts, cfg.BEST_MODEL_PATH)
    with open(cfg.LOAD_CHECK_PATH, "w", encoding="utf-8") as f:
        json.dump(doc, f, indent=2)
        f.write("\n")

    probs = [p["failure_probability"] for p in doc["probes"]]
    print(f"Wrote {cfg.LOAD_CHECK_PATH}")
    print(f"  environment : {load_check.environment_summary(doc['generated_with'])}")
    print(f"  probes      : {len(probs)}, failure probability {min(probs):.4f} .. {max(probs):.4f}")
    print(f"  model sha256: {doc['model_sha256'][:16]}...")


if __name__ == "__main__":
    main()
