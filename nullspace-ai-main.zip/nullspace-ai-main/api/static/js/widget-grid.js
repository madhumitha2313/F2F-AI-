/* Widget grid: a dashboard of widgets that can be rearranged by dragging.

   The layout is a sequence plus a size per widget. An exact tiler turns the sequence
   into a gap-free rectangle at any column count (a row packer is the fallback when no
   exact tiling exists), and every change slides into place. A vanilla port of the
   layout, drop-target and keyboard logic of the React draggable-widget-grid: no
   framework, no animation library.

   Two layers, so the logic can be tested without a browser:
     - layout(), canonical(), moveTo(), sanitizeOrder(), candidatesFor(), choose():
       pure functions over [{id, size}] (no DOM, no clock).
     - mount(grid, opts): the DOM engine. It reads [data-widget] children of the grid
       and writes only layout: display grid, column and row spans, transforms and
       animations, aria attributes, data-cols, and three classes for the stylesheet to
       style: is-lifted (the widget being dragged), is-landed (about 600ms after a drop)
       and is-dragging (on the grid while a drag runs). The DOM order never changes:
       a rearranged widget only gets a new grid placement.

   Sizes: sm 1x1, wide 2x1, tall 1x2, lg 2x2, clamped to the column count. With ONE column there
   are no square cells: every widget is one column wide and as tall as its content, whatever
   its size, and dragging measures the real heights (see rowHeight and columnSlots).

   Ways to move a widget (all reach the same code):
     - drag the [data-widget-handle] (mouse, pen or touch: the handle has touch-action none)
     - the [data-widget-move="-1"|"1"] buttons: a click or tap alternative to dragging
     - Alt + arrow keys on a widget or its buttons

   Animation runs only when the page has the "motion" class (base.html sets it unless the
   visitor asked for reduced motion); otherwise every change is instant. */
(function (root) {
  'use strict';

  var SPANS = {
    sm:   { col: 1, row: 1 },
    wide: { col: 2, row: 1 },
    tall: { col: 1, row: 2 },
    lg:   { col: 2, row: 2 }
  };

  function spanOf(item, columns) {
    var size = item && item.size;
    var s = Object.prototype.hasOwnProperty.call(SPANS, size) ? SPANS[size] : SPANS.sm;
    return { w: Math.min(s.col, columns), h: s.row };
  }

  /* ---- Layout ------------------------------------------------------------------ */
  function overlaps(a, b) {
    return a.col < b.col + b.w && b.col < a.col + a.w && a.row < b.row + b.h && b.row < a.row + a.h;
  }
  function contains(outer, inner) {
    return inner.col >= outer.col && inner.row >= outer.row &&
      inner.col + inner.w <= outer.col + outer.w && inner.row + inner.h <= outer.row + outer.h;
  }
  function reading(a, b) { return a.row - b.row || a.col - b.col; }
  function find(list, id) {
    for (var i = 0; i < list.length; i++) { if (list[i].id === id) { return list[i]; } }
    return null;
  }

  var TILING_BUDGET = 20000;
  var CACHE = Object.create(null);
  var cacheSize = 0;

  // Places every widget. An exact tiling first (no gaps, no stretching); a row packer that
  // grows widgets to close gaps when none exists. Pure, so results are cached.
  function layout(items, columns) {
    if (columns < 1 || !items || items.length === 0) { return []; }
    var key = columns + '|' + JSON.stringify(items.map(function (i) { return [i.id, i.size]; }));
    var hit = CACHE[key];
    if (!hit) {
      hit = tile(items, columns) || pack(items, columns);
      if (cacheSize >= 400) { CACHE = Object.create(null); cacheSize = 0; }
      CACHE[key] = hit;
      cacheSize++;
    }
    return hit.map(function (p) { return { id: p.id, col: p.col, row: p.row, w: p.w, h: p.h }; });
  }

  // Exact tiling. The first empty cell in reading order takes the earliest widget that fits
  // there and still lets the rest be placed. Widgets of the same shape are interchangeable at
  // a cell, so only one of each shape is tried. The search is capped by TILING_BUDGET, so a
  // set that cannot tile (about 1ms) falls through to the packer instead of hanging.
  function tile(items, columns) {
    var spans = items.map(function (item) { return spanOf(item, columns); });
    var area = 0;
    spans.forEach(function (s) { area += s.w * s.h; });
    var rows = Math.ceil(area / columns);
    var grid = [], used = [], out = [];
    var budget = TILING_BUDGET;
    var i;
    for (i = 0; i < rows * columns; i++) { grid.push(false); }
    for (i = 0; i < items.length; i++) { used.push(false); }

    function fits(w, h, r, c) {
      if (c + w > columns || r + h > rows) { return false; }
      for (var y = r; y < r + h; y++) {
        for (var x = c; x < c + w; x++) { if (grid[y * columns + x]) { return false; } }
      }
      return true;
    }
    function mark(w, h, r, c, value) {
      for (var y = r; y < r + h; y++) {
        for (var x = c; x < c + w; x++) { grid[y * columns + x] = value; }
      }
    }

    function place(count) {
      if (count === items.length) { return true; }
      if (--budget < 0) { return false; }
      var at = grid.indexOf(false);
      if (at < 0) { return false; }
      var r = Math.floor(at / columns), c = at % columns;
      var tried = Object.create(null);
      for (var k = 0; k < items.length; k++) {
        if (used[k]) { continue; }
        var w = spans[k].w, h = spans[k].h, shape = w + 'x' + h;
        if (tried[shape] || !fits(w, h, r, c)) { continue; }
        tried[shape] = true;
        used[k] = true;
        mark(w, h, r, c, true);
        out.push({ id: items[k].id, col: c, row: r, w: w, h: h });
        if (place(count + 1)) { return true; }
        out.pop();
        mark(w, h, r, c, false);
        used[k] = false;
      }
      return false;
    }

    return place(0) ? out : null;
  }

  // Fallback: fill bands in order, then widen widgets to close each band's gaps.
  function pack(items, columns) {
    var out = [];
    var row = 0;
    var queue = items.map(function (item) {
      var s = spanOf(item, columns);
      return { id: item.id, w: s.w, h: s.h };
    });

    while (queue.length > 0) {
      var height = 0;
      queue.slice(0, columns).forEach(function (q) { height = Math.max(height, q.h); });
      var cells = [];
      var band = [];
      var rest = [];
      var i;
      for (i = 0; i < height * columns; i++) { cells.push(false); }

      queue.forEach(function (q) {
        var spot = -1;
        for (var n = 0; n < cells.length && spot < 0; n++) {
          var r = Math.floor(n / columns), c = n % columns;
          if (c + q.w > columns || r + q.h > height) { continue; }
          var free = true;
          for (var y = r; y < r + q.h && free; y++) {
            for (var x = c; x < c + q.w && free; x++) { if (cells[y * columns + x]) { free = false; } }
          }
          if (free) { spot = n; }
        }
        // Once one widget is deferred, the rest wait too, so the order is kept.
        if (spot < 0 || rest.length > 0) { rest.push(q); return; }
        var pr = Math.floor(spot / columns), pc = spot % columns;
        for (var yy = pr; yy < pr + q.h; yy++) {
          for (var xx = pc; xx < pc + q.w; xx++) { cells[yy * columns + xx] = true; }
        }
        band.push({ id: q.id, col: pc, row: pr, w: q.w, h: q.h });
      });

      // Grow widgets right, then down, into any cell left empty.
      for (i = 0; i < cells.length; i++) {
        if (cells[i]) { continue; }
        var r2 = Math.floor(i / columns), c2 = i % columns;
        var left = null, above = null;
        band.forEach(function (p) {
          if (!left && p.col + p.w === c2 && p.row <= r2 && p.row + p.h > r2 && p.h === 1) { left = p; }
          if (!above && p.row + p.h === r2 && p.col === c2 && p.w === 1) { above = p; }
        });
        var grow = left || above;
        if (!grow) { continue; }
        if (grow === left) { grow.w += 1; } else { grow.h += 1; }
        cells[i] = true;
      }

      band.forEach(function (p) { out.push({ id: p.id, col: p.col, row: p.row + row, w: p.w, h: p.h }); });
      row += height;
      queue = rest;
    }
    return out;
  }

  // Reorders items to the reading order of their layout, when that gives the same layout.
  function canonical(items, columns) {
    var places = layout(items, columns);
    if (places.length !== items.length) { return items; }
    var byId = Object.create(null);
    items.forEach(function (item) { byId[item.id] = item; });
    var sorted = places.slice().sort(reading).map(function (p) { return byId[p.id]; });
    if (sorted.every(function (item, i) { return item === items[i]; })) { return items; }
    var at = Object.create(null);
    places.forEach(function (p) { at[p.id] = p; });
    var same = layout(sorted, columns).every(function (p) {
      var q = at[p.id];
      return q && q.col === p.col && q.row === p.row && q.w === p.w && q.h === p.h;
    });
    return same ? sorted : items;
  }

  function moveTo(items, id, index) {
    var from = -1;
    for (var i = 0; i < items.length; i++) { if (items[i].id === id) { from = i; break; } }
    if (from < 0 || from === index || index < 0 || index >= items.length) { return items; }
    var next = items.slice();
    var moved = next.splice(from, 1)[0];
    next.splice(index, 0, moved);
    return next;
  }

  function sameOrder(a, b) {
    if (a.length !== b.length) { return false; }
    for (var i = 0; i < a.length; i++) { if (a[i].id !== b[i].id) { return false; } }
    return true;
  }

  // A saved order, made safe against the widgets that exist now: unknown and repeated ids
  // are dropped, and widgets added since the save follow in their current order. Anything
  // that is not a list of ids is ignored.
  function sanitizeOrder(saved, current) {
    var known = Object.create(null), seen = Object.create(null), out = [];
    current.forEach(function (id) { known[id] = true; });
    if (Array.isArray(saved)) {
      saved.forEach(function (id) {
        if (typeof id === 'string' && known[id] && !seen[id]) { seen[id] = true; out.push(id); }
      });
    }
    current.forEach(function (id) { if (!seen[id]) { seen[id] = true; out.push(id); } });
    return out;
  }

  /* ---- Drop target selection ---------------------------------------------------- */
  // Fraction of a slot the dragged widget's centre must enter to take it.
  var ENTER = 0.18;

  // Picks the arrangement whose slot for the dragged widget is nearest its centre, or null
  // to keep the current one. Candidates are measured to a slot shrunk by ENTER, the current
  // slot unshrunk, so every accepted move strictly reduces that distance and the widget can
  // never oscillate between two arrangements. Slots are {left, top, right, bottom}.
  function choose(home, candidates, cx, cy) {
    function distance(s, inset) {
      var ix = (s.right - s.left) * inset, iy = (s.bottom - s.top) * inset;
      var dx = Math.max(s.left + ix - cx, 0, cx - (s.right - ix));
      var dy = Math.max(s.top + iy - cy, 0, cy - (s.bottom - iy));
      return Math.sqrt(dx * dx + dy * dy);
    }
    function toCentre(s) {
      var dx = (s.left + s.right) / 2 - cx, dy = (s.top + s.bottom) / 2 - cy;
      return Math.sqrt(dx * dx + dy * dy);
    }
    var best = distance(home, 0);
    if (best === 0) { return null; }
    var pick = null, bestCentre = Infinity;
    for (var i = 0; i < candidates.length; i++) {
      var d = distance(candidates[i].slot, ENTER);
      var c = toCentre(candidates[i].slot);
      // On a tie the earlier candidate wins; group swaps are listed first.
      if (d < best || (d === best && pick && c < bestCentre)) {
        best = d;
        bestCentre = c;
        pick = candidates[i].order;
      }
    }
    return pick;
  }

  // Every arrangement one move away from `items`, each with the slot the dragged widget
  // would then occupy (toSlot maps a {col, row, w, h} box to a slot):
  //  - group swaps: a same-shaped area filled entirely by smaller widgets trades places with
  //    the dragged widget, keeping its internal arrangement;
  //  - sequence moves: the dragged widget takes another index.
  function candidatesFor(items, id, columns, toSlot) {
    var places = layout(items, columns);
    var me = find(places, id);
    if (!me) { return []; }
    var byId = Object.create(null);
    items.forEach(function (item) { byId[item.id] = item; });
    var rows = Math.max.apply(null, places.map(function (p) { return p.row + p.h; }));
    var out = [];

    for (var row = 0; row + me.h <= rows; row++) {
      for (var col = 0; col + me.w <= columns; col++) {
        var area = { col: col, row: row, w: me.w, h: me.h };
        if (overlaps(area, me)) { continue; }
        var group = places.filter(function (p) { return overlaps(p, area); });
        if (group.length < 2 || !group.every(function (p) { return contains(area, p); })) { continue; }
        var moved = places.map(function (p) {
          if (p.id === id) { return { id: p.id, col: col, row: row, w: p.w, h: p.h }; }
          if (group.indexOf(p) >= 0) {
            return { id: p.id, col: p.col - col + me.col, row: p.row - row + me.row, w: p.w, h: p.h };
          }
          return p;
        });
        moved.sort(reading);
        var order = moved.map(function (p) { return byId[p.id]; });
        if (!sameOrder(order, items)) { out.push({ order: order, slot: toSlot(area) }); }
      }
    }

    var from = -1;
    for (var i = 0; i < items.length; i++) { if (items[i].id === id) { from = i; break; } }
    for (var j = 0; j < items.length; j++) {
      if (j === from) { continue; }
      var next = moveTo(items, id, j);
      var p2 = find(layout(next, columns), id);
      if (p2) { out.push({ order: next, slot: toSlot(p2) }); }
    }
    return out;
  }

  /* ---- One column: natural heights ---------------------------------------------- */
  // Fixed row height (px) of the multi-column layouts: square cells scaled by `ratio`, but never
  // shorter than `minRow` (optional): a small window makes narrow cells, and a widget with a
  // fixed amount of text and controls needs a minimum height however narrow it gets.
  // Zero means natural: with one column there are no cells, and every widget is as tall as
  // its content (a phone would otherwise get a tall, mostly blank square for each widget).
  function rowHeight(unit, ratio, columns, minRow) {
    if (columns === 1) { return 0; }
    var h = Math.round(unit * ratio);
    return minRow > 0 ? Math.max(h, Math.round(minRow)) : h;
  }

  // Drop-target geometry for ONE column of widgets with different heights. `heights` maps id
  // to px and `geo` is {left, top, width, gap} of the column. Returns where the dragged
  // widget sits now (home) and where it would sit at every other position, each with the
  // arrangement that puts it there: measured from the real heights, not from uniform slots.
  function columnSlots(items, id, heights, geo) {
    function slotIn(list) {
      var y = geo.top;
      for (var i = 0; i < list.length; i++) {
        var h = heights[list[i].id] || 0;
        if (list[i].id === id) { return { left: geo.left, top: y, right: geo.left + geo.width, bottom: y + h }; }
        y += h + geo.gap;
      }
      return null;
    }
    var home = slotIn(items), candidates = [];
    if (!home) { return { home: null, candidates: candidates }; }
    for (var j = 0; j < items.length; j++) {
      var next = moveTo(items, id, j);
      if (next !== items) { candidates.push({ order: next, slot: slotIn(next) }); }
    }
    return { home: home, candidates: candidates };
  }

  /* ---- Engine ------------------------------------------------------------------- */
  var SETTLE_MS = 40;        // minimum time between two reorders during a drag
  var LANDED_MS = 620;       // how long is-landed stays on a dropped widget
  var FLIP_MS = 260;
  var FLIP_EASE = 'cubic-bezier(0.2, 0.7, 0.2, 1)';
  var DRAG_SLOP = 3;         // px the pointer must travel before a press becomes a drag

  function mount(grid, opts) {
    if (grid._widgetGrid) { return grid._widgetGrid; }
    opts = opts || {};
    var doc = grid.ownerDocument;
    var win = doc.defaultView;
    var maxColumns = Math.max(1, opts.maxColumns || 4);
    var cellSize = opts.cellSize > 0 ? opts.cellSize : 300;
    // Optional: only these column counts may be used (e.g. [1, 2, 4] to avoid counts a
    // given widget set cannot tile exactly). The largest allowed count that fits wins.
    var allowed = Array.isArray(opts.columns) && opts.columns.length
      ? opts.columns.filter(function (n) { return n >= 1; }).sort(function (a, b) { return a - b; })
      : null;
    var storageKey = grid.getAttribute('data-storage-key') || '';
    var rowRatio = parseFloat(grid.getAttribute('data-row-ratio')) || 1;
    var minRow = parseFloat(grid.getAttribute('data-min-row')) || 0;

    // Widgets: the [data-widget] children of the grid.
    var els = Object.create(null), items = Object.create(null), ids = [];
    Array.prototype.forEach.call(grid.children, function (el) {
      var id = el.getAttribute('data-widget');
      if (!id || els[id]) { return; }
      var size = el.getAttribute('data-size');
      els[id] = el;
      items[id] = { id: id, size: Object.prototype.hasOwnProperty.call(SPANS, size) ? size : 'sm' };
      ids.push(id);
    });
    var original = ids.slice();

    var order = sanitizeOrder(load(), ids);
    var columns = maxColumns, unit = 0, colGap = 0, rowGap = 0, rowH = 0;
    var placements = [];
    var anims = Object.create(null);     // our running slide animations, by widget id
    var drag = null;                     // the press or drag in progress
    var dragId = null;                   // set once a press has become a drag
    var frame = 0, lastMove = 0;
    var landed = null;                   // {el, timer}
    var live = null, madeLive = false;
    var observer = null;

    function motionOn() { return doc.documentElement.classList.contains('motion'); }
    function seq() { return order.map(function (id) { return items[id]; }); }

    /* -- storage: every access may throw (private windows, blocked site data) -- */
    function load() {
      if (!storageKey) { return null; }
      try {
        var raw = win.localStorage.getItem(storageKey);
        if (!raw) { return null; }
        var data = JSON.parse(raw);
        return data && data.v === 1 && Array.isArray(data.order) ? data.order : null;
      } catch (e) { return null; }
    }
    function persist() {
      if (!storageKey) { return; }
      try { win.localStorage.setItem(storageKey, JSON.stringify({ v: 1, order: order })); } catch (e) {}
    }
    function forget() {
      if (!storageKey) { return; }
      try { win.localStorage.removeItem(storageKey); } catch (e) {}
    }

    /* -- geometry -- */
    function measure() {
      var width = grid.getBoundingClientRect().width;
      if (width < 1) { return null; }
      var cs = win.getComputedStyle(grid);
      var cg = parseFloat(cs.columnGap);
      if (!(cg >= 0)) { cg = 0; }
      var rg = parseFloat(cs.rowGap);
      if (!(rg >= 0)) { rg = cg; }
      var cols = Math.max(1, Math.min(maxColumns, Math.round(width / cellSize)));
      if (allowed) {
        var pick = allowed[0];
        allowed.forEach(function (n) { if (n <= cols) { pick = n; } });
        cols = pick;
      }
      return { columns: cols, colGap: cg, rowGap: rg, unit: (width - cg * (cols - 1)) / cols };
    }

    // Viewport rectangle of a {col, row, w, h} box in the settled layout.
    function toSlot(box) {
      var rect = grid.getBoundingClientRect();
      var colStep = unit + colGap, rowStep = rowH + rowGap;
      var left = rect.left + box.col * colStep, top = rect.top + box.row * rowStep;
      return { left: left, top: top, right: left + box.w * colStep - colGap, bottom: top + box.h * rowStep - rowGap };
    }

    // One column of natural heights: the slots come from the widgets' real heights. The
    // dragged widget's own height is its layout height (a CSS scale on it does not change it);
    // the others' are measured, so a slide in progress cannot skew them.
    function column() {
      var rect = grid.getBoundingClientRect(), cs = win.getComputedStyle(grid);
      var px = function (name) { var n = parseFloat(cs[name]); return n > 0 ? n : 0; };
      var heights = Object.create(null);
      ids.forEach(function (id) {
        heights[id] = id === dragId ? els[id].offsetHeight : els[id].getBoundingClientRect().height;
      });
      return columnSlots(seq(), dragId, heights, {
        left: rect.left + px('borderLeftWidth') + px('paddingLeft'),
        top: rect.top + px('borderTopWidth') + px('paddingTop'),
        width: rect.width - px('borderLeftWidth') - px('paddingLeft') - px('borderRightWidth') - px('paddingRight'),
        gap: rowGap
      });
    }

    /* -- animation: FLIP with the Web Animations API -- */
    function play(id, el, from, to) {
      if (!el.animate) { return; }
      if (anims[id]) { anims[id].cancel(); }
      var anim = el.animate([{ transform: from }, { transform: to }], { duration: FLIP_MS, easing: FLIP_EASE });
      anims[id] = anim;
      var clear = function () { if (anims[id] === anim) { delete anims[id]; } };
      anim.onfinish = clear;
      anim.oncancel = clear;
    }
    function snapshot() {
      var rects = Object.create(null);
      ids.forEach(function (id) { if (id !== dragId) { rects[id] = els[id].getBoundingClientRect(); } });
      return rects;
    }
    function cancelAnimations() {
      Object.keys(anims).forEach(function (id) { if (id !== dragId) { anims[id].cancel(); } });
    }
    function flip(before) {
      ids.forEach(function (id) {
        var b = before[id];
        if (!b) { return; }
        var a = els[id].getBoundingClientRect();
        var dx = b.left - a.left, dy = b.top - a.top;
        if (Math.abs(dx) < 0.5 && Math.abs(dy) < 0.5) { return; }
        play(id, els[id], 'translate(' + dx + 'px, ' + dy + 'px)', 'none');
      });
    }

    /* -- applying a layout -- */
    function apply(animate) {
      var before = null;
      if (animate && motionOn()) {
        before = snapshot();     // measured with any running slide included, so an interrupted move is smooth
        cancelAnimations();
      }
      grid.style.display = 'grid';
      grid.style.gridTemplateColumns = 'repeat(' + columns + ', minmax(0, 1fr))';
      grid.style.gridAutoRows = rowH ? rowH + 'px' : 'auto';
      grid.setAttribute('data-cols', String(columns));
      if (columns === 1) {
        // No cells: whatever its size, a widget is one column wide and as tall as its content,
        // one per auto-sized row, in sequence (an explicit row keeps a moved widget where the
        // sequence says, since the DOM order never changes).
        placements = seq().map(function (item, i) { return { id: item.id, col: 0, row: i, w: 1, h: 1 }; });
        placements.forEach(function (p) {
          els[p.id].style.gridColumn = '1';
          els[p.id].style.gridRow = String(p.row + 1);
        });
      } else {
        placements = layout(seq(), columns);
        placements.forEach(function (p) {
          var el = els[p.id];
          el.style.gridColumn = (p.col + 1) + ' / span ' + p.w;
          el.style.gridRow = (p.row + 1) + ' / span ' + p.h;
        });
      }
      semantics();
      if (before) { flip(before); }
    }

    // Roles, reading-order positions, and the enabled state of the first and last buttons.
    function semantics() {
      grid.setAttribute('role', 'list');
      var visual = placements.slice().sort(reading);
      visual.forEach(function (p, i) {
        var el = els[p.id];
        el.setAttribute('role', 'listitem');
        el.setAttribute('aria-posinset', String(i + 1));
        el.setAttribute('aria-setsize', String(visual.length));
      });
      order.forEach(function (id, i) {
        Array.prototype.forEach.call(els[id].querySelectorAll('[data-widget-move]'), function (btn) {
          var dir = parseInt(btn.getAttribute('data-widget-move'), 10);
          var off = (dir < 0 && i === 0) || (dir > 0 && i === order.length - 1);
          btn.setAttribute('aria-disabled', off ? 'true' : 'false');
        });
      });
    }

    function positionOf(id) {
      var visual = placements.slice().sort(reading);
      for (var i = 0; i < visual.length; i++) { if (visual[i].id === id) { return i + 1; } }
      return 0;
    }

    function announce(message) {
      if (!live) {
        var host = grid.parentNode || doc.body;
        live = host.querySelector('[data-widget-live]');
        if (!live) {
          live = doc.createElement('p');
          live.className = 'sr-only';
          live.setAttribute('role', 'status');
          live.setAttribute('aria-live', 'polite');
          live.setAttribute('data-widget-live', '');
          host.insertBefore(live, grid);
          madeLive = true;
        }
      }
      live.textContent = '';
      win.setTimeout(function () { live.textContent = message; }, 30);
    }

    function changed(id) {
      grid.dispatchEvent(new win.CustomEvent('f2f:widgets-changed', { bubbles: true, detail: { order: order.slice() } }));
      if (id) {
        announce((els[id].getAttribute('aria-label') || id) + ' moved to position ' + positionOf(id) + ' of ' + ids.length);
      }
    }

    function commit(next, animate) {
      order = next.map(function (item) { return item.id; });
      apply(animate);
    }

    /* -- moving one step (buttons and keys) -- */
    function move(id, delta) {
      var current = seq();
      var from = order.indexOf(id);
      if (from < 0) { return false; }
      // Step until the layout actually changes: some steps swap two equal-shaped widgets.
      for (var to = from + delta; to >= 0 && to < current.length; to += delta) {
        var next = canonical(moveTo(current, id, to), columns);
        if (sameOrder(next, current)) { continue; }
        commit(next, true);
        persist();
        changed(id);
        return true;
      }
      return false;
    }

    function widgetOf(node) {
      var el = node && node.closest ? node.closest('[data-widget]') : null;
      return el && el.parentNode === grid ? el : null;
    }

    function onClick(e) {
      var btn = e.target.closest ? e.target.closest('[data-widget-move]') : null;
      var el = btn && widgetOf(btn);
      if (!el || btn.getAttribute('aria-disabled') === 'true') { return; }
      move(el.getAttribute('data-widget'), parseInt(btn.getAttribute('data-widget-move'), 10) < 0 ? -1 : 1);
    }

    function onKey(e) {
      if (!e.altKey || e.ctrlKey || e.metaKey || e.shiftKey) { return; }
      var delta = e.key === 'ArrowRight' || e.key === 'ArrowDown' ? 1
        : e.key === 'ArrowLeft' || e.key === 'ArrowUp' ? -1 : 0;
      if (!delta) { return; }
      var el = widgetOf(e.target);
      if (!el || (e.target.closest && e.target.closest('input, textarea, select, [contenteditable=""], [contenteditable="true"]'))) { return; }
      e.preventDefault();      // Alt + arrow is Back / Forward in most browsers
      move(el.getAttribute('data-widget'), delta);
    }

    /* -- dragging -- */
    // The dragged widget sits in its slot; a transform carries it to the pointer.
    function follow() {
      if (!drag) { return; }
      var p = find(placements, dragId);
      var slot = columns === 1 ? column().home : p && toSlot(p);
      if (!slot) { return; }
      drag.el.style.transform = 'translate(' + (drag.x - drag.grabX - slot.left) + 'px, ' + (drag.y - drag.grabY - slot.top) + 'px)';
    }

    function step(force) {
      frame = 0;
      if (!dragId) { return; }
      var now = win.performance.now();
      if (!force && now - lastMove < SETTLE_MS) {
        // Try again next frame, so a widget held still still settles.
        frame = win.requestAnimationFrame(function () { step(false); });
        return;
      }
      var r = drag.el.getBoundingClientRect();
      var cx = r.left + r.width / 2, cy = r.top + r.height / 2, next;
      if (columns === 1) {
        var col = column();
        next = col.home && choose(col.home, col.candidates, cx, cy);
      } else {
        var me = find(placements, dragId);
        if (!me) { return; }
        next = choose(toSlot(me), candidatesFor(seq(), dragId, columns, toSlot), cx, cy);
        if (next) { next = canonical(next, columns); }
      }
      if (!next) { return; }
      lastMove = now;
      commit(next, true);
      follow();      // its slot moved; keep it under the pointer
    }

    function schedule() {
      if (!frame) { frame = win.requestAnimationFrame(function () { step(false); }); }
    }

    function blockSelect(e) { e.preventDefault(); }

    function beginDrag() {
      dragId = drag.id;
      drag.started = true;
      drag.startOrder = order.slice();
      lastMove = 0;
      if (anims[dragId]) { anims[dragId].cancel(); }
      if (landed) { win.clearTimeout(landed.timer); landed.el.classList.remove('is-landed'); landed = null; }
      grid.classList.add('is-dragging');
      drag.el.classList.add('is-lifted');
      doc.addEventListener('selectstart', blockSelect);
    }

    function onPointerDown(e) {
      var handle = e.target.closest ? e.target.closest('[data-widget-handle]') : null;
      var el = handle && widgetOf(handle);
      if (!el || drag || e.button !== 0 || e.isPrimary === false) { return; }
      var rect = el.getBoundingClientRect();
      drag = {
        id: el.getAttribute('data-widget'), el: el, pointerId: e.pointerId, started: false,
        startX: e.clientX, startY: e.clientY, x: e.clientX, y: e.clientY,
        grabX: e.clientX - rect.left, grabY: e.clientY - rect.top, startOrder: null
      };
      try { handle.setPointerCapture(e.pointerId); } catch (err) {}
      win.addEventListener('pointermove', onPointerMove);
      win.addEventListener('pointerup', onPointerEnd);
      win.addEventListener('pointercancel', onPointerEnd);
    }

    function onPointerMove(e) {
      if (!drag || e.pointerId !== drag.pointerId) { return; }
      drag.x = e.clientX;
      drag.y = e.clientY;
      if (!drag.started) {
        if (Math.abs(drag.x - drag.startX) + Math.abs(drag.y - drag.startY) < DRAG_SLOP) { return; }
        beginDrag();
      }
      follow();
      schedule();
    }

    function onPointerEnd(e) {
      if (!drag || e.pointerId !== drag.pointerId) { return; }
      win.removeEventListener('pointermove', onPointerMove);
      win.removeEventListener('pointerup', onPointerEnd);
      win.removeEventListener('pointercancel', onPointerEnd);
      var d = drag;
      if (!d.started) { drag = null; return; }   // a plain click on the handle
      win.cancelAnimationFrame(frame);
      step(true);
      frame = 0;
      drag = null;
      var released = d.el.style.transform;
      d.el.style.transform = '';
      dragId = null;
      d.el.classList.remove('is-lifted');
      grid.classList.remove('is-dragging');
      doc.removeEventListener('selectstart', blockSelect);
      if (motionOn() && released) { play(d.id, d.el, released, 'none'); }   // slide into the slot from where it was let go
      d.el.classList.add('is-landed');
      var timer = win.setTimeout(function () {
        d.el.classList.remove('is-landed');
        if (landed && landed.el === d.el) { landed = null; }
      }, LANDED_MS);
      landed = { el: d.el, timer: timer };
      var moved = d.startOrder.join('|') !== order.join('|');
      if (moved) { persist(); changed(d.id); }
    }

    /* -- reset, resize -- */
    function reset() {
      forget();
      order = original.slice();
      order = canonical(seq(), columns).map(function (item) { return item.id; });
      apply(true);
      grid.dispatchEvent(new win.CustomEvent('f2f:widgets-changed', { bubbles: true, detail: { order: order.slice() } }));
      announce('Layout reset');
    }

    function relayout() {
      var m = measure();
      if (!m) { return; }
      var columnsChanged = m.columns !== columns;
      if (!columnsChanged && Math.abs(m.unit - unit) < 0.5 && m.colGap === colGap) { return; }
      columns = m.columns;
      unit = m.unit;
      colGap = m.colGap;
      rowGap = m.rowGap;
      rowH = rowHeight(unit, rowRatio, columns, minRow);
      order = canonical(seq(), columns).map(function (item) { return item.id; });
      apply(columnsChanged);     // a plain width change just scales; a new column count slides
    }

    /* -- wire up -- */
    var resets = Array.prototype.slice.call(doc.querySelectorAll('[data-widget-reset]'));
    var handles = [];
    ids.forEach(function (id) {
      Array.prototype.forEach.call(els[id].querySelectorAll('[data-widget-handle]'), function (h) {
        h.style.touchAction = 'none';
        handles.push(h);
      });
    });

    var m0 = measure();
    if (m0) { columns = m0.columns; unit = m0.unit; colGap = m0.colGap; rowGap = m0.rowGap; rowH = rowHeight(unit, rowRatio, columns, minRow); }
    order = canonical(seq(), columns).map(function (item) { return item.id; });
    apply(false);

    grid.addEventListener('click', onClick);
    grid.addEventListener('keydown', onKey);
    grid.addEventListener('pointerdown', onPointerDown);
    resets.forEach(function (b) { b.addEventListener('click', reset); });
    if ('ResizeObserver' in win) {
      observer = new win.ResizeObserver(relayout);
      observer.observe(grid);
    } else {
      win.addEventListener('resize', relayout);
    }

    var api = {
      order: function () { return order.slice(); },
      reset: reset,
      destroy: function () {
        grid.removeEventListener('click', onClick);
        grid.removeEventListener('keydown', onKey);
        grid.removeEventListener('pointerdown', onPointerDown);
        win.removeEventListener('pointermove', onPointerMove);
        win.removeEventListener('pointerup', onPointerEnd);
        win.removeEventListener('pointercancel', onPointerEnd);
        win.removeEventListener('resize', relayout);
        doc.removeEventListener('selectstart', blockSelect);
        resets.forEach(function (b) { b.removeEventListener('click', reset); });
        if (observer) { observer.disconnect(); }
        win.cancelAnimationFrame(frame);
        if (landed) { win.clearTimeout(landed.timer); landed.el.classList.remove('is-landed'); }
        Object.keys(anims).forEach(function (id) { anims[id].cancel(); });
        ids.forEach(function (id) {
          var el = els[id];
          el.style.gridColumn = '';
          el.style.gridRow = '';
          el.style.transform = '';
          el.classList.remove('is-lifted');
          ['role', 'aria-posinset', 'aria-setsize'].forEach(function (a) { el.removeAttribute(a); });
          Array.prototype.forEach.call(el.querySelectorAll('[data-widget-move]'), function (btn) { btn.removeAttribute('aria-disabled'); });
        });
        handles.forEach(function (h) { h.style.touchAction = ''; });
        grid.style.display = '';
        grid.style.gridTemplateColumns = '';
        grid.style.gridAutoRows = '';
        grid.removeAttribute('data-cols');
        grid.removeAttribute('role');
        grid.classList.remove('is-dragging');
        if (madeLive && live && live.parentNode) { live.parentNode.removeChild(live); }
        delete grid._widgetGrid;
      }
    };
    grid._widgetGrid = api;
    return api;
  }

  var api = {
    layout: layout, canonical: canonical, moveTo: moveTo, sanitizeOrder: sanitizeOrder,
    candidatesFor: candidatesFor, choose: choose, spanOf: spanOf, sameOrder: sameOrder,
    rowHeight: rowHeight, columnSlots: columnSlots, mount: mount
  };
  if (typeof module === 'object' && module.exports) { module.exports = api; }
  else { (root.F2F = root.F2F || {}).WidgetGrid = api; }
})(typeof window !== 'undefined' ? window : globalThis);
