/* Batch predictions: the pure logic behind the Batch widget. No DOM, no network; node-testable.
     - parseCsv: RFC 4180 (quoted cells, doubled quotes, line breaks inside quotes), a leading
       byte-order mark, CRLF / LF / CR endings, and comma / semicolon / tab delimiters (comma wins a
       tie). Unquoted cells are trimmed; blank lines at the top and bottom are dropped.
     - columnMap / toRequestRows: find the four inputs by name (case, spaces, hyphens and underscores
       do not matter), or, for a file with no header and exactly four columns, read it in the standard
       order. At most LIMIT rows are sent; the caller says so when there were more.
     - resultsToCsv: the download. Every cell a person typed is defused against spreadsheet formulas
       (a leading = + - @ tab or CR gets an apostrophe), and lines end in CRLF.
   Nothing here reaches the model: the server checks every value again and reports errors per row. */
(function (root) {
  'use strict';

  var LIMIT = 200;
  var MAX_CHARS = 100000;
  var KEYS = ['ligand', 'additive', 'base', 'aryl_halide'];
  var ALIASES = { ligand: ['ligand'], additive: ['additive'], base: ['base'], aryl_halide: ['arylhalide', 'halide'] };
  var RESULT_HEADER = ['row', 'ligand', 'additive', 'base', 'aryl_halide', 'prediction', 'failure_probability', 'confidence', 'error'];

  function isBlank(cells) {
    for (var i = 0; i < cells.length; i++) { if (cells[i] !== '') { return false; } }
    return true;
  }

  // The delimiter is read off the first line that has anything on it, ignoring quoted text.
  function detectDelimiter(text) {
    var counts = { ',': 0, ';': 0, '\t': 0 };
    var quoted = false, seen = false;
    for (var i = 0; i < text.length; i++) {
      var c = text.charAt(i);
      if (c === '"') { quoted = !quoted; seen = true; continue; }
      if (quoted) { continue; }
      if (c === '\n' || c === '\r') { if (seen) { break; } continue; }
      if (c !== ' ' && c !== '\t') { seen = true; }
      if (counts.hasOwnProperty(c)) { counts[c]++; }
    }
    var best = ',';
    if (counts[';'] > counts[best]) { best = ';'; }
    if (counts['\t'] > counts[best]) { best = '\t'; }
    return best;
  }

  // States: 0 = at the start of a cell (blanks skipped), 1 = plain text, 2 = inside quotes, 3 = after
  // the closing quote. Returns null when a quote is never closed.
  function readRecords(text, d) {
    var records = [], rec = [], cell = '', state = 0;
    function endCell() { rec.push(state === 1 ? cell.replace(/\s+$/, '') : cell); cell = ''; state = 0; }
    function endRow() { endCell(); records.push(rec); rec = []; }
    for (var i = 0; i < text.length; i++) {
      var c = text.charAt(i);
      if (state === 2) {
        if (c !== '"') { cell += c; }
        else if (text.charAt(i + 1) === '"') { cell += '"'; i++; }
        else { state = 3; }
        continue;
      }
      if (c === d) { endCell(); continue; }
      if (c === '\r' || c === '\n') {
        if (c === '\r' && text.charAt(i + 1) === '\n') { i++; }
        endRow();
        continue;
      }
      if (state === 0) {
        if (c === '"') { state = 2; }
        else if (c !== ' ' && c !== '\t') { state = 1; cell += c; }
      } else if (state === 1) {
        cell += c;
      } else if (c !== ' ' && c !== '\t') {
        cell += c;
      }
    }
    if (state === 2) { return null; }
    if (rec.length || cell !== '' || state !== 0) { endRow(); }
    return records;
  }

  function parseCsv(text) {
    if (typeof text !== 'string') { return { ok: false, error: 'That is not text I can read.' }; }
    if (text.length > MAX_CHARS) {
      return { ok: false, error: 'That file is too large: the limit is ' + MAX_CHARS + ' characters.' };
    }
    if (text.charAt(0) === '\uFEFF') { text = text.slice(1); }
    var delimiter = detectDelimiter(text);
    var records = readRecords(text, delimiter);
    if (records === null) { return { ok: false, error: 'A quote is never closed, so the rest of the file cannot be read.' }; }
    while (records.length && isBlank(records[records.length - 1])) { records.pop(); }
    while (records.length && isBlank(records[0])) { records.shift(); }
    if (!records.length) { return { ok: false, error: 'The file is empty.' }; }
    return { ok: true, header: records[0], rows: records.slice(1), delimiter: delimiter };
  }

  function normalizeName(s) {
    return String(s === null || s === undefined ? '' : s).toLowerCase().replace(/[\s_\-]+/g, '');
  }

  function columnMap(header) {
    var map = {}, missing = [];
    var names = Array.isArray(header) ? header.map(normalizeName) : [];
    KEYS.forEach(function (key) {
      for (var i = 0; i < names.length; i++) {
        if (ALIASES[key].indexOf(names[i]) !== -1) { map[key] = i; return; }
      }
      missing.push(key);
    });
    return { map: map, missing: missing };
  }

  function cellAt(row, i) {
    var v = row[i];
    return (v === undefined || v === null) ? '' : String(v).trim();
  }

  function toRequestRows(parsed) {
    var out = { rows: [], skipped: 0, missing: [], assumedOrder: false, tooMany: false, count: 0 };
    if (!parsed || !parsed.ok) { out.error = (parsed && parsed.error) || 'The file could not be read.'; return out; }
    var cols = columnMap(parsed.header), map = cols.map, data = parsed.rows;
    if (Object.keys(map).length === 0 && parsed.header.length === KEYS.length) {
      out.assumedOrder = true;                       // no header: the first line is data, in the standard order
      map = { ligand: 0, additive: 1, base: 2, aryl_halide: 3 };
      data = [parsed.header].concat(parsed.rows);
    } else if (cols.missing.length) {
      out.missing = cols.missing;
      return out;
    }
    data.forEach(function (cells) {
      var req = {};
      KEYS.forEach(function (key) { req[key] = cellAt(cells, map[key]); });
      if (KEYS.every(function (key) { return req[key] === ''; })) { out.skipped++; return; }
      out.count++;
      if (out.rows.length < LIMIT) { out.rows.push(req); }
    });
    out.tooMany = out.count > LIMIT;
    return out;
  }

  function template() {
    var lines = ['Ligand,Additive,Base,Aryl halide'];
    for (var i = 1; i <= 3; i++) { lines.push('Ligand ' + i + ',Additive ' + i + ',Base ' + i + ',Aryl halide ' + i); }
    return lines.join('\n') + '\n';
  }

  // A spreadsheet treats a cell that starts with = + - @ tab or CR as a formula. Only real strings
  // (what a person typed) are defused; numbers we format ourselves pass through as they are.
  function sanitizeCell(v) {
    if (v === null || v === undefined) { return ''; }
    if (typeof v !== 'string') { return String(v); }
    return /^[=+\-@\t\r]/.test(v) ? "'" + v : v;
  }

  function csvField(v) {
    var s = sanitizeCell(v);
    return /[",\r\n]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s;
  }

  function fixed4(x) { return (typeof x === 'number' && isFinite(x)) ? x.toFixed(4) : ''; }

  function resultsToCsv(results) {
    var lines = [RESULT_HEADER.join(',')];
    (Array.isArray(results) ? results : []).forEach(function (r) {
      var inputs = (r && r.inputs) || {};
      var cells = [r.row].concat(KEYS.map(function (key) { return inputs[key]; }));
      if (r.ok) { cells.push(r.prediction, fixed4(r.failure_probability), fixed4(r.confidence), ''); }
      else { cells.push('', '', '', r.error); }
      lines.push(cells.map(csvField).join(','));
    });
    return lines.join('\r\n') + '\r\n';
  }

  function summarize(results) {
    var s = { ok: 0, failed: 0, predictedFailure: 0, predictedSuccess: 0, meanFailureProbability: null };
    var sum = 0, n = 0;
    (Array.isArray(results) ? results : []).forEach(function (r) {
      if (!r || !r.ok) { s.failed++; return; }
      s.ok++;
      if (r.prediction === 'Failure') { s.predictedFailure++; }
      else if (r.prediction === 'Success') { s.predictedSuccess++; }
      if (typeof r.failure_probability === 'number' && isFinite(r.failure_probability)) { sum += r.failure_probability; n++; }
    });
    if (n) { s.meanFailureProbability = sum / n; }
    return s;
  }

  var api = {
    LIMIT: LIMIT, MAX_CHARS: MAX_CHARS, KEYS: KEYS,
    parseCsv: parseCsv, columnMap: columnMap, toRequestRows: toRequestRows, template: template,
    sanitizeCell: sanitizeCell, csvField: csvField, resultsToCsv: resultsToCsv, summarize: summarize
  };
  if (typeof module === 'object' && module.exports) { module.exports = api; }
  else { (root.F2F = root.F2F || {}).Batch = api; }
})(typeof window !== 'undefined' ? window : globalThis);
