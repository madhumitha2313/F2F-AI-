/* Reaction-progress component, shared by the sign-in and sign-up pages.

   A small canvas scene: a hairline benzene ring, and one reagent atom per form field.
   An empty field is a dim, hollow, gray atom drifting in thermal jitter. Once its field
   is valid the atom fills indigo, glides to its ring vertex and a bond draws in with an
   electron pair riding it. Fill every field and the ring carries a full set of
   substituents: a little aryl amine, the product of the Buchwald-Hartwig coupling the
   landing page shows. The element labels (N, Pd, Br) are decoration, not a mechanism.

   Two layers, so the logic can be tested without a browser:
     - createModel(n): pure state and interpolation (no DOM, no clock). Advance it with
       step(dt seconds). Hand-rolled: linear tweens, plus one damped spring for the
       atom's glide, which is what gives the elastic snap-back.
     - mount(section): the canvas renderer and its single requestAnimationFrame loop.
       It pauses when the tab is hidden or the canvas is off screen. Canvas 2D only.

   Under prefers-reduced-motion nothing here runs: mount() returns null and the page
   shows the static step dots instead (see _reaction.html and auth.js). */
(function (root) {
  'use strict';

  var TAU = Math.PI * 2;
  var DEG = Math.PI / 180;

  /* ---- Geometry: a fixed 320 x 200 scene, scaled to fit the canvas ------------- */
  var W = 320, H = 200, CX = 160, CY = 100;
  var RING = 34;      // hexagon radius
  var REACH = 80;     // ring centre to an atom's home; the bond spans REACH - RING
  var ATOM_R = 15;

  // Where each atom drifts while its field is empty ("loose"), and which ring vertex it
  // bonds to when it is filled (an angle, degrees, y down). Two atoms sit para to each
  // other; three sit at alternate vertices (1,3,5).
  var ARRANGEMENTS = {
    2: { angles: [180, 0],       loose: [[34, 40],  [286, 162]] },
    3: { angles: [180, 300, 60], loose: [[34, 40],  [272, 34], [272, 166]] }
  };

  function polar(r, deg) {
    return { x: CX + r * Math.cos(deg * DEG), y: CY + r * Math.sin(deg * DEG) };
  }

  function layoutFor(n) {
    var a = ARRANGEMENTS[n];
    if (!a) { throw new RangeError('no arrangement for ' + n + ' atoms (supported: 2 or 3)'); }
    return {
      w: W, h: H, center: { x: CX, y: CY }, ring: RING,
      vertices: a.angles.map(function (d) { return polar(RING, d); }),
      anchors: a.angles.map(function (d) { return polar(REACH, d); }),
      loose: a.loose.map(function (p) { return { x: p[0], y: p[1] }; })
    };
  }

  /* ---- Model: pure state, advanced by step(dt) --------------------------------- */
  var K = 120;                        // spring stiffness of the glide (1/s^2)
  var ZETA = 0.7;                     // damping ratio: firm on the way in
  var ZETA_SNAP = 0.35;               // springy after a failure: overshoots ~30%
  var SUBSTEP = 1 / 240;              // fixed-size sub-steps keep the spring frame-rate independent
  var ARRIVED = 0.8;                  // a bond starts once the atom is this far along its glide
  var FILL_TIME = 0.25;               // seconds: gray -> indigo
  var BOND_FORM = 0.35;               // seconds: bond draws in
  var BOND_RETRACT = 0.18;            // seconds: bond pulls back when a field empties
  var PULSE_TIME = 0.6;               // seconds: the ring that radiates when an atom lights
  var SNAP_TIME = 0.45;               // seconds: fragments of a broken bond
  var SETTLE_TIME = 0.6;              // seconds: the success pulse

  function clamp01(x) { return x < 0 ? 0 : (x > 1 ? 1 : x); }
  function approach(x, target, delta) {
    return x < target ? Math.min(target, x + delta) : Math.max(target, x - delta);
  }

  function createModel(n) {
    var layout = layoutFor(n);
    var atoms = [];
    for (var i = 0; i < n; i++) {
      atoms.push({
        filled: false,   // what the field says (the target)
        fill: 0,         // 0 gray .. 1 indigo
        join: 0,         // 0 loose .. 1 at its ring vertex (the spring can overshoot both ends)
        vel: 0,
        bond: 0,         // 0 none .. 1 drawn
        pulse: 1,        // 0 just lit .. 1 finished (1 means no ring is showing)
        snap: 1,         // 0 just broke .. 1 finished
        zeta: ZETA
      });
    }
    var settle = null;       // seconds into the success pulse, or null
    var onSettled = null;

    var model = {
      layout: layout,
      atoms: atoms,

      setFilled: function (i, value) {
        var a = atoms[i];
        value = !!value;
        if (a.filled === value) { return; }
        a.filled = value;
        if (value) { a.pulse = 0; a.zeta = ZETA; }
      },

      step: function (dt) {
        dt = Math.min(dt, 0.1);
        var subs = Math.max(1, Math.ceil(dt / SUBSTEP));
        var h = dt / subs;
        atoms.forEach(function (a) {
          a.fill = approach(a.fill, a.filled ? 1 : 0, dt / FILL_TIME);
          if (a.filled) {
            if (a.join >= ARRIVED) { a.bond = Math.min(1, a.bond + dt / BOND_FORM); }
          } else if (a.bond > 0) {
            a.bond = Math.max(0, a.bond - dt / BOND_RETRACT);
          }
          // The atom stays home until its bond has pulled back, then drifts off.
          var target = (a.filled || a.bond > 0) ? 1 : 0;
          var c = 2 * a.zeta * Math.sqrt(K);
          for (var s = 0; s < subs; s++) {
            a.vel += (K * (target - a.join) - c * a.vel) * h;
            a.join += a.vel * h;
          }
          if (a.pulse < 1) { a.pulse = Math.min(1, a.pulse + dt / PULSE_TIME); }
          if (a.snap < 1) { a.snap = Math.min(1, a.snap + dt / SNAP_TIME); }
        });
        if (settle !== null) {
          settle += dt;
          if (settle >= SETTLE_TIME) {
            settle = null;
            var cb = onSettled;
            onSettled = null;
            if (cb) { cb(); }
          }
        }
      },

      // The request failed: every bond snaps at once, every atom dims and springs back.
      fail: function () {
        atoms.forEach(function (a) {
          if (a.bond > 0.5) { a.snap = 0; }
          a.bond = 0;
          a.filled = false;
          a.zeta = ZETA_SNAP;
        });
      },

      // The request worked: the assembled molecule settles, then cb runs once.
      success: function (cb) {
        settle = 0;
        onSettled = cb || null;
      },

      scale: function () { return settle === null ? 1 : 1 + 0.04 * Math.sin(Math.PI * settle / SETTLE_TIME); },
      flash: function () { return settle === null ? 0 : 0.7 * Math.sin(Math.PI * settle / SETTLE_TIME); },

      bondsFormed: function () {
        return atoms.filter(function (a) { return a.bond === 1; }).length;
      },
      assembled: function () { return model.bondsFormed() === n; },

      // Where atom i is drawn at time t (seconds): glide position plus thermal jitter.
      // A loose atom wanders a couple of pixels; a bonded one only vibrates.
      pos: function (i, t) {
        var a = atoms[i], l = layout.loose[i], c = layout.anchors[i];
        var amp = 2.2 * (1 - 0.85 * clamp01(a.join));
        var ph = i * 2.399;
        return {
          x: l.x + (c.x - l.x) * a.join + amp * (0.7 * Math.sin(t * 1.9 + ph) + 0.3 * Math.sin(t * 3.1 + ph * 1.7)),
          y: l.y + (c.y - l.y) * a.join + amp * (0.7 * Math.cos(t * 1.6 + ph * 1.3) + 0.3 * Math.sin(t * 2.7 + ph))
        };
      }
    };
    return model;
  }

  /* ---- Renderer ---------------------------------------------------------------- */
  var GROUND = '#0A0A0A';
  var INDIGO = [99, 102, 241];        // #6366F1, the app accent
  var GRAY = [113, 113, 122];         // #71717A, the app's muted

  function mix(a, b, f) {
    return 'rgb(' + Math.round(a[0] + (b[0] - a[0]) * f) + ',' +
      Math.round(a[1] + (b[1] - a[1]) * f) + ',' + Math.round(a[2] + (b[2] - a[2]) * f) + ')';
  }
  function rgba(c, a) { return 'rgba(' + c[0] + ',' + c[1] + ',' + c[2] + ',' + a + ')'; }

  function mount(section) {
    if (!document.documentElement.classList.contains('motion')) { return null; }   // reduced motion: no canvas
    var canvas = section.querySelector('[data-reaction-canvas]');
    var symbols = (section.getAttribute('data-atoms') || '').split(',');
    var ctx = canvas && canvas.getContext ? canvas.getContext('2d') : null;
    if (!ctx) { return null; }
    var model;
    try { model = createModel(symbols.length); } catch (e) { return null; }

    var L = model.layout;
    var n = symbols.length;
    var mono = (window.getComputedStyle(canvas).getPropertyValue('--mono') || '').trim() || 'monospace';
    var w = 0, h = 0, s = 1;
    var raf = 0, last = 0, visible = true;
    var waiters = [];

    function fit() {
      var rect = canvas.getBoundingClientRect();
      if (!rect.width || !rect.height) { return; }
      var dpr = Math.min(window.devicePixelRatio || 1, 2);
      canvas.width = Math.round(rect.width * dpr);
      canvas.height = Math.round(rect.height * dpr);
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      w = rect.width;
      h = rect.height;
      s = Math.min(w / W, h / H);
      draw(last / 1000);
    }

    function hexPath() {
      ctx.beginPath();
      for (var k = 0; k < 6; k++) {
        var p = polar(RING, k * 60);
        if (k) { ctx.lineTo(p.x, p.y); } else { ctx.moveTo(p.x, p.y); }
      }
      ctx.closePath();
    }

    // Ring, with the alternating inner lines of an aromatic ring.
    function drawRing(color, width) {
      ctx.strokeStyle = color;
      ctx.lineWidth = width;
      hexPath();
      ctx.stroke();
      ctx.lineWidth = width * 0.75;
      [0, 2, 4].forEach(function (k) {
        var a = polar(RING - 6, k * 60 + 12), b = polar(RING - 6, k * 60 + 48);
        ctx.beginPath();
        ctx.moveTo(a.x, a.y);
        ctx.lineTo(b.x, b.y);
        ctx.stroke();
      });
    }

    // The bond runs from the ring vertex to the edge of the atom, so its length follows the
    // (jittering) atom. Returns null when there is nothing to draw.
    function bondSegment(i, p, progress) {
      var v = L.vertices[i];
      var dx = p.x - v.x, dy = p.y - v.y;
      var dist = Math.sqrt(dx * dx + dy * dy) || 1;
      var ux = dx / dist, uy = dy / dist;
      var len = Math.max(0, dist - ATOM_R) * progress;
      return { v: v, ux: ux, uy: uy, ex: v.x + ux * len, ey: v.y + uy * len };
    }

    function line(x1, y1, x2, y2) {
      ctx.beginPath();
      ctx.moveTo(x1, y1);
      ctx.lineTo(x2, y2);
      ctx.stroke();
    }

    function drawBonds(t, positions) {
      model.atoms.forEach(function (a, i) {
        var p = positions[i];
        if (a.bond > 0) {
          var g = bondSegment(i, p, a.bond);
          ctx.strokeStyle = rgba(INDIGO, 1);
          ctx.lineWidth = 2.2;
          line(g.v.x, g.v.y, g.ex, g.ey);
          if (a.bond < 1) {
            // the electron pair leading the bond in
            ctx.fillStyle = 'rgba(255,255,255,0.95)';
            ctx.beginPath();
            ctx.arc(g.ex, g.ey, 2.4, 0, TAU);
            ctx.fill();
          } else {
            // a faint dash keeps travelling along a finished bond
            ctx.save();
            ctx.setLineDash([3, 9]);
            ctx.lineDashOffset = -t * 14;
            ctx.strokeStyle = 'rgba(255,255,255,0.55)';
            ctx.lineWidth = 1.1;
            line(g.v.x, g.v.y, g.ex, g.ey);
            ctx.restore();
          }
        }
        if (a.snap < 1) {
          // a broken bond: two stubs pull away from the break, with a small spark
          var f = bondSegment(i, p, 1);
          var life = 1 - a.snap;
          var stub = (REACH - RING - ATOM_R) * 0.4 * life;
          ctx.strokeStyle = rgba(INDIGO, life);
          ctx.lineWidth = 2.2;
          line(f.v.x, f.v.y, f.v.x + f.ux * stub, f.v.y + f.uy * stub);
          line(f.ex, f.ey, f.ex - f.ux * stub, f.ey - f.uy * stub);
          var mx = f.v.x + f.ux * 12, my = f.v.y + f.uy * 12, r0 = 5 + 12 * a.snap;
          ctx.strokeStyle = 'rgba(255,255,255,' + (life * 0.8).toFixed(3) + ')';
          ctx.lineWidth = 1;
          for (var k = 0; k < 5; k++) {
            var ang = k * TAU / 5 + 0.6;
            line(mx + Math.cos(ang) * r0, my + Math.sin(ang) * r0, mx + Math.cos(ang) * (r0 + 3), my + Math.sin(ang) * (r0 + 3));
          }
        }
      });
    }

    function drawAtoms(positions) {
      ctx.font = '300 12px ' + mono;
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      model.atoms.forEach(function (a, i) {
        var p = positions[i];
        if (a.pulse < 1) {
          var e = 1 - Math.pow(1 - a.pulse, 3);
          ctx.strokeStyle = rgba(INDIGO, ((1 - a.pulse) * 0.7).toFixed(3));
          ctx.lineWidth = 1.5;
          ctx.beginPath();
          ctx.arc(p.x, p.y, ATOM_R + 24 * e, 0, TAU);
          ctx.stroke();
        }
        ctx.beginPath();
        ctx.arc(p.x, p.y, ATOM_R, 0, TAU);
        ctx.fillStyle = GROUND;
        ctx.fill();
        ctx.fillStyle = rgba(INDIGO, a.fill.toFixed(3));
        ctx.fill();
        ctx.strokeStyle = mix(GRAY, INDIGO, a.fill);
        ctx.lineWidth = 1.5;
        ctx.stroke();
        ctx.fillStyle = mix(GRAY, [255, 255, 255], a.fill);
        ctx.fillText(symbols[i], p.x, p.y + 0.5);
      });
    }

    function draw(t) {
      ctx.clearRect(0, 0, w, h);
      if (!w) { return; }
      var positions = model.atoms.map(function (a, i) { return model.pos(i, t); });
      var sc = model.scale(), fl = model.flash();
      var frac = model.bondsFormed() / n;

      ctx.save();
      ctx.translate((w - W * s) / 2, (h - H * s) / 2);
      ctx.scale(s, s);
      ctx.translate(CX, CY);          // the success pulse scales the whole molecule about the ring
      ctx.scale(sc, sc);
      ctx.translate(-CX, -CY);

      drawRing('rgba(255,255,255,' + (0.28 + 0.3 * frac).toFixed(3) + ')', 1.5);
      drawBonds(t, positions);
      drawAtoms(positions);

      if (fl > 0) {                   // the opacity flash: everything brightens toward white
        ctx.globalCompositeOperation = 'lighter';
        var wht = 'rgba(255,255,255,' + (fl * 0.55).toFixed(3) + ')';
        drawRing(wht, 2);
        ctx.strokeStyle = wht;
        ctx.lineWidth = 2;
        model.atoms.forEach(function (a, i) {
          var p = positions[i];
          if (a.bond > 0) { var g = bondSegment(i, p, a.bond); line(g.v.x, g.v.y, g.ex, g.ey); }
          ctx.beginPath();
          ctx.arc(p.x, p.y, ATOM_R, 0, TAU);
          ctx.stroke();
        });
        ctx.globalCompositeOperation = 'source-over';
      }
      ctx.restore();
    }

    function flush() {
      waiters = waiters.filter(function (wt) {
        if (wt.done) { return false; }
        if (model.assembled()) { wt.finish(); return false; }
        return true;
      });
    }

    function frame(now) {
      raf = 0;
      var dt = last ? Math.min((now - last) / 1000, 0.05) : 0;
      last = now;
      model.step(dt);
      draw(now / 1000);
      flush();
      if (visible && !document.hidden) { raf = window.requestAnimationFrame(frame); }
    }
    function kick() {
      if (!raf && visible && !document.hidden) { last = 0; raf = window.requestAnimationFrame(frame); }
    }

    document.addEventListener('visibilitychange', kick);
    if ('ResizeObserver' in window) { new ResizeObserver(fit).observe(canvas); }
    else { window.addEventListener('resize', fit); }
    if ('IntersectionObserver' in window) {
      new IntersectionObserver(function (entries) {
        visible = entries[0].isIntersecting;
        if (visible) { kick(); }
      }).observe(canvas);
    }
    fit();
    kick();

    return {
      model: model,
      setFilled: function (i, value) { model.setFilled(i, value); kick(); },
      fail: function () { model.fail(); kick(); },
      success: function (cb) { model.success(cb); kick(); },
      // Resolves once every atom is bonded, or after timeoutMs (a hidden tab pauses the
      // animation, and the page must not hang on it).
      assembled: function (timeoutMs) {
        return new Promise(function (resolve) {
          if (model.assembled()) { resolve(); return; }
          var wt = { done: false, finish: function () { if (!wt.done) { wt.done = true; resolve(); } } };
          waiters.push(wt);
          window.setTimeout(wt.finish, timeoutMs);
        });
      }
    };
  }

  var api = { layoutFor: layoutFor, createModel: createModel, mount: mount };
  if (typeof module === 'object' && module.exports) { module.exports = api; }
  else { (root.F2F = root.F2F || {}).Reaction = api; }
})(typeof window !== 'undefined' ? window : globalThis);
