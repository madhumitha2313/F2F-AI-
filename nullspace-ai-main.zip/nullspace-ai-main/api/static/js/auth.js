/* Sign-in and sign-up forms: validate each field on blur, light the matching atom in the
   reaction-progress component (reaction.js), and submit with fetch so the animation can
   answer the outcome. Everything from the network is written with textContent.

   Sign-up is not real multi-user auth (see _AUTH_PAGES in app.py): it posts to the same
   check as sign-in. The "confirm" input has no name, so it is never submitted; it only
   has to match the password here in the browser.

   Progressive enhancement: with reduced motion (or no canvas) there is no interception:
   the dots update as fields become valid and the browser posts the form itself, so the
   server's redirect / re-rendered error page does the work. */
(function (root) {
  'use strict';

  // "Valid" is deliberately light: this build has no real accounts to check against.
  var validators = {
    username: function (v) { return v.trim().length > 0; },
    password: function (v) { return v.length > 0; },
    confirm: function (v, all) { return v.length > 0 && v === all.password; }
  };

  if (typeof module === 'object' && module.exports) { module.exports = { validators: validators }; }
  if (typeof document === 'undefined') { return; }

  var form = document.querySelector('[data-auth-form]');
  var panel = document.querySelector('[data-reaction]');
  if (!form || !panel) { return; }

  var inputs = Array.prototype.slice.call(form.querySelectorAll('[data-rx-rule]'));
  var steps = panel.querySelectorAll('[data-reaction-steps] li');
  var countEl = panel.querySelector('[data-reaction-count]');
  var errorEl = document.getElementById('auth-error');
  var submitBtn = form.querySelector('[data-auth-submit]');
  var idleLabel = submitBtn.textContent;
  var busyLabel = form.getAttribute('data-busy-label') || idleLabel;

  var reaction = root.F2F && root.F2F.Reaction ? root.F2F.Reaction.mount(panel) : null;
  var filled = inputs.map(function () { return false; });
  var busy = false;

  function values() {
    var all = {};
    inputs.forEach(function (input) { all[input.getAttribute('data-rx-rule')] = input.value; });
    return all;
  }

  function byRule(rule) {
    return inputs.filter(function (i) { return i.getAttribute('data-rx-rule') === rule; })[0] || null;
  }

  // The last dot is "Ready": it fills when every field is valid.
  function render() {
    var count = filled.filter(Boolean).length;
    var ready = count === inputs.length;
    for (var k = 0; k < steps.length; k++) {
      var done = k < inputs.length ? filled[k] : ready;
      steps[k].setAttribute('data-done', done ? 'true' : 'false');
      var state = steps[k].querySelector('[data-step-state]');
      if (state) { state.textContent = done ? ', done' : ', not done'; }
    }
    if (countEl) { countEl.textContent = count + ' of ' + inputs.length + ' bonds'; }
  }

  // Keep the browser's own validity in step with the confirm field, so a mismatch blocks
  // a native submit as well as ours. Cheap, so it runs on every keystroke.
  function syncConfirmValidity() {
    var confirm = byRule('confirm'), password = byRule('password');
    if (!confirm || !password) { return; }
    var mismatch = confirm.value !== '' && confirm.value !== password.value;
    confirm.setCustomValidity(mismatch ? 'The two passwords do not match.' : '');
  }

  // Blur, not keystroke: an atom lights when a field is finished and valid.
  function sync(i) {
    var input = inputs[i];
    var ok = validators[input.getAttribute('data-rx-rule')](input.value, values());
    if (ok === filled[i]) { return; }
    filled[i] = ok;
    if (reaction) { reaction.setFilled(i, ok); }
    render();
  }

  function syncAll() {
    syncConfirmValidity();
    inputs.forEach(function (_, i) { sync(i); });
  }

  inputs.forEach(function (input, i) {
    input.addEventListener('input', syncConfirmValidity);
    function onDone() {
      syncConfirmValidity();
      sync(i);
      if (input.getAttribute('data-rx-rule') === 'password') {
        var c = byRule('confirm');
        if (c) { sync(inputs.indexOf(c)); }   // the password changed, so does what "matches" means
      }
    }
    input.addEventListener('blur', onDone);
    input.addEventListener('change', onDone);   // autofill and paste can change a value without a blur
  });

  function setBusy(on) {
    busy = on;
    submitBtn.disabled = on;
    submitBtn.textContent = on ? busyLabel : idleLabel;
  }

  function showError(message) {
    errorEl.textContent = message;
    errorEl.hidden = false;
  }

  function messageFor(result) {
    if (result.status === 0) { return 'Could not reach the server. Check your connection and try again.'; }
    if (result.data && result.data.error) { return result.data.error; }
    return 'The server returned an unexpected response (HTTP ' + result.status + ').';
  }

  // Only ever follow a same-site path the server handed back.
  function safeNext(next) {
    return typeof next === 'string' && next.charAt(0) === '/' && next.charAt(1) !== '/' ? next : null;
  }

  form.addEventListener('submit', function (ev) {
    syncAll();   // Enter pressed inside a field never blurred it
    if (!reaction) { return; }   // reduced motion: let the browser post the form
    ev.preventDefault();
    if (busy) { return; }
    setBusy(true);
    errorEl.hidden = true;

    var body = new URLSearchParams(new FormData(form));   // named inputs only: confirm stays behind
    var request = fetch(form.getAttribute('action'), {
      method: 'POST',
      headers: { 'Accept': 'application/json', 'Content-Type': 'application/x-www-form-urlencoded' },
      credentials: 'same-origin',
      body: body
    }).then(function (res) {
      return res.json().catch(function () { return null; }).then(function (data) {
        return { ok: res.ok, status: res.status, data: data };
      });
    }).catch(function () { return { ok: false, status: 0, data: null }; });

    // Let the last bond finish drawing before the verdict plays.
    Promise.all([request, reaction.assembled(1500)]).then(function (all) {
      var result = all[0];
      var next = result.ok && result.data && result.data.ok ? safeNext(result.data.next) : null;
      if (next) {
        var gone = false;
        var go = function () { if (!gone) { gone = true; window.location.assign(next); } };
        reaction.success(go);
        window.setTimeout(go, 1500);   // a hidden tab pauses the animation; still go
        for (var k = 0; k < steps.length; k++) { steps[k].setAttribute('data-done', 'true'); }
        return;
      }
      reaction.fail();
      filled = filled.map(function () { return false; });
      render();
      showError(messageFor(result));
      setBusy(false);
      inputs[0].focus();
    });
  });

  syncAll();
  render();
})(typeof window !== 'undefined' ? window : globalThis);
