/* Lab elements on the login page: the reaction scheme and the reaction plate.

   Both read one JSON blob (#lab-data) that the server computed from the model, and
   they share one piece of state (the halogen filter), so choosing Cl, Br or I in
   either one updates the other. Every figure is the model's predicted failure
   probability, not a measurement. Nothing here animates, so it behaves the same
   under reduced motion. All text is written with textContent. */
(function () {
  'use strict';

  var dataEl = document.getElementById('lab-data');
  if (!dataEl) { return; }
  var D;
  try { D = JSON.parse(dataEl.textContent); } catch (e) { return; }

  var F2F = window.F2F || {};
  function setLead(el, text) {
    if (F2F.setLead) { F2F.setLead(el, text); } else { el.textContent = text; }
  }

  var NL = D.ligands.length, NB = D.bases.length, NA = D.additives.length, NR = D.rows.length;
  var NC = NL * NB;
  var HALOGENS = ['Cl', 'Br', 'I'];
  var HALIDE_NOUN = { Cl: 'chlorides', Br: 'bromides', I: 'iodides' };
  var state = { halide: null, add: 0, pin: null, cursor: null };

  function pct(p) { return (p * 100).toFixed(1) + '%'; }
  function clip(s, n) { return s.length <= n ? s : s.slice(0, n - 1) + '…'; }
  function el(tag, cls, text) {
    var e = document.createElement(tag);
    if (cls) { e.className = cls; }
    if (text !== undefined) { e.textContent = text; }
    return e;
  }

  /* ---- Reaction plate ------------------------------------------------------ */
  var plate = document.querySelector('[data-plate]');
  var wells = [];   // wells[r][c]
  var rowLabels = [];
  var body, readout;

  function wellData(r, c) {
    return {
      p: D.p[state.add][r][c] / 1000,
      aryl: D.rows[r],
      lig: D.ligands[Math.floor(c / NB)],
      base: D.bases[c % NB],
      add: D.additives[state.add]
    };
  }

  function showWell(r, c) {
    if (!readout) { return; }
    var w = wellData(r, c);
    readout.code.textContent = w.aryl.code + ' · ' + w.lig.code + ' · ' + w.base.code + ' · ' + w.add.code;
    setLead(readout.p, pct(w.p));
    readout.a.textContent = 'Aryl halide ' + w.aryl.code + ': ' + clip(w.aryl.label, 56);
    readout.b.textContent = 'Ligand ' + w.lig.code + ': ' + clip(w.lig.label, 56);
    readout.c.textContent = 'Base ' + w.base.code + ': ' + clip(w.base.label, 56);
    readout.d.textContent = 'Additive ' + w.add.code + ': ' + clip(w.add.label, 56);
  }

  function showSummary() {
    if (!readout) { return; }
    var sum = 0, n = 0;
    for (var r = 0; r < NR; r++) {
      if (state.halide && D.rows[r].halide !== state.halide) { continue; }
      for (var c = 0; c < NC; c++) { sum += D.p[state.add][r][c] / 1000; n++; }
    }
    readout.code.textContent = D.additives[state.add].code + ' · ' + (state.halide || 'all halogens') +
      ' · mean of ' + n + ' wells';
    setLead(readout.p, n ? pct(sum / n) : 'n/a');
    readout.a.textContent = 'Point at a well, or use the arrow keys, to read one reaction.';
    readout.b.textContent = '';
    readout.c.textContent = '';
    readout.d.textContent = '';
  }

  function showCurrent() {
    if (state.cursor) { showWell(state.cursor.r, state.cursor.c); }
    else if (state.pin) { showWell(state.pin.r, state.pin.c); }
    else { showSummary(); }
  }

  function paintPlate() {
    if (!plate) { return; }
    var pl = D.p[state.add];
    for (var r = 0; r < NR; r++) {
      var dim = !!(state.halide && D.rows[r].halide !== state.halide);
      rowLabels[r].classList.toggle('is-dim', dim);
      for (var c = 0; c < NC; c++) {
        var w = wells[r][c];
        w.style.setProperty('--p', (pl[r][c] / 1000).toFixed(3));
        w.classList.toggle('is-dim', dim);
      }
    }
    plate.querySelector('[data-additive-code]').textContent = D.additives[state.add].code + ' / ' + NA;
    plate.querySelector('[data-additive-label]').textContent = clip(D.additives[state.add].label, 90);
    Array.prototype.forEach.call(plate.querySelectorAll('[data-halide]'), function (b) {
      b.setAttribute('aria-pressed', b.getAttribute('data-halide') === state.halide ? 'true' : 'false');
    });
    showCurrent();
  }

  function paintMarks() {
    for (var r = 0; r < NR; r++) {
      for (var c = 0; c < NC; c++) {
        wells[r][c].classList.toggle('is-pinned', !!(state.pin && state.pin.r === r && state.pin.c === c));
        wells[r][c].classList.toggle('is-cursor', !!(state.cursor && state.cursor.r === r && state.cursor.c === c));
      }
    }
  }

  function pin(r, c) {
    var same = state.pin && state.pin.r === r && state.pin.c === c;
    state.pin = same ? null : { r: r, c: c };
    paintMarks();
    showCurrent();
  }

  function buildPlate() {
    body = plate.querySelector('[data-plate-body]');
    var head = plate.querySelector('[data-plate-head]');
    var rows = plate.querySelector('[data-plate-rows]');
    readout = {
      code: plate.querySelector('[data-well-code]'),
      p: plate.querySelector('[data-well-p]'),
      a: plate.querySelector('[data-well-a]'),
      b: plate.querySelector('[data-well-b]'),
      c: plate.querySelector('[data-well-c]'),
      d: plate.querySelector('[data-well-d]')
    };

    var r, c, j, b;
    for (j = 0; j < NL; j++) {                       // header: ligand over its three bases
      var hg = el('div', 'plate-group is-head');
      hg.appendChild(el('span', 'label', D.ligands[j].code));
      for (b = 0; b < NB; b++) { hg.appendChild(el('span', 'plate-base', D.bases[b].code)); }
      head.appendChild(hg);
    }
    for (r = 0; r < NR; r++) {                       // row labels: aryl halide code + halogen
      var lab = el('span');
      lab.appendChild(el('b', null, D.rows[r].code));
      lab.appendChild(document.createTextNode(D.rows[r].halide || ''));
      rows.appendChild(lab);
      rowLabels.push(lab);
      wells.push([]);
    }
    for (j = 0; j < NL; j++) {                       // wells, one group per ligand
      var g = el('div', 'plate-group');
      for (r = 0; r < NR; r++) {
        for (b = 0; b < NB; b++) {
          var well = el('div', 'well');
          well.setAttribute('data-r', String(r));
          well.setAttribute('data-c', String(j * NB + b));
          g.appendChild(well);
          wells[r][j * NB + b] = well;
        }
      }
      body.appendChild(g);
    }

    body.addEventListener('mouseover', function (e) {
      var t = e.target;
      if (t.classList && t.classList.contains('well') && !state.cursor) {
        showWell(+t.getAttribute('data-r'), +t.getAttribute('data-c'));
      }
    });
    body.addEventListener('mouseleave', function () { if (!state.cursor) { showCurrent(); } });
    body.addEventListener('click', function (e) {
      var t = e.target;
      if (t.classList && t.classList.contains('well')) {
        state.cursor = null;   // the mouse is in charge now, not the keyboard
        pin(+t.getAttribute('data-r'), +t.getAttribute('data-c'));
      }
    });
    body.addEventListener('focus', function () {
      // Only keyboard focus gets a cursor: a mouse click also focuses this element and
      // must not invent a cursor at the top-left well.
      var keyboard = true;
      try { keyboard = body.matches(':focus-visible'); } catch (e) {}
      if (!keyboard) { return; }
      if (!state.cursor) { state.cursor = state.pin ? { r: state.pin.r, c: state.pin.c } : { r: 0, c: 0 }; }
      paintMarks();
      showCurrent();
    });
    body.addEventListener('blur', function () { state.cursor = null; paintMarks(); showCurrent(); });
    body.addEventListener('keydown', function (e) {
      var cur = state.cursor || state.pin || { r: 0, c: 0 };
      var r2 = cur.r, c2 = cur.c;
      switch (e.key) {
        case 'ArrowRight': c2 = Math.min(NC - 1, c2 + 1); break;
        case 'ArrowLeft': c2 = Math.max(0, c2 - 1); break;
        case 'ArrowDown': r2 = Math.min(NR - 1, r2 + 1); break;
        case 'ArrowUp': r2 = Math.max(0, r2 - 1); break;
        case 'Home': c2 = 0; break;
        case 'End': c2 = NC - 1; break;
        case 'Enter': case ' ': e.preventDefault(); pin(cur.r, cur.c); return;
        case 'Escape': state.pin = null; paintMarks(); showCurrent(); return;
        default: return;
      }
      e.preventDefault();
      state.cursor = { r: r2, c: c2 };
      paintMarks();
      showCurrent();
    });

    Array.prototype.forEach.call(plate.querySelectorAll('[data-step]'), function (btn) {
      btn.addEventListener('click', function () {
        state.add = (state.add + parseInt(btn.getAttribute('data-step'), 10) + NA) % NA;
        paintPlate();
      });
    });
    Array.prototype.forEach.call(plate.querySelectorAll('[data-halide]'), function (btn) {
      var h = btn.getAttribute('data-halide');
      var mean = plate.querySelector('[data-el-mean="' + h + '"]');
      if (mean && D.halides[h]) { mean.textContent = 'mean ' + pct(D.halides[h].mean); }
      btn.addEventListener('click', function () { setHalide(state.halide === h ? null : h); });
    });
  }

  /* ---- Reaction scheme ------------------------------------------------------- */
  var scheme = document.querySelector('[data-lab-scheme]');
  var schemeOut = scheme && scheme.querySelector('[data-lab-readout]');
  var xText = scheme && scheme.querySelector('[data-x]');
  var DEFAULT_SCHEME = 'Point at a part of the reaction, or select the X to step through the halogens.';

  function describe(part) {
    var C = D.counts, H = D.halides;
    switch (part) {
      case 'aryl':
        return 'Aryl halide: ' + C.aryl_halide + ' values in the model (' +
          HALOGENS.filter(function (h) { return H[h]; }).map(function (h) { return H[h].n + ' ' + HALIDE_NOUN[h]; }).join(', ') +
          '). Select the X to filter by halogen.';
      case 'halogen':
        return state.halide && H[state.halide]
          ? 'X = ' + state.halide + ': ' + H[state.halide].n + ' aryl halides, mean predicted failure probability ' +
            pct(H[state.halide].mean) + '. Select again for the next halogen.'
          : 'X is the leaving group: Cl, Br or I. Select it to step through them and filter the reaction plate.';
      case 'amine': return "The amine partner is not one of the model's four inputs.";
      case 'catalyst': return 'Palladium catalyst. The model knows ' + C.ligand + ' ligands.';
      case 'base': return 'Base: the model knows ' + C.base + ' bases.';
      case 'additive': return 'Additive: the model knows ' + C.additive + ' additives.';
      case 'product':
        return 'Product: the coupled aryl amine. A reaction counts as a failure when its measured output is below ' +
          (typeof D.threshold === 'number' ? D.threshold.toFixed(1) : 'the training threshold') + '.';
      default: return DEFAULT_SCHEME;
    }
  }

  function paintScheme() {
    if (!scheme) { return; }
    xText.textContent = state.halide || 'X';
    if (!scheme.classList.contains('has-focus')) {
      schemeOut.textContent = state.halide ? describe('halogen') : DEFAULT_SCHEME;
    }
  }

  function buildScheme() {
    var parts = scheme.querySelectorAll('.scheme-part');
    Array.prototype.forEach.call(parts, function (p) {
      var name = p.getAttribute('data-part');
      function on() { scheme.classList.add('has-focus'); p.classList.add('is-on'); schemeOut.textContent = describe(name); }
      function off() { scheme.classList.remove('has-focus'); p.classList.remove('is-on'); paintScheme(); }
      p.addEventListener('mouseenter', on);
      p.addEventListener('mouseleave', off);
      p.addEventListener('focus', on);
      p.addEventListener('blur', off);
      if (name === 'halogen') {
        var step = function () {
          var i = state.halide ? HALOGENS.indexOf(state.halide) : -1;
          setHalide(i === HALOGENS.length - 1 ? null : HALOGENS[i + 1]);
          schemeOut.textContent = describe('halogen');
        };
        p.addEventListener('click', step);
        p.addEventListener('keydown', function (e) {
          if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); step(); }
        });
      }
    });
  }

  /* ---- Shared state ------------------------------------------------------------ */
  function setHalide(h) {
    state.halide = h;
    paintPlate();
    paintScheme();
  }

  if (plate) { buildPlate(); paintPlate(); }
  if (scheme) { buildScheme(); paintScheme(); }
})();
