# -*- coding: utf-8 -*-
"""
Stage: Monitoring (architecture slide stage 10)

Lightweight SQLite logger for every prediction request. This is
intentionally simple (SQLite, not a full observability stack) — it is
enough to power a monitoring dashboard and feed drift_detector.py,
which is the actual scope needed for this project.
"""

import json
import os
import pathlib
import sqlite3
from datetime import datetime, timedelta, timezone

DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "predictions.db")


def _connect():
    conn = sqlite3.connect(DB_PATH)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS predictions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp TEXT NOT NULL,
            ligand TEXT, additive TEXT, base TEXT, aryl_halide TEXT,
            prediction TEXT,
            failure_probability REAL,
            confidence REAL,
            model_used TEXT,
            warnings TEXT
        )
    """)
    return conn


def log_prediction(inputs: dict, result: dict):
    """inputs: {ligand, additive, base, aryl_halide}. result: output of FailurePredictor.predict()."""
    conn = _connect()
    conn.execute(
        """INSERT INTO predictions
           (timestamp, ligand, additive, base, aryl_halide,
            prediction, failure_probability, confidence, model_used, warnings)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
        (
            datetime.now(timezone.utc).isoformat(),
            inputs.get("ligand"), inputs.get("additive"),
            inputs.get("base"), inputs.get("aryl_halide"),
            result.get("prediction"), result.get("failure_probability"),
            result.get("confidence"), result.get("model_used"),
            json.dumps(result.get("warnings", [])),
        ),
    )
    conn.commit()
    conn.close()


def get_recent_predictions(limit: int = 100):
    conn = _connect()
    conn.row_factory = sqlite3.Row
    rows = conn.execute(
        "SELECT * FROM predictions ORDER BY id DESC LIMIT ?", (limit,)
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def get_summary_stats():
    conn = _connect()
    total = conn.execute("SELECT COUNT(*) FROM predictions").fetchone()[0]
    failures = conn.execute(
        "SELECT COUNT(*) FROM predictions WHERE prediction='Failure'"
    ).fetchone()[0]
    avg_conf = conn.execute("SELECT AVG(confidence) FROM predictions").fetchone()[0]
    conn.close()
    return {
        "total_predictions": total,
        "flagged_failures": failures,
        "failure_rate": round(failures / total, 4) if total else None,
        "average_confidence": round(avg_conf, 4) if avg_conf else None,
    }


# ---- Read-only queries for the dashboard's Activity, Trend and Coverage widgets ----
# These never create the database or its table: a missing or empty log reads as zeros.

VALUE_COLUMNS = ("ligand", "additive", "base", "aryl_halide")
UNSEEN_PHRASE = "not seen during training"   # from FailurePredictor.predict()'s warning
HOURLY_DAYS = 5
DAILY_DAYS = 14
WEEK_DAYS = 7


def _connect_readonly(db_path=None):
    """A read-only connection, or None when there is no database file to read."""
    path = db_path or DB_PATH
    if not os.path.exists(path):
        return None
    return sqlite3.connect(pathlib.Path(path).resolve().as_uri() + "?mode=ro", uri=True)


def _query(db_path, sql, params=(), default=None):
    """Run one read; a missing database or table gives `default` instead of an error."""
    conn = _connect_readonly(db_path)
    if conn is None:
        return default
    try:
        return conn.execute(sql, params).fetchall()
    except sqlite3.OperationalError as e:
        if "no such table" in str(e):
            return default
        raise
    finally:
        conn.close()


def _utc(text):
    """A logged timestamp as an aware UTC datetime, or None if it cannot be read.
    Naive stamps are taken as UTC (the logger always writes UTC)."""
    if not isinstance(text, str):
        return None
    try:
        when = datetime.fromisoformat(text.strip())
    except ValueError:
        return None
    return when.replace(tzinfo=timezone.utc) if when.tzinfo is None else when.astimezone(timezone.utc)


def get_activity(now=None, db_path=None):
    """When the tool was asked, by UTC hour and day. Every window is zero-filled.

        {"generated_at": iso,
         "hourly": {"days": [5 dates, oldest first, today last],
                    "counts": [[24 ints] x 5], "flagged": [[24 ints] x 5], "total_today": int},
         "daily":  [14 x {"date", "total", "flagged"}, oldest first, today last],
         "week":   {"total", "flagged", "failure_rate": float | None},   # today and the 6 days before
         "total_all": int}                                              # every logged row, in or out of a window

    A "flagged" row is one whose prediction is exactly 'Failure'. Rows with an unreadable
    timestamp are left out of every window but still counted in total_all.
    """
    now = datetime.now(timezone.utc) if now is None else now
    now = now.replace(tzinfo=timezone.utc) if now.tzinfo is None else now.astimezone(timezone.utc)
    today = now.date()

    def day(back):
        return (today - timedelta(days=back)).isoformat()

    hourly_days = [day(back) for back in range(HOURLY_DAYS - 1, -1, -1)]
    daily_days = [day(back) for back in range(DAILY_DAYS - 1, -1, -1)]
    week_days = set(daily_days[-WEEK_DAYS:])
    hour_row = {d: i for i, d in enumerate(hourly_days)}
    counts = [[0] * 24 for _ in hourly_days]
    flagged = [[0] * 24 for _ in hourly_days]
    daily = {d: [0, 0] for d in daily_days}
    week = [0, 0]

    total_all = (_query(db_path, "SELECT COUNT(*) FROM predictions", default=[(0,)]))[0][0]
    # A stamp's date prefix sorts as text, and a UTC offset moves it by less than a day, so one
    # day of slack before the oldest window keeps every row that could belong in one.
    since = (today - timedelta(days=DAILY_DAYS)).isoformat()
    rows = _query(db_path, "SELECT timestamp, prediction FROM predictions WHERE timestamp >= ?",
                  (since,), default=[])
    for stamp, prediction in rows:
        when = _utc(stamp)
        if when is None:
            continue
        date, is_failure = when.date().isoformat(), prediction == "Failure"
        if date in hour_row:
            counts[hour_row[date]][when.hour] += 1
            flagged[hour_row[date]][when.hour] += is_failure
        if date in daily:
            daily[date][0] += 1
            daily[date][1] += is_failure
        if date in week_days:
            week[0] += 1
            week[1] += is_failure

    return {
        "generated_at": now.isoformat(),
        "hourly": {"days": hourly_days, "counts": counts, "flagged": flagged,
                   "total_today": sum(counts[-1])},
        "daily": [{"date": d, "total": daily[d][0], "flagged": daily[d][1]} for d in daily_days],
        "week": {"total": week[0], "flagged": week[1],
                 "failure_rate": round(week[1] / week[0], 4) if week[0] else None},
        "total_all": total_all,
    }


def get_value_counts(db_path=None):
    """How often each value was asked about, per input, over the whole log:
    {"ligand": {smiles: n}, "additive": {...}, "base": {...}, "aryl_halide": {...}, "samples": rows}.
    A row with no value for an input adds nothing to that input's counts but still counts as a sample."""
    out = {col: {} for col in VALUE_COLUMNS}
    out["samples"] = _query(db_path, "SELECT COUNT(*) FROM predictions", default=[(0,)])[0][0]
    for col in VALUE_COLUMNS:     # column names come from the tuple above, never from a request
        out[col] = dict(_query(
            db_path, f"SELECT {col}, COUNT(*) FROM predictions WHERE {col} IS NOT NULL GROUP BY {col}",
            default=[]))
    return out


def count_unseen_requests(db_path=None):
    """Logged requests that carried a value the model never saw in training (one per row)."""
    return _query(db_path, "SELECT COUNT(*) FROM predictions WHERE warnings LIKE ?",
                  (f"%{UNSEEN_PHRASE}%",), default=[(0,)])[0][0]
