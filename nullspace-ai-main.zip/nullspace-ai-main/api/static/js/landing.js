/* Landing page motion. Everything here is skipped when the visitor asks for reduced
   motion (base.html adds the "motion" class only when they have not), and the
   canvases then draw one still frame instead of animating.

     - intro line: fades in, lifts, clears (first visit per session only)
     - hero headline: per-character stagger
     - hero canvas: three sine ribbons, additively brightening where they cross
     - engine tiles: four small canvases, ONE shared routine (different seed and speed)
     - reveal-on-scroll: IntersectionObserver
     - live stats: refreshed from GET /stats

   One requestAnimationFrame loop drives every canvas and it pauses for canvases that
   are off screen and when the tab is hidden. No WebGL, no scroll listener. */
(function () {
  'use strict';

  var root = document.documentElement;
  var motion = root.classList.contains('motion');
  var TAU = Math.PI * 2;
  var GROUND = '#0A0A0A';

  /* ---- Canvas scenes ------------------------------------------------------- */
  var scenes = [];
  var raf = 0;

  function frame(t) {
    raf = 0;
    var running = false;
    for (var i = 0; i < scenes.length; i++) {
      var s = scenes[i];
      if (s.visible) { s.draw(s.ctx, s.w, s.h, t); running = true; }
    }
    if (running) { raf = window.requestAnimationFrame(frame); }
  }
  function kick() {
    if (motion && !raf && !document.hidden) { raf = window.requestAnimationFrame(frame); }
  }
  document.addEventListener('visibilitychange', kick);

  function fit(s) {
    var rect = s.canvas.getBoundingClientRect();
    if (!rect.width || !rect.height) { return; }
    var dpr = Math.min(window.devicePixelRatio || 1, 2);
    s.canvas.width = Math.round(rect.width * dpr);
    s.canvas.height = Math.round(rect.height * dpr);
    s.ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    s.w = rect.width;
    s.h = rect.height;
    s.draw(s.ctx, s.w, s.h, s.stillAt);   // a valid frame at once (and the only frame under reduced motion)
  }

  function addScene(canvas, draw, stillAt) {
    var ctx = canvas.getContext('2d');
    if (!ctx) { return; }
    var s = { canvas: canvas, ctx: ctx, draw: draw, stillAt: stillAt, w: 0, h: 0, visible: false };
    scenes.push(s);
    fit(s);
    if ('ResizeObserver' in window) {
      new ResizeObserver(function () { fit(s); }).observe(canvas);
    } else {
      window.addEventListener('resize', function () { fit(s); });
    }
    if (motion && 'IntersectionObserver' in window) {
      new IntersectionObserver(function (entries) {
        s.visible = entries[0].isIntersecting;
        if (s.visible) { kick(); }
      }).observe(canvas);
    }
  }

  /* ---- Hero: three ribbons in one accent family --------------------------------
     Indigo, an indigo shifted toward violet, and an indigo shifted toward cyan. Filled
     with the 'lighter' blend so overlaps add up and brighten where the ribbons cross. */
  // base, amp and th are fractions of the ribbon zone: the bottom RIBBON_ZONE px of the
  // hero, which the stylesheet keeps free of text (--ribbon-zone), so ribbons never sit
  // behind copy.
  var RIBBON_ZONE = 152;
  var RIBBONS = [
    { rgb: '99,102,241',  base: 0.52, amp: 0.15, k: 1.25, s:  0.00042, ph: 0.0, th: 0.46, a: 0.32 },
    { rgb: '143,100,241', base: 0.46, amp: 0.19, k: 0.95, s: -0.00032, ph: 2.1, th: 0.38, a: 0.28 },
    { rgb: '100,152,241', base: 0.58, amp: 0.13, k: 1.65, s:  0.00052, ph: 4.2, th: 0.34, a: 0.26 }
  ];

  function drawRibbons(ctx, w, h, t) {
    ctx.globalCompositeOperation = 'source-over';
    ctx.fillStyle = GROUND;
    ctx.fillRect(0, 0, w, h);
    ctx.globalCompositeOperation = 'lighter';
    var step = Math.max(4, Math.round(w / 220));
    var zone = Math.min(h * 0.4, RIBBON_ZONE);
    var zoneTop = h - zone;
    RIBBONS.forEach(function (r) {
      var top = [], bottom = [];
      for (var x = 0; x <= w + step; x += step) {
        var u = (x / w) * TAU;
        var yc = zoneTop + zone * (r.base +
          r.amp * Math.sin(u * r.k + t * r.s + r.ph) +
          r.amp * 0.45 * Math.sin(u * r.k * 2.3 - t * r.s * 1.4 + r.ph));
        var th = zone * r.th * (0.7 + 0.3 * Math.sin(u * 1.6 + t * r.s * 0.8 + r.ph * 1.3));
        top.push([x, yc - th / 2]);
        bottom.push([x, yc + th / 2]);
      }
      var i;
      ctx.beginPath();
      ctx.moveTo(top[0][0], top[0][1]);
      for (i = 1; i < top.length; i++) { ctx.lineTo(top[i][0], top[i][1]); }
      for (i = bottom.length - 1; i >= 0; i--) { ctx.lineTo(bottom[i][0], bottom[i][1]); }
      ctx.closePath();
      ctx.fillStyle = 'rgba(' + r.rgb + ',' + r.a + ')';
      ctx.fill();

      ctx.lineWidth = 1;
      ctx.strokeStyle = 'rgba(' + r.rgb + ',0.55)';
      [top, bottom].forEach(function (edge) {
        ctx.beginPath();
        ctx.moveTo(edge[0][0], edge[0][1]);
        for (var j = 1; j < edge.length; j++) { ctx.lineTo(edge[j][0], edge[j][1]); }
        ctx.stroke();
      });
    });
    ctx.globalCompositeOperation = 'source-over';
  }

  /* ---- Engine tiles: one routine, four seeds ---------------------------------
     A dot grid with a pulse travelling across it. Seed sets the direction, the
     wavelength and the phase; speed sets the tempo. White only: indigo is rationed. */
  function makePulse(seed, speed) {
    var dir = seed % 2 ? 1 : -1;
    var freq = 0.42 + seed * 0.11;
    return function (ctx, w, h, t) {
      ctx.globalCompositeOperation = 'source-over';
      ctx.fillStyle = GROUND;
      ctx.fillRect(0, 0, w, h);
      var cols = Math.max(8, Math.round(w / 22));
      var rows = 4;
      var gx = w / cols;
      var gy = h / (rows + 1);
      for (var j = 0; j < rows; j++) {
        for (var i = 0; i < cols; i++) {
          var wave = 0.5 + 0.5 * Math.sin(dir * t * 0.0022 * speed - i * freq + j * 0.9 + seed * 1.7);
          ctx.fillStyle = 'rgba(255,255,255,' + (0.14 + 0.78 * wave * wave).toFixed(3) + ')';
          ctx.beginPath();
          ctx.arc(gx * (i + 0.5), gy * (j + 1), 1 + 1.6 * wave, 0, TAU);
          ctx.fill();
        }
      }
    };
  }

  /* ---- Hero headline: per-character stagger -------------------------------------
     The heading keeps its aria-label; the visual characters are aria-hidden. Words are
     wrapped so a line never breaks in the middle of one. */
  function splitHeading(h1) {
    var counter = 0;
    function walk(source, target) {
      Array.prototype.slice.call(source.childNodes).forEach(function (node) {
        if (node.nodeType === 3) {
          node.nodeValue.split(/(\s+)/).forEach(function (chunk) {
            if (!chunk) { return; }
            if (/^\s+$/.test(chunk)) { target.appendChild(document.createTextNode(' ')); return; }
            var word = document.createElement('span');
            word.className = 'word';
            Array.prototype.forEach.call(chunk, function (ch) {
              var c = document.createElement('span');
              c.className = 'char';
              c.style.setProperty('--i', String(counter++));
              c.textContent = ch;
              word.appendChild(c);
            });
            target.appendChild(word);
          });
        } else if (node.nodeType === 1) {
          var copy = node.cloneNode(false);
          target.appendChild(copy);
          walk(node, copy);
        }
      });
    }
    var visual = document.createElement('span');
    visual.setAttribute('aria-hidden', 'true');
    walk(h1, visual);
    h1.textContent = '';
    h1.appendChild(visual);
    h1.classList.add('is-split');
  }

  /* ---- Intro: one lowercase line ------------------------------------------------
     0.0-0.7s fades in and lifts, holds until 1.7s, then the overlay clears while the
     headline starts. Once per session, never under reduced motion. The overlay is
     decorative (aria-hidden, pointer-events: none). */
  function runIntro(done) {
    var seen = false;
    try { seen = window.sessionStorage.getItem('f2f-intro') === '1'; } catch (e) {}
    if (!motion || seen) { done(); return; }
    try { window.sessionStorage.setItem('f2f-intro', '1'); } catch (e) {}

    var overlay = document.createElement('div');
    overlay.className = 'intro';
    overlay.setAttribute('aria-hidden', 'true');
    var line = document.createElement('p');
    line.className = 'intro-line';
    line.textContent = 'reading the failures nobody published';
    overlay.appendChild(line);
    document.body.appendChild(overlay);

    window.requestAnimationFrame(function () {
      window.requestAnimationFrame(function () { overlay.classList.add('is-in'); });
    });
    window.setTimeout(function () {
      overlay.classList.add('is-out');
      window.setTimeout(done, 250);
    }, 1700);
    window.setTimeout(function () {
      if (overlay.parentNode) { overlay.parentNode.removeChild(overlay); }
    }, 2400);
  }

  /* ---- Reveal on scroll ------------------------------------------------------- */
  function initReveal() {
    if (!motion || !('IntersectionObserver' in window)) { return; }
    var vh = window.innerHeight || 800;
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (e) {
        if (e.isIntersecting) {
          e.target.classList.remove('reveal-hidden');
          io.unobserve(e.target);
        }
      });
    }, { threshold: 0.12 });
    Array.prototype.forEach.call(document.querySelectorAll('[data-reveal]'), function (el) {
      // Only what starts below the fold is hidden, so nothing flashes and no-JS shows it all.
      if (el.getBoundingClientRect().top > vh * 0.9) {
        el.classList.add('reveal-hidden');
        io.observe(el);
      }
    });
  }

  /* ---- Wire everything up ------------------------------------------------------ */
  var ribbonCanvas = document.querySelector('canvas[data-ribbons]');
  if (ribbonCanvas) { addScene(ribbonCanvas, drawRibbons, 5200); }

  Array.prototype.forEach.call(document.querySelectorAll('canvas[data-tile]'), function (c) {
    var seed = parseFloat(c.getAttribute('data-seed')) || 1;
    var speed = parseFloat(c.getAttribute('data-speed')) || 1;
    addScene(c, makePulse(seed, speed), seed * 900);
  });

  var h1 = document.querySelector('.hero h1[data-split]');
  if (h1 && motion) {
    splitHeading(h1);
    runIntro(function () {
      window.requestAnimationFrame(function () { h1.classList.add('is-in'); });
    });
  }

  initReveal();

  if (window.F2F && window.F2F.refreshStats) {
    window.F2F.refreshStats();
    window.setInterval(function () {
      if (!document.hidden) { window.F2F.refreshStats(); }
    }, 30000);
  }
})();
