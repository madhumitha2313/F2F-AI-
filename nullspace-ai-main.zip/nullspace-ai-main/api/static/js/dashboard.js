/* Dashboard: the widget grid, and the predict flow inside it.
     - the grid (widget-grid.js) lets people rearrange the widgets
     - choosing a value draws its structure under the field (structures.js) and tells the
       reaction widget (reaction-widget.js) with an 'f2f:inputs' event
     - the form posts to POST /predict, and the result is drawn in place
     - the same inputs then go to POST /explain, which fills "Why this?" (how far each
       input moved the score) and "Try this instead" (one-input swaps; Try loads and runs it)
     - "Recent predictions" and the stat tiles refresh after every run
   Only motion: widgets sliding when rearranged (widget-grid.js, skipped under reduced
   motion). All text from the API is written with textContent; nothing is parsed as HTML. */
(function () {
  'use strict';

  var F2F = window.F2F;
  var KEYS = ['ligand', 'additive', 'base', 'aryl_halide'];
  var MINUS = '−';

  function byId(id) { return document.getElementById(id); }
  // Mark widgets as working; returns done(). Harmless if the effects script is missing.
  function working(ids) {
    return F2F.WidgetFx && F2F.WidgetFx.run ? F2F.WidgetFx.run(ids) : function () {};
  }
  function el(tag, className, text) {
    var node = document.createElement(tag);
    if (className) { node.className = className; }
    if (text !== undefined) { node.textContent = text; }
    return node;
  }

  // The grid mounts even without a model (and so without a form). Only 1, 2 and 4 columns:
  // the default widget set is 28 cells, which 3 columns cannot tile without gaps.
  var gridEl = document.querySelector('[data-widget-grid]');
  if (gridEl && F2F && F2F.WidgetGrid) { F2F.WidgetGrid.mount(gridEl, { columns: [1, 2, 4] }); }

  /* ---- Names: the form's own labels for a logged or returned value --------------- */
  function nameOf(key, value) {
    var select = byId('f-' + key);
    if (select) {
      for (var i = 0; i < select.options.length; i++) {
        if (select.options[i].value === value) { return select.options[i].textContent; }
      }
    }
    value = String(value);
    return value.length > 14 ? value.slice(0, 13) + '…' : value;
  }

  /* ---- Recent predictions ------------------------------------------------------ */
  var recentList = byId('recent-list');
  var recentEmpty = byId('recent-empty');

  function clock(iso) {
    var d = new Date(iso);
    return isNaN(d.getTime()) ? '--:--' : d.toISOString().slice(11, 16);
  }

  function loadRecent() {
    if (!recentList) { return Promise.resolve(); }
    var url = recentList.getAttribute('data-recent-url') + '?limit=7';   // what fits the widget's smallest cell without scrolling
    return fetch(url, { headers: { 'Accept': 'application/json' }, credentials: 'same-origin' })
      .then(function (res) {
        if (!res.ok) { throw new Error('HTTP ' + res.status); }
        return res.json();
      })
      .then(function (rows) {
        recentList.textContent = '';
        rows.forEach(function (row) {
          var li = el('li');
          var inputs = KEYS.map(function (k) { return nameOf(k, row[k]); }).join(' · ');
          li.appendChild(el('span', 'recent-time', clock(row.timestamp)));
          var what = el('span', 'recent-inputs', inputs);
          what.title = inputs;
          li.appendChild(what);
          var result = el('span', 'recent-result', row.prediction || '');
          result.setAttribute('data-result', row.prediction || '');
          li.appendChild(result);
          li.appendChild(el('span', 'recent-p', F2F.pct(row.failure_probability)));
          recentList.appendChild(li);
        });
        recentList.hidden = rows.length === 0;
        recentEmpty.textContent = 'No predictions logged yet.';
        recentEmpty.hidden = rows.length > 0;
      })
      .catch(function () {
        recentList.hidden = true;
        recentEmpty.textContent = 'Recent predictions could not be read. Check the server log.';
        recentEmpty.hidden = false;
      });
  }
  loadRecent();

  var form = byId('predict-form');
  if (!form) { return; }

  var predictUrl = form.getAttribute('data-predict-url');
  var explainUrl = form.getAttribute('data-explain-url');

  var runBtn = byId('run-btn');
  var emptyEl = byId('result-empty');
  var errorEl = byId('result-error');
  var bodyEl = byId('result-body');
  var warnWrap = byId('out-warnings');
  var warnList = byId('out-warnings-list');

  var whyEmpty = byId('why-empty');
  var whyList = byId('why-list');
  var whyNote = byId('why-note');
  var altEmpty = byId('alt-empty');
  var altList = byId('alt-list');

  // The reaction widget (reaction-widget.js) listens for what is chosen and for the explanation.
  function announceInputs() {
    var values = {}, names = {};
    KEYS.forEach(function (key) {
      var select = byId('f-' + key);
      values[key] = select ? select.value : '';
      names[key] = select && select.value ? select.selectedOptions[0].textContent : '';
    });
    document.dispatchEvent(new CustomEvent('f2f:inputs', { detail: { values: values, names: names } }));
  }
  function announceExplained(contributions) {
    document.dispatchEvent(new CustomEvent('f2f:explained', { detail: { contributions: contributions } }));
  }

  // Under each field: the drawn structure, and the full selected SMILES.
  KEYS.forEach(function (key) {
    var select = byId('f-' + key);
    var readout = byId('r-' + key);
    var preview = byId('st-' + key);
    if (!select || !readout) { return; }
    select.addEventListener('change', function () {
      readout.textContent = select.value || 'Nothing selected.';
      readout.classList.toggle('is-empty', !select.value);
      if (preview && F2F.Structures) {
        if (select.value) {
          preview.hidden = false;
          F2F.Structures.render(preview, select.value, { width: 240, height: 120 });
        } else {
          preview.hidden = true;
          preview.textContent = '';
        }
      }
      announceInputs();
    });
  });

  function setBusy(busy) {
    runBtn.disabled = busy;
    runBtn.textContent = busy ? 'Running prediction' : 'Run prediction';
  }

  function showError(message) {
    emptyEl.hidden = true;
    bodyEl.hidden = true;
    errorEl.textContent = message;
    errorEl.hidden = false;
  }

  function showResult(d) {
    var failure = d.prediction === 'Failure';
    emptyEl.hidden = true;
    errorEl.hidden = true;
    bodyEl.setAttribute('data-state', failure ? 'failure' : 'success');
    byId('verdict-word').textContent = d.prediction;
    F2F.setLead(byId('out-prob'), F2F.pct(d.failure_probability));
    byId('out-prob-bar').style.width = F2F.pct(d.failure_probability);
    F2F.setLead(byId('out-conf'), F2F.pct(d.confidence));
    byId('out-model').textContent = d.model_used || 'unknown';

    warnList.textContent = '';
    var warnings = Array.isArray(d.warnings) ? d.warnings : [];
    warnings.forEach(function (w) {
      var li = document.createElement('li');
      var tag = document.createElement('span');
      tag.className = 'label';
      tag.textContent = 'Warning';
      var text = document.createElement('span');
      text.textContent = String(w);
      li.appendChild(tag);
      li.appendChild(text);
      warnList.appendChild(li);
    });
    warnWrap.hidden = warnings.length === 0;
    bodyEl.hidden = false;
  }

  function errorMessage(status, data) {
    if (status === 0) {
      return 'Could not reach the server. Check your connection and run the prediction again.';
    }
    var text = data && data.error ? data.error : 'The server returned an unexpected response.';
    if (data && data.detail) { text += ': ' + data.detail; }
    return text + ' (HTTP ' + status + ')';
  }

  /* ---- Why this? and Try this instead -------------------------------------------- */
  function explainUnavailable(message) {
    announceExplained(null);
    whyList.hidden = true;
    whyNote.hidden = true;
    whyEmpty.textContent = message;
    whyEmpty.hidden = false;
    altList.hidden = true;
    altEmpty.textContent = message;
    altEmpty.hidden = false;
  }

  function signed(x) { return (x > 0 ? '+' : MINUS) + Math.abs(x).toFixed(2); }

  function renderWhy(d) {
    var largest = 0;
    d.contributions.forEach(function (c) { largest = Math.max(largest, Math.abs(c.push)); });
    whyList.textContent = '';
    d.contributions.forEach(function (c) {
      var li = el('li', 'why-row');
      var name = el('span', 'why-name');
      name.appendChild(el('span', '', c.input));
      var choice = el('span', 'mono', c.choice);
      choice.title = c.value;
      name.appendChild(choice);
      li.appendChild(name);
      var bar = el('span', 'why-bar');
      bar.setAttribute('aria-hidden', 'true');
      var fill = el('i', 'why-fill');
      fill.setAttribute('data-dir', c.direction);
      fill.style.setProperty('--w', String(largest ? Math.abs(c.push) / largest : 0));
      bar.appendChild(fill);
      li.appendChild(bar);
      var val = el('span', 'why-val', signed(c.push));
      val.appendChild(el('span', 'sr-only', c.direction === 'failure' ? ' toward failure' : ' toward success'));
      li.appendChild(val);
      whyList.appendChild(li);
    });
    var scale = el('li', 'why-scale label');
    scale.setAttribute('aria-hidden', 'true');
    scale.appendChild(el('span'));
    var ends = el('span');
    ends.appendChild(el('span', '', 'Success'));
    ends.appendChild(el('span', '', 'Failure'));
    scale.appendChild(ends);
    scale.appendChild(el('span'));
    whyList.appendChild(scale);
    whyEmpty.hidden = true;
    whyList.hidden = false;
    whyNote.hidden = false;
  }

  function renderAlternatives(d) {
    altList.textContent = '';
    if (!d.alternatives.length) {
      altEmpty.textContent = d.prediction === 'Success'
        ? 'Already predicted to succeed, and no single change lowers the failure probability by 5 points or more.'
        : 'No single change lowers the failure probability by 5 points or more.';
      altEmpty.hidden = false;
      altList.hidden = true;
      return;
    }
    d.alternatives.forEach(function (a) {
      var li = el('li');
      var what = el('span', 'alt-what');
      what.appendChild(el('span', '', a.from + ' → ' + a.to));
      var points = Math.round(-a.change * 100);
      what.appendChild(el('span', 'mono', points + ' points lower' + (a.flips ? ' · flips to Success' : '')));
      what.title = 'Change the ' + a.input.toLowerCase();
      li.appendChild(what);
      li.appendChild(el('span', 'alt-p', F2F.pct(a.failure_probability)));
      var btn = el('button', 'btn btn-ghost alt-try', 'Try');
      btn.type = 'button';
      btn.setAttribute('data-key', a.key);
      btn.setAttribute('data-value', a.to_value);
      btn.setAttribute('aria-label', 'Try ' + a.to + ' instead of ' + a.from);
      li.appendChild(btn);
      altList.appendChild(li);
    });
    altEmpty.hidden = true;
    altList.hidden = false;
  }

  // Load the swap into the form and run it, so one click shows the new result.
  altList.addEventListener('click', function (ev) {
    var btn = ev.target.closest ? ev.target.closest('.alt-try') : null;
    if (!btn) { return; }
    var select = byId('f-' + btn.getAttribute('data-key'));
    if (!select) { return; }
    select.value = btn.getAttribute('data-value');
    select.dispatchEvent(new Event('change', { bubbles: true }));
    if (form.requestSubmit) { form.requestSubmit(); } else { runBtn.click(); }
  });

  var runId = 0;
  function explain(payload, id) {
    return fetch(explainUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
      credentials: 'same-origin',
      body: JSON.stringify(payload)
    })
      .then(function (res) {
        return res.json().catch(function () { return null; }).then(function (data) {
          return { ok: res.ok, status: res.status, data: data };
        });
      })
      .then(function (r) {
        if (id !== runId) { return; }   // a newer run has replaced this one
        if (!r.ok || !r.data) {
          explainUnavailable('The explanation could not be loaded (' + errorMessage(r.status, r.data) + ').');
          return;
        }
        if (!r.data.supported) {
          explainUnavailable(r.data.reason || 'An explanation is not available for this model.');
          return;
        }
        renderWhy(r.data);
        renderAlternatives(r.data);
        announceExplained(r.data.contributions);
      })
      .catch(function () {
        if (id === runId) { explainUnavailable('The explanation could not be loaded. Check your connection.'); }
      });
  }

  form.addEventListener('submit', function (ev) {
    ev.preventDefault();
    var payload = {};
    KEYS.forEach(function (key) { payload[key] = byId('f-' + key).value; });
    var id = ++runId;

    setBusy(true);
    // The widgets that are working glow (widget-effects.js): the form and the result while the
    // model answers, then the explanation widgets while /explain does.
    var stopPredict = working(['predict', 'result']);
    fetch(predictUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
      credentials: 'same-origin',
      body: JSON.stringify(payload)
    })
      .then(function (res) {
        return res.json().catch(function () { return null; }).then(function (data) {
          return { ok: res.ok, status: res.status, data: data };
        });
      })
      .then(function (r) {
        stopPredict();   // answered, or failed: either way the model is done
        var valid = r.ok && r.data &&
          typeof r.data.failure_probability === 'number' &&
          typeof r.data.confidence === 'number';
        if (!valid) {
          showError(errorMessage(r.status, r.data));
          explainUnavailable('Run a prediction to see this.');
          return;
        }
        showResult(r.data);
        F2F.refreshStats();
        loadRecent();
        // The prediction is in the log now: activity, trend and coverage (dashboard-extras.js) re-read it.
        document.dispatchEvent(new CustomEvent('f2f:logged'));
        var stopExplain = working(['why', 'alternatives', 'reaction']);
        return explain(payload, id).then(stopExplain, stopExplain);
      })
      .catch(function () { stopPredict(); showError(errorMessage(0, null)); })
      .then(function () { setBusy(false); });
  });

  announceInputs();   // nothing chosen yet: the reaction widget starts from a clean scheme
})();
